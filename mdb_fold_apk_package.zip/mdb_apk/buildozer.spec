[app]

# App identity
title = MDB Fold
package.name = mdbfold
package.domain = org.mdb

# Entry point
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,json
source.include_patterns = mdb_engine/*.py

# Version
version = 1.0.0

# Requirements — NO compression libraries, pure Python + Kivy
requirements = python3,kivy,kivymd

# Android permissions
android.permissions = READ_EXTERNAL_STORAGE,WRITE_EXTERNAL_STORAGE,MANAGE_EXTERNAL_STORAGE

# Android API
android.api = 33
android.minapi = 21
android.ndk = 25b
android.sdk = 33
android.accept_sdk_license = True

# Architecture — build for all common Android devices
android.archs = arm64-v8a, armeabi-v7a

# App icon and presplash
# android.icon.filename = %(source.dir)s/assets/icon.png
# android.presplash.filename = %(source.dir)s/assets/presplash.png

# Orientation
orientation = portrait

# Fullscreen
fullscreen = 0

[buildozer]

# Build directory
build_dir = ./.buildozer

# Log level (0=error, 1=info, 2=debug)
log_level = 2

warn_on_root = 1

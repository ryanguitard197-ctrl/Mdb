"""
================================================================================
MDB FOLD — Android APK Main Application
================================================================================
The MDB Fold app. Fold any file. Unfold any .mdb file.
Pure dimensional addressing. Zero compression. Perfectly lossless.

This is the entry point for the Android APK.
Built with Kivy for cross-platform support (Android + Windows same code).
================================================================================
"""

import os
import sys
import threading
import time

# Add engine to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'mdb_engine'))

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.progressbar import ProgressBar
from kivy.uix.scrollview import ScrollView
from kivy.uix.popup import Popup
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.textinput import TextInput
from kivy.core.window import Window
from kivy.clock import Clock
from kivy.utils import platform
from kivy.metrics import dp

from mdb_engine.mdb_fold_engine import MDBFoldEngine, format_size, format_time


# ============================================================================
# COLOR SCHEME — Dark, technical, clean
# ============================================================================
BG_DARK     = (0.05, 0.05, 0.08, 1)
BG_PANEL    = (0.10, 0.10, 0.15, 1)
BG_BUTTON   = (0.08, 0.20, 0.35, 1)
BG_FOLD     = (0.05, 0.35, 0.15, 1)
BG_UNFOLD   = (0.30, 0.15, 0.05, 1)
BG_DANGER   = (0.35, 0.05, 0.05, 1)
COLOR_CYAN  = (0.0,  0.85, 1.0,  1)
COLOR_GREEN = (0.0,  1.0,  0.4,  1)
COLOR_AMBER = (1.0,  0.75, 0.0,  1)
COLOR_WHITE = (1.0,  1.0,  1.0,  1)
COLOR_GREY  = (0.6,  0.6,  0.6,  1)
COLOR_RED   = (1.0,  0.3,  0.3,  1)


# ============================================================================
# CUSTOM WIDGETS
# ============================================================================

class MDBButton(Button):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.background_normal = ''
        self.background_color = BG_BUTTON
        self.color = COLOR_WHITE
        self.font_size = dp(14)
        self.bold = True
        self.size_hint_y = None
        self.height = dp(52)


class MDBLabel(Label):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.color = COLOR_WHITE
        self.font_size = dp(13)
        self.halign = 'left'
        self.valign = 'middle'
        self.text_size = (self.width, None)
        self.bind(size=self._update_text_size)

    def _update_text_size(self, *args):
        self.text_size = (self.width, None)


class StatRow(BoxLayout):
    def __init__(self, label_text, value_text='—', **kwargs):
        super().__init__(orientation='horizontal', size_hint_y=None,
                        height=dp(32), **kwargs)
        self.label = Label(
            text=label_text, color=COLOR_GREY,
            font_size=dp(12), halign='left',
            size_hint_x=0.45
        )
        self.value = Label(
            text=value_text, color=COLOR_CYAN,
            font_size=dp(12), halign='right', bold=True,
            size_hint_x=0.55
        )
        self.add_widget(self.label)
        self.add_widget(self.value)

    def set_value(self, text, color=None):
        self.value.text = text
        if color:
            self.value.color = color


class LogView(ScrollView):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.label = Label(
            text='[ MDB ENGINE READY ]\n',
            color=COLOR_GREEN,
            font_size=dp(11),
            halign='left',
            valign='top',
            size_hint_y=None,
            markup=True
        )
        self.label.bind(texture_size=self._update_height)
        self.add_widget(self.label)

    def _update_height(self, *args):
        self.label.height = self.label.texture_size[1]

    def log(self, message, color='ffffff'):
        timestamp = time.strftime('%H:%M:%S')
        self.label.text += f'[color={color}][{timestamp}] {message}[/color]\n'
        Clock.schedule_once(lambda dt: setattr(self, 'scroll_y', 0), 0.1)

    def log_success(self, msg):
        self.log(msg, '00ff66')

    def log_error(self, msg):
        self.log(msg, 'ff4444')

    def log_info(self, msg):
        self.log(msg, '00ccff')

    def log_dim(self, msg):
        self.log(msg, 'aaaaaa')


# ============================================================================
# FILE CHOOSER POPUP
# ============================================================================

class FileChooserPopup(Popup):
    def __init__(self, callback, mode='fold', **kwargs):
        super().__init__(**kwargs)
        self.callback = callback
        self.mode = mode
        self.title = 'Select File to Fold' if mode == 'fold' else 'Select .mdb File to Unfold'
        self.size_hint = (0.95, 0.9)
        self.background_color = BG_PANEL

        layout = BoxLayout(orientation='vertical', spacing=dp(8), padding=dp(8))

        # Determine start path
        if platform == 'android':
            start_path = '/storage/emulated/0/'
            if not os.path.exists(start_path):
                start_path = os.path.expanduser('~')
        else:
            start_path = os.path.expanduser('~')

        # File chooser
        if mode == 'unfold':
            self.chooser = FileChooserListView(
                path=start_path,
                filters=['*.mdb'],
                size_hint_y=0.85
            )
        else:
            self.chooser = FileChooserListView(
                path=start_path,
                size_hint_y=0.85
            )

        layout.add_widget(self.chooser)

        # Buttons
        btn_layout = BoxLayout(
            size_hint_y=None, height=dp(52),
            spacing=dp(8)
        )

        select_btn = Button(
            text='SELECT',
            background_normal='',
            background_color=BG_FOLD,
            color=COLOR_WHITE,
            bold=True
        )
        select_btn.bind(on_release=self._on_select)

        cancel_btn = Button(
            text='CANCEL',
            background_normal='',
            background_color=BG_DANGER,
            color=COLOR_WHITE,
            bold=True
        )
        cancel_btn.bind(on_release=self.dismiss)

        btn_layout.add_widget(select_btn)
        btn_layout.add_widget(cancel_btn)
        layout.add_widget(btn_layout)

        self.content = layout

    def _on_select(self, instance):
        selection = self.chooser.selection
        if selection:
            self.dismiss()
            self.callback(selection[0])
        else:
            pass  # Nothing selected, stay open


# ============================================================================
# MAIN SCREEN
# ============================================================================

class MDBFoldScreen(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation='vertical', spacing=dp(6),
                        padding=dp(10), **kwargs)

        self.engine = MDBFoldEngine()
        self.selected_file = None
        self.processing = False

        Window.clearcolor = BG_DARK

        self._build_ui()

    def _build_ui(self):
        # ── HEADER ──────────────────────────────────────────────
        header = BoxLayout(
            orientation='vertical',
            size_hint_y=None,
            height=dp(70),
            padding=[0, dp(4)]
        )
        title = Label(
            text='MDB FOLD',
            color=COLOR_CYAN,
            font_size=dp(26),
            bold=True,
            size_hint_y=None,
            height=dp(36)
        )
        subtitle = Label(
            text='Multidimensional Binary  •  Zero Compression  •  Lossless',
            color=COLOR_GREY,
            font_size=dp(11),
            size_hint_y=None,
            height=dp(22)
        )
        header.add_widget(title)
        header.add_widget(subtitle)
        self.add_widget(header)

        # ── FILE SELECTION ───────────────────────────────────────
        file_panel = BoxLayout(
            orientation='vertical',
            size_hint_y=None,
            height=dp(110),
            spacing=dp(6)
        )

        file_label_row = BoxLayout(size_hint_y=None, height=dp(22))
        file_label_row.add_widget(Label(
            text='SELECTED FILE',
            color=COLOR_GREY,
            font_size=dp(11),
            halign='left'
        ))
        file_panel.add_widget(file_label_row)

        self.file_display = Label(
            text='No file selected',
            color=COLOR_AMBER,
            font_size=dp(12),
            halign='left',
            size_hint_y=None,
            height=dp(38),
            text_size=(Window.width - dp(20), None)
        )
        file_panel.add_widget(self.file_display)

        btn_row = BoxLayout(
            size_hint_y=None,
            height=dp(42),
            spacing=dp(8)
        )

        fold_select_btn = Button(
            text='SELECT FILE TO FOLD',
            background_normal='',
            background_color=BG_FOLD,
            color=COLOR_WHITE,
            bold=True,
            font_size=dp(13)
        )
        fold_select_btn.bind(on_release=lambda x: self._open_chooser('fold'))

        unfold_select_btn = Button(
            text='SELECT .MDB TO UNFOLD',
            background_normal='',
            background_color=BG_UNFOLD,
            color=COLOR_WHITE,
            bold=True,
            font_size=dp(13)
        )
        unfold_select_btn.bind(on_release=lambda x: self._open_chooser('unfold'))

        btn_row.add_widget(fold_select_btn)
        btn_row.add_widget(unfold_select_btn)
        file_panel.add_widget(btn_row)

        self.add_widget(file_panel)

        # ── ACTION BUTTON ────────────────────────────────────────
        self.action_btn = Button(
            text='SELECT A FILE ABOVE TO BEGIN',
            background_normal='',
            background_color=(0.2, 0.2, 0.2, 1),
            color=COLOR_GREY,
            bold=True,
            font_size=dp(15),
            size_hint_y=None,
            height=dp(58),
            disabled=True
        )
        self.action_btn.bind(on_release=self._execute)
        self.add_widget(self.action_btn)

        # ── PROGRESS ─────────────────────────────────────────────
        progress_panel = BoxLayout(
            orientation='vertical',
            size_hint_y=None,
            height=dp(56),
            spacing=dp(4)
        )

        self.progress_bar = ProgressBar(
            max=100, value=0,
            size_hint_y=None,
            height=dp(20)
        )
        self.progress_label = Label(
            text='Ready',
            color=COLOR_GREY,
            font_size=dp(12),
            size_hint_y=None,
            height=dp(24)
        )
        progress_panel.add_widget(self.progress_bar)
        progress_panel.add_widget(self.progress_label)
        self.add_widget(progress_panel)

        # ── STATS PANEL ──────────────────────────────────────────
        stats_label = Label(
            text='DIMENSIONAL STATS',
            color=COLOR_GREY,
            font_size=dp(11),
            halign='left',
            size_hint_y=None,
            height=dp(20)
        )
        self.add_widget(stats_label)

        stats_grid = GridLayout(
            cols=1,
            size_hint_y=None,
            spacing=dp(2),
            padding=[dp(4), 0]
        )
        stats_grid.bind(minimum_height=stats_grid.setter('height'))

        self.stat_original   = StatRow('Original Size:')
        self.stat_mdb        = StatRow('MDB Size:')
        self.stat_address    = StatRow('D3 Address:')
        self.stat_d4         = StatRow('D4 Density:')
        self.stat_d5         = StatRow('D5 Gravity:')
        self.stat_chunks     = StatRow('Dimensional Chunks:')
        self.stat_time       = StatRow('Fold/Unfold Time:')
        self.stat_integrity  = StatRow('Integrity:')

        for stat in [self.stat_original, self.stat_mdb, self.stat_address,
                     self.stat_d4, self.stat_d5, self.stat_chunks,
                     self.stat_time, self.stat_integrity]:
            stats_grid.add_widget(stat)

        self.add_widget(stats_grid)

        # ── LOG ──────────────────────────────────────────────────
        log_label = Label(
            text='ENGINE LOG',
            color=COLOR_GREY,
            font_size=dp(11),
            halign='left',
            size_hint_y=None,
            height=dp(20)
        )
        self.add_widget(log_label)

        self.log_view = LogView(size_hint_y=1)
        self.add_widget(self.log_view)

    # ── FILE CHOOSER ─────────────────────────────────────────────

    def _open_chooser(self, mode):
        if self.processing:
            return
        popup = FileChooserPopup(
            callback=lambda path: self._file_selected(path, mode),
            mode=mode
        )
        popup.open()

    def _file_selected(self, path, mode):
        self.selected_file = path
        self.selected_mode = mode
        filename = os.path.basename(path)
        size = format_size(os.path.getsize(path))

        self.file_display.text = f'{filename}  ({size})'
        self.file_display.color = COLOR_WHITE

        if mode == 'fold':
            self.action_btn.text = f'FOLD  →  {filename}.mdb'
            self.action_btn.background_color = BG_FOLD
        else:
            self.action_btn.text = f'UNFOLD  →  {filename}'
            self.action_btn.background_color = BG_UNFOLD

        self.action_btn.color = COLOR_WHITE
        self.action_btn.disabled = False

        self.log_view.log_info(f'Selected: {filename} ({size}) [{mode.upper()} mode]')
        self._reset_stats()

    # ── EXECUTE ──────────────────────────────────────────────────

    def _execute(self, instance):
        if self.processing or not self.selected_file:
            return
        self.processing = True
        self.action_btn.disabled = True
        mode = getattr(self, 'selected_mode', 'fold')

        thread = threading.Thread(
            target=self._run_operation,
            args=(self.selected_file, mode),
            daemon=True
        )
        thread.start()

    def _run_operation(self, path, mode):
        try:
            if mode == 'fold':
                self._do_fold(path)
            else:
                self._do_unfold(path)
        except Exception as e:
            Clock.schedule_once(lambda dt: self._on_error(str(e)))
        finally:
            Clock.schedule_once(lambda dt: self._finish())

    def _do_fold(self, path):
        Clock.schedule_once(lambda dt: self.log_view.log_info(
            f'Beginning dimensional fold: {os.path.basename(path)}'
        ))
        Clock.schedule_once(lambda dt: self.log_view.log_dim(
            'No compression. Pure dimensional addressing.'
        ))

        def progress(pct, msg):
            Clock.schedule_once(lambda dt, p=pct, m=msg: self._update_progress(p, m))

        result = self.engine.fold_file(path, progress_callback=progress)

        def update_ui(dt):
            self._update_fold_stats(result)
            if result['success']:
                self.log_view.log_success(
                    f"Fold complete! → {os.path.basename(result['mdb_path'])}"
                )
                self.log_view.log_dim(
                    f"Dimensional address: D3={result['file_address'][0]} "
                    f"D4={result['file_address'][1]:.4f} "
                    f"D5={result['file_address'][2]:.4f}"
                )
                self.log_view.log_dim(
                    f"Time: {format_time(result['fold_time'])} | "
                    f"Chunks: {result['total_chunks']}"
                )

        Clock.schedule_once(update_ui)

    def _do_unfold(self, path):
        Clock.schedule_once(lambda dt: self.log_view.log_info(
            f'Unfolding: {os.path.basename(path)}'
        ))

        def progress(pct, msg):
            Clock.schedule_once(lambda dt, p=pct, m=msg: self._update_progress(p, m))

        result = self.engine.unfold_file(path, progress_callback=progress)

        def update_ui(dt):
            self._update_unfold_stats(result)
            if result['integrity_verified']:
                self.log_view.log_success(
                    f"Unfold complete! Integrity VERIFIED ✓"
                )
                self.log_view.log_success(
                    f"→ {os.path.basename(result['output_path'])}"
                )
            else:
                self.log_view.log_error('INTEGRITY FAILURE — hashes do not match')

        Clock.schedule_once(update_ui)

    # ── UI UPDATES ───────────────────────────────────────────────

    def _update_progress(self, pct, msg):
        self.progress_bar.value = pct
        self.progress_label.text = msg

    def _update_fold_stats(self, result):
        addr = result['file_address']
        self.stat_original.set_value(format_size(result['original_size']))
        self.stat_mdb.set_value(format_size(result['mdb_size']))
        self.stat_address.set_value(str(addr[0]))
        self.stat_d4.set_value(f"{addr[1]:.6f}")
        self.stat_d5.set_value(f"{addr[2]:.6f}")
        self.stat_chunks.set_value(str(result['total_chunks']))
        self.stat_time.set_value(format_time(result['fold_time']))
        self.stat_integrity.set_value('LOSSLESS ✓', COLOR_GREEN)

    def _update_unfold_stats(self, result):
        addr = result.get('file_address', {})
        self.stat_original.set_value(format_size(result['original_size']))
        self.stat_mdb.set_value(format_size(result['restored_size']))
        self.stat_address.set_value(str(addr.get('d3', '—')))
        self.stat_d4.set_value(f"{addr.get('d4', 0):.6f}")
        self.stat_d5.set_value(f"{addr.get('d5', 0):.6f}")
        self.stat_time.set_value(format_time(result['unfold_time']))
        if result['integrity_verified']:
            self.stat_integrity.set_value('VERIFIED ✓', COLOR_GREEN)
        else:
            self.stat_integrity.set_value('FAILED ✗', COLOR_RED)

    def _reset_stats(self):
        for stat in [self.stat_original, self.stat_mdb, self.stat_address,
                     self.stat_d4, self.stat_d5, self.stat_chunks,
                     self.stat_time, self.stat_integrity]:
            stat.set_value('—', COLOR_CYAN)

    def _on_error(self, error_msg):
        self.log_view.log_error(f'ERROR: {error_msg}')
        self.progress_label.text = 'Error — see log'

    def _finish(self):
        self.processing = False
        self.action_btn.disabled = False


# ============================================================================
# KIVY APP
# ============================================================================

class MDBFoldApp(App):
    def build(self):
        self.title = 'MDB Fold v1.0'
        if platform == 'android':
            Window.fullscreen = 'auto'
        else:
            Window.size = (420, 780)
        return MDBFoldScreen()

    def on_pause(self):
        return True

    def on_resume(self):
        pass


if __name__ == '__main__':
    MDBFoldApp().run()

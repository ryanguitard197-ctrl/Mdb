# MDB FOLD v1.0 — APK Build Instructions

## What This Is
MDB Fold is the first application built on the Multidimensional Binary engine.
It folds any file into dimensional coordinate space and unfolds it back perfectly.
Zero compression. Pure dimensional addressing. Lossless. Always.

## Files in This Package
```
mdb_apk/
├── main.py                    ← APK entry point (Kivy app)
├── buildozer.spec             ← APK build configuration
├── BUILD.md                   ← This file
└── mdb_engine/
    ├── mdb_core.py            ← The MDB canonical engine (Ryan's invention)
    └── mdb_fold_engine.py     ← Pure dimensional fold/unfold engine
```

---

## OPTION 1: Build APK on Linux/Mac (Recommended)

### Requirements
- Linux or Mac (Windows needs WSL)
- Python 3.8+
- Java JDK 11+

### Steps

```bash
# 1. Install buildozer
pip install buildozer

# 2. Install system dependencies (Ubuntu/Debian)
sudo apt-get install -y \
    python3-pip \
    build-essential \
    git \
    ffmpeg \
    libsdl2-dev \
    libsdl2-image-dev \
    libsdl2-mixer-dev \
    libsdl2-ttf-dev \
    libportmidi-dev \
    libswscale-dev \
    libavformat-dev \
    libavcodec-dev \
    zlib1g-dev \
    libgstreamer1.0-dev \
    autoconf \
    libtool \
    pkg-config \
    libncurses5-dev \
    libtinfo5 \
    cmake \
    libffi-dev \
    libssl-dev

# 3. Navigate to mdb_apk folder
cd mdb_apk

# 4. Build the APK (first build takes 15-30 min, downloads Android SDK)
buildozer android debug

# 5. Find your APK here:
# bin/mdbfold-1.0.0-arm64-v8a-debug.apk
```

---

## OPTION 2: Build APK on Android Phone (Termux)

### Steps

```bash
# 1. Install Termux from F-Droid (NOT Google Play)

# 2. In Termux:
pkg update && pkg upgrade
pkg install python git binutils
pip install buildozer kivy

# 3. Copy mdb_apk folder to phone
# (via USB or download)

# 4. Navigate to it
cd /path/to/mdb_apk

# 5. Build
buildozer android debug

# APK will be in bin/ folder
```

---

## OPTION 3: Use an Online Build Service

Upload the entire mdb_apk folder to:
- **Buildozer GitHub Actions** — free, automated
- **Google Cloud Build** — reliable
- **Replit** — browser-based, free tier available

---

## OPTION 4: Run Directly on Android Without Building APK

If you have Pydroid 3 installed on your Android device:

1. Copy the entire `mdb_apk` folder to your phone
2. Open Pydroid 3
3. Install kivy: pip install kivy (in Pydroid terminal)
4. Open `main.py` in Pydroid 3
5. Run it

This runs the exact same app without needing to build an APK.
Good for testing before building.

---

## INSTALLING THE APK

Once built:
1. Transfer `bin/mdbfold-1.0.0-debug.apk` to your Android device
2. Enable "Install from unknown sources" in Android settings
3. Tap the APK file to install
4. Open MDB Fold

---

## WHAT THE APP DOES

**FOLD a file:**
- Tap "SELECT FILE TO FOLD"
- Choose any file on your device
- Tap the green FOLD button
- A `.mdb` file is created alongside the original
- Dimensional address (D3/D4/D5) is shown
- Original file is untouched

**UNFOLD a file:**
- Tap "SELECT .MDB TO UNFOLD"  
- Choose any `.mdb` file
- Tap the orange UNFOLD button
- Original file is perfectly restored
- SHA-256 hash verified — LOSSLESS confirmed

---

## IMPORTANT NOTES

- This is NOT compression. Data is not squeezed or encoded with loss.
- Folding maps data to dimensional coordinates. Every bit is preserved.
- The .mdb file contains the original data organized by dimensional address.
- Unfolding restores the original byte-for-byte. SHA-256 verified.
- No internet connection required. Runs entirely on-device.

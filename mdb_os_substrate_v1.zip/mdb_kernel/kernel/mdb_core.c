/* mdb_core.c — MDB Fold Engine
 *
 * Implements the three MDB primitives:
 *   1. Dimensional addressing  (D3/D4/D5)
 *   2. evolve_step             (deterministic evolution rule)
 *   3. fold / unfold           (lossless dimensional storage)
 *
 * No compression. No zlib. No information loss.
 * The dimensional address IS the retrieval key.
 */

#ifdef __KERNEL__
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/slab.h>
#include <linux/string.h>
#else
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#endif

#include "mdb_core.h"

/* ── CRC32 (IEEE 802.3 polynomial, no external dep) ─────────────────────── */

static u32 crc32_table[256];
static int crc32_init_done = 0;

static void crc32_init(void)
{
    u32 i, j, c;
    for (i = 0; i < 256; i++) {
        c = i;
        for (j = 0; j < 8; j++)
            c = (c & 1) ? (0xEDB88320U ^ (c >> 1)) : (c >> 1);
        crc32_table[i] = c;
    }
    crc32_init_done = 1;
}

u32 mdb_crc32(const u8 *data, u64 len)
{
    u32 crc = 0xFFFFFFFFU;
    u64 i;
    if (!crc32_init_done) crc32_init();
    for (i = 0; i < len; i++)
        crc = crc32_table[(crc ^ data[i]) & 0xFF] ^ (crc >> 8);
    return crc ^ 0xFFFFFFFFU;
}

/* ── Integer sqrt (no FPU) ───────────────────────────────────────────────── */

u64 mdb_isqrt(u64 n)
{
    u64 x = n, y = 1;
    if (n == 0) return 0;
    while (x > y) { x = (x + y) / 2; y = n / x; }
    return x;
}

/* ── Dimensional Address ─────────────────────────────────────────────────── */

/*
 * D3: Temporal coordinate = byte length of data.
 *     Length IS time. This is the founding insight.
 *
 * D4: Probability density = (number of 1-bits) / (total bits) × 10^6.
 *     Stored as integer to avoid FPU in kernel.
 *
 * D5: Relational gravity = sum(bit[i] × PHI × (i+1)) mod 10^6.
 *     PHI-weighting ensures no two positions produce the same contribution.
 *     Uses integer fixed-point arithmetic — no FPU.
 *
 * All three together uniquely identify any distinct data payload.
 */

mdb_addr_t mdb_compute_addr(const u8 *data, u64 len_bytes)
{
    mdb_addr_t addr;
    u64 total_bits, ones, gravity, i, j;
    u8 byte, bit;

    addr.d3 = len_bytes;

    total_bits = len_bytes * 8;
    ones = 0;
    gravity = 0;

    for (i = 0; i < len_bytes; i++) {
        byte = data[i];
        for (j = 0; j < 8; j++) {
            bit = (byte >> (7 - j)) & 1;
            u64 pos = i * 8 + j + 1;  /* 1-indexed */
            if (bit) {
                ones++;
                /* PHI fixed-point: phi_contrib = bit × PHI_NUM × pos / PHI_DEN */
                gravity += (MDB_PHI_NUM * pos) / MDB_PHI_DEN;
            }
        }
    }

    /* D4: density × 10^6, integer */
    addr.d4 = (total_bits > 0) ? (ones * MDB_ADDR_PREC / total_bits) : 0;

    /* D5: gravity mod 10^6 */
    addr.d5 = gravity % MDB_ADDR_PREC;

    return addr;
}

/* Compute address from a raw bit array (1 byte per bit) */
mdb_addr_t mdb_compute_addr_bits(const u8 *bits, u64 len_bits)
{
    mdb_addr_t addr;
    u64 ones, gravity, i;

    addr.d3 = len_bits;
    ones = 0;
    gravity = 0;

    for (i = 0; i < len_bits; i++) {
        if (bits[i]) {
            ones++;
            gravity += (MDB_PHI_NUM * (i + 1)) / MDB_PHI_DEN;
        }
    }

    addr.d4 = (len_bits > 0) ? (ones * MDB_ADDR_PREC / len_bits) : 0;
    addr.d5 = gravity % MDB_ADDR_PREC;

    return addr;
}

/* Address comparison for BTree ordering */
int mdb_addr_cmp(const mdb_addr_t *a, const mdb_addr_t *b)
{
    if (a->d3 < b->d3) return -1;
    if (a->d3 > b->d3) return  1;
    if (a->d4 < b->d4) return -1;
    if (a->d4 > b->d4) return  1;
    if (a->d5 < b->d5) return -1;
    if (a->d5 > b->d5) return  1;
    return 0;
}

/* ── evolve_step ─────────────────────────────────────────────────────────── */

/*
 * One deterministic evolution step on a bit array.
 *
 *   Odd length  → flip bit at index len/2   (middle)
 *   Even length → flip bit at index len-1   (last)
 *
 * This is the clock of the MDB substrate.
 * The string's own length drives its own next state.
 * No external input. No randomness.
 *
 * Returns the index that was flipped.
 */
u64 mdb_evolve_step(u8 *bits, u64 len)
{
    u64 target;
    if (len == 0) return 0;
    target = (len % 2 == 1) ? (len / 2) : (len - 1);
    bits[target] ^= 1;
    return target;
}

/* ── Fold / Unfold ───────────────────────────────────────────────────────── */

/*
 * mdb_fold: attach a dimensional header to data.
 *
 * Output layout:
 *   [32 bytes: mdb_fold_hdr_t] [orig_len bytes: original data verbatim]
 *
 * This is NOT compression. The data is stored in full, unchanged.
 * The header encodes the dimensional address for O(1) retrieval.
 *
 * Why this matters:
 *   Classical storage: find file by path traversal (O(log n) or worse).
 *   MDB storage: compute address from data, retrieve directly (O(1)).
 *   Two different datasets cannot have the same address.
 *   The same dataset always has the same address on any machine.
 */
u64 mdb_fold(const u8 *data, u64 len, u8 *out, u64 out_size)
{
    mdb_fold_hdr_t hdr;
    u64 total = MDB_FOLD_HDR_SIZE + len;

    if (!data || !out || out_size < total)
        return 0;

    hdr.magic      = MDB_FOLD_MAGIC;
    hdr.addr       = mdb_compute_addr(data, len);
    hdr.orig_bytes = len;
    hdr.checksum   = mdb_crc32(data, len);

    MDB_MEMCPY(out, &hdr, MDB_FOLD_HDR_SIZE);
    MDB_MEMCPY(out + MDB_FOLD_HDR_SIZE, data, len);

    return total;
}

/*
 * mdb_unfold: verify header and return pointer to original data.
 *
 * Does NOT copy. Returns a pointer into the folded buffer.
 * Zero-copy retrieval: the data never moved.
 */
const u8 *mdb_unfold(const u8 *folded, u64 folded_len, u64 *orig_len)
{
    const mdb_fold_hdr_t *hdr;
    mdb_addr_t recomputed;
    u32 check;

    if (!folded || folded_len < MDB_FOLD_HDR_SIZE)
        return NULL;

    hdr = (const mdb_fold_hdr_t *)folded;

    /* Verify magic */
    if (hdr->magic != MDB_FOLD_MAGIC)
        return NULL;

    /* Verify size consistency */
    if (folded_len < MDB_FOLD_HDR_SIZE + hdr->orig_bytes)
        return NULL;

    /* Verify dimensional address matches the data */
    recomputed = mdb_compute_addr(folded + MDB_FOLD_HDR_SIZE, hdr->orig_bytes);
    if (mdb_addr_cmp(&recomputed, &hdr->addr) != 0)
        return NULL;

    /* Verify checksum */
    check = mdb_crc32(folded + MDB_FOLD_HDR_SIZE, hdr->orig_bytes);
    if (check != hdr->checksum)
        return NULL;

    if (orig_len)
        *orig_len = hdr->orig_bytes;

    return folded + MDB_FOLD_HDR_SIZE;
}

int mdb_verify(const u8 *folded, u64 folded_len)
{
    u64 orig_len;
    return mdb_unfold(folded, folded_len, &orig_len) != NULL;
}

/* ── SuperBit ────────────────────────────────────────────────────────────── */

mdb_superbit_t *mdb_superbit_new(const char *label, const u8 *data, u64 len)
{
    mdb_superbit_t *sb;
    u64 i, j;

    sb = (mdb_superbit_t *)MDB_MALLOC(sizeof(mdb_superbit_t));
    if (!sb) return NULL;

    sb->len = len * 8;
    sb->bits = (u8 *)MDB_MALLOC(sb->len);
    if (!sb->bits) { MDB_FREE(sb); return NULL; }

    /* Unpack bytes to bit array */
    for (i = 0; i < len; i++) {
        for (j = 0; j < 8; j++) {
            sb->bits[i * 8 + j] = (data[i] >> (7 - j)) & 1;
        }
    }

    sb->addr  = mdb_compute_addr_bits(sb->bits, sb->len);
    sb->ticks = 0;

    MDB_MEMSET(sb->label, 0, 64);
    if (label) {
        u64 llen = 0;
        while (label[llen] && llen < 63) llen++;
        MDB_MEMCPY(sb->label, label, llen);
    }

    return sb;
}

void mdb_superbit_free(mdb_superbit_t *sb)
{
    if (!sb) return;
    if (sb->bits) MDB_FREE(sb->bits);
    MDB_FREE(sb);
}

/* Apply one evolve_step and update the address. Returns flipped index. */
u64 mdb_superbit_tick(mdb_superbit_t *sb)
{
    u64 flipped;
    if (!sb || sb->len == 0) return 0;
    flipped = mdb_evolve_step(sb->bits, sb->len);
    sb->addr = mdb_compute_addr_bits(sb->bits, sb->len);
    sb->ticks++;
    return flipped;
}

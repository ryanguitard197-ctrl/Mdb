/* mdb_syscalls.c — MDB Userspace Interface
 *
 * Exposes MDB primitives to all userspace programs via:
 *   1. /proc/mdb        — read kernel MDB stats
 *   2. /dev/mdb         — character device for fold/unfold/addr ops
 *   3. ioctl interface  — used by the mdb-tool CLI and any future app
 *
 * Any program on the system can use MDB natively from day one.
 * No recompilation needed. No special libraries.
 * Open /dev/mdb, write data, get back dimensional address.
 */

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/atomic.h>
#include <linux/mutex.h>

#include "mdb_core.h"

/* ── ioctl command definitions ───────────────────────────────────────────── */

struct mdb_fold_req {
    u64  in_size;           /* size of input data */
    u64  out_size;          /* size of output buffer */
    u64  result_size;       /* filled by kernel: actual output size */
    u64  __pad;
    /* followed by: in_size bytes input, out_size bytes output buffer
     * passed via separate read/write calls or mmap */
};

struct mdb_addr_req {
    u64        data_size;   /* size of data to address */
    u64        __pad;
    mdb_addr_t addr;        /* filled by kernel */
};

struct mdb_evolve_req {
    u64  len;               /* number of bits */
    u64  steps;             /* steps to apply */
    u64  flipped;           /* last flipped index (output) */
};

#define MDB_IOC_MAGIC     'D'
#define MDB_FOLD          _IOWR(MDB_IOC_MAGIC, 10, struct mdb_fold_req)
#define MDB_UNFOLD        _IOWR(MDB_IOC_MAGIC, 11, struct mdb_fold_req)
#define MDB_GETADDR       _IOWR(MDB_IOC_MAGIC, 12, struct mdb_addr_req)
#define MDB_EVOLVE        _IOWR(MDB_IOC_MAGIC, 13, struct mdb_evolve_req)
#define MDB_VERIFY        _IOWR(MDB_IOC_MAGIC, 14, struct mdb_fold_req)

/* ── Device state ────────────────────────────────────────────────────────── */

#define MDB_DEVNAME      "mdb"
#define MDB_CLASSNAME    "mdb"
#define MDB_MAX_BUF      (64 * 1024 * 1024)   /* 64 MiB max per operation */

static int          mdb_major;
static struct class *mdb_class;
static struct cdev  mdb_cdev;

/* Global stats */
static atomic64_t stat_folds      = ATOMIC64_INIT(0);
static atomic64_t stat_unfolds    = ATOMIC64_INIT(0);
static atomic64_t stat_addr_calls = ATOMIC64_INIT(0);
static atomic64_t stat_evolves    = ATOMIC64_INIT(0);
static atomic64_t stat_bytes_in   = ATOMIC64_INIT(0);

/* Per-fd session buffer */
struct mdb_session {
    u8     *buf;
    u64     buf_size;
    struct mutex lock;
};

static int mdb_open(struct inode *inode, struct file *file)
{
    struct mdb_session *sess;

    sess = kzalloc(sizeof(*sess), GFP_KERNEL);
    if (!sess) return -ENOMEM;

    mutex_init(&sess->lock);
    file->private_data = sess;
    return 0;
}

static int mdb_release(struct inode *inode, struct file *file)
{
    struct mdb_session *sess = file->private_data;
    if (sess) {
        if (sess->buf) kvfree(sess->buf);
        kfree(sess);
    }
    return 0;
}

/* ── Core ioctl handler ──────────────────────────────────────────────────── */

static long mdb_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    struct mdb_session *sess = file->private_data;
    long ret = 0;

    mutex_lock(&sess->lock);

    switch (cmd) {

    /* ── MDB_GETADDR: compute dimensional address of user data ── */
    case MDB_GETADDR: {
        struct mdb_addr_req req;
        u8 *kbuf;

        if (copy_from_user(&req, (void __user *)arg, sizeof(req))) {
            ret = -EFAULT; break;
        }
        if (req.data_size == 0 || req.data_size > MDB_MAX_BUF) {
            ret = -EINVAL; break;
        }

        kbuf = kvmalloc(req.data_size, GFP_KERNEL);
        if (!kbuf) { ret = -ENOMEM; break; }

        /* Data pointer follows the struct in userspace */
        if (copy_from_user(kbuf,
                           (void __user *)(arg + sizeof(struct mdb_addr_req)),
                           req.data_size)) {
            kvfree(kbuf); ret = -EFAULT; break;
        }

        req.addr = mdb_compute_addr(kbuf, req.data_size);
        kvfree(kbuf);

        if (copy_to_user((void __user *)arg, &req, sizeof(req))) {
            ret = -EFAULT; break;
        }

        atomic64_inc(&stat_addr_calls);
        atomic64_add(req.data_size, &stat_bytes_in);
        break;
    }

    /* ── MDB_FOLD: fold user data, return header+data ── */
    case MDB_FOLD: {
        struct mdb_fold_req req;
        u8 *in_buf, *out_buf;
        u64 folded_size;

        if (copy_from_user(&req, (void __user *)arg, sizeof(req))) {
            ret = -EFAULT; break;
        }
        if (req.in_size == 0 || req.in_size > MDB_MAX_BUF) {
            ret = -EINVAL; break;
        }

        in_buf  = kvmalloc(req.in_size, GFP_KERNEL);
        out_buf = kvmalloc(req.in_size + MDB_FOLD_HDR_SIZE, GFP_KERNEL);
        if (!in_buf || !out_buf) {
            kvfree(in_buf); kvfree(out_buf);
            ret = -ENOMEM; break;
        }

        if (copy_from_user(in_buf,
                           (void __user *)(arg + sizeof(struct mdb_fold_req)),
                           req.in_size)) {
            kvfree(in_buf); kvfree(out_buf);
            ret = -EFAULT; break;
        }

        folded_size = mdb_fold(in_buf, req.in_size,
                               out_buf, req.in_size + MDB_FOLD_HDR_SIZE);
        kvfree(in_buf);

        if (!folded_size) {
            kvfree(out_buf); ret = -EIO; break;
        }

        req.result_size = folded_size;

        /* Write req back (with result_size), then folded data */
        if (copy_to_user((void __user *)arg, &req, sizeof(req)) ||
            copy_to_user((void __user *)(arg + sizeof(req) + req.in_size),
                         out_buf, folded_size)) {
            kvfree(out_buf); ret = -EFAULT; break;
        }

        kvfree(out_buf);
        atomic64_inc(&stat_folds);
        atomic64_add(req.in_size, &stat_bytes_in);
        break;
    }

    /* ── MDB_UNFOLD: verify and strip header ── */
    case MDB_UNFOLD: {
        struct mdb_fold_req req;
        u8 *kbuf;
        const u8 *orig;
        u64 orig_len;

        if (copy_from_user(&req, (void __user *)arg, sizeof(req))) {
            ret = -EFAULT; break;
        }
        if (req.in_size < MDB_FOLD_HDR_SIZE || req.in_size > MDB_MAX_BUF) {
            ret = -EINVAL; break;
        }

        kbuf = kvmalloc(req.in_size, GFP_KERNEL);
        if (!kbuf) { ret = -ENOMEM; break; }

        if (copy_from_user(kbuf,
                           (void __user *)(arg + sizeof(struct mdb_fold_req)),
                           req.in_size)) {
            kvfree(kbuf); ret = -EFAULT; break;
        }

        orig = mdb_unfold(kbuf, req.in_size, &orig_len);
        if (!orig) {
            kvfree(kbuf); ret = -EBADMSG; break;
        }

        req.result_size = orig_len;
        if (copy_to_user((void __user *)arg, &req, sizeof(req)) ||
            copy_to_user((void __user *)(arg + sizeof(req) + req.in_size),
                         orig, orig_len)) {
            kvfree(kbuf); ret = -EFAULT; break;
        }

        kvfree(kbuf);
        atomic64_inc(&stat_unfolds);
        break;
    }

    /* ── MDB_EVOLVE: apply N evolve_steps to a bit array ── */
    case MDB_EVOLVE: {
        struct mdb_evolve_req req;
        u8 *bits;
        u64 i;

        if (copy_from_user(&req, (void __user *)arg, sizeof(req))) {
            ret = -EFAULT; break;
        }
        if (req.len == 0 || req.len > MDB_MAX_BITS) {
            ret = -EINVAL; break;
        }

        bits = kvmalloc(req.len, GFP_KERNEL);
        if (!bits) { ret = -ENOMEM; break; }

        if (copy_from_user(bits,
                           (void __user *)(arg + sizeof(req)),
                           req.len)) {
            kvfree(bits); ret = -EFAULT; break;
        }

        req.flipped = 0;
        for (i = 0; i < req.steps; i++)
            req.flipped = mdb_evolve_step(bits, req.len);

        if (copy_to_user((void __user *)arg, &req, sizeof(req)) ||
            copy_to_user((void __user *)(arg + sizeof(req)), bits, req.len)) {
            kvfree(bits); ret = -EFAULT; break;
        }

        kvfree(bits);
        atomic64_add(req.steps, &stat_evolves);
        break;
    }

    default:
        ret = -ENOTTY;
    }

    mutex_unlock(&sess->lock);
    return ret;
}

static const struct file_operations mdb_fops = {
    .owner          = THIS_MODULE,
    .open           = mdb_open,
    .release        = mdb_release,
    .unlocked_ioctl = mdb_ioctl,
    .llseek         = no_llseek,
};

/* ── /proc/mdb stats ─────────────────────────────────────────────────────── */

static int mdb_proc_show(struct seq_file *m, void *v)
{
    seq_printf(m, "mdb_version:    %d.%d\n",
               MDB_VERSION_MAJOR, MDB_VERSION_MINOR);
    seq_printf(m, "folds:          %lld\n", atomic64_read(&stat_folds));
    seq_printf(m, "unfolds:        %lld\n", atomic64_read(&stat_unfolds));
    seq_printf(m, "addr_calls:     %lld\n", atomic64_read(&stat_addr_calls));
    seq_printf(m, "evolve_steps:   %lld\n", atomic64_read(&stat_evolves));
    seq_printf(m, "bytes_processed:%lld\n", atomic64_read(&stat_bytes_in));
    seq_printf(m, "fold_overhead:  %d bytes per object\n", MDB_FOLD_HDR_SIZE);
    return 0;
}

static int mdb_proc_open(struct inode *inode, struct file *file)
{
    return single_open(file, mdb_proc_show, NULL);
}

static const struct proc_ops mdb_proc_ops = {
    .proc_open    = mdb_proc_open,
    .proc_read    = seq_read,
    .proc_lseek   = seq_lseek,
    .proc_release = single_release,
};

/* ── init / exit ─────────────────────────────────────────────────────────── */

int mdb_dev_init(void)
{
    int ret;
    dev_t devno;

    ret = alloc_chrdev_region(&devno, 0, 1, MDB_DEVNAME);
    if (ret < 0) return ret;
    mdb_major = MAJOR(devno);

    cdev_init(&mdb_cdev, &mdb_fops);
    mdb_cdev.owner = THIS_MODULE;
    ret = cdev_add(&mdb_cdev, devno, 1);
    if (ret) goto fail_cdev;

    mdb_class = class_create(MDB_CLASSNAME);
    if (IS_ERR(mdb_class)) { ret = PTR_ERR(mdb_class); goto fail_class; }

    if (IS_ERR(device_create(mdb_class, NULL, devno, NULL, MDB_DEVNAME))) {
        ret = -EIO; goto fail_device;
    }

    proc_create("mdb", 0444, NULL, &mdb_proc_ops);

    pr_info("mdb: /dev/mdb ready (major=%d)\n", mdb_major);
    pr_info("mdb: /proc/mdb stats ready\n");
    return 0;

fail_device:
    class_destroy(mdb_class);
fail_class:
    cdev_del(&mdb_cdev);
fail_cdev:
    unregister_chrdev_region(devno, 1);
    return ret;
}

void mdb_dev_exit(void)
{
    remove_proc_entry("mdb", NULL);
    device_destroy(mdb_class, MKDEV(mdb_major, 0));
    class_destroy(mdb_class);
    cdev_del(&mdb_cdev);
    unregister_chrdev_region(MKDEV(mdb_major, 0), 1);
    pr_info("mdb: removed\n");
}

# MDB AI - Quick Start Guide

Get up and running with MDB AI in 5 minutes.

## Desktop (Windows/Mac/Linux)

### 1. Install Python Dependencies
```bash
pip install -r requirements.txt
```

### 2. Run the App
```bash
python mdb_app.py
```

### 3. Start Chatting!
- Click the **Chat** tab
- Type a message and press **Send**
- The AI will respond

### 4. Train the Model (Optional)
- Click the **Training** tab
- Click **Quick Train** to download 100 Wikipedia articles
- Watch the progress bar
- Click **Save Model** when done

### 5. View Statistics
- Click the **Stats** tab to see network metrics

---

## Android (Pydroid 3)

### 1. Install Pydroid 3
- Download from Google Play Store
- Open and grant storage permissions

### 2. Copy Files
- Transfer all `.py` files to `/storage/emulated/0/Documents/MDB/`

### 3. Install Dependencies
In Pydroid 3 terminal:
```bash
pip install kivy kivymd matplotlib
```

### 4. Run the App
- Open Pydroid 3 File Manager
- Navigate to `/storage/emulated/0/Documents/MDB/`
- Tap `mdb_app.py` → **Run with Python**

### 5. Done!
The app is now running on your Android device.

---

## First Time Tips

### Chat Tab
- The AI starts with basic knowledge
- Ask questions to see it learn
- Responses improve after training

### Training Tab
- **Quick Train**: 100 articles, ~2 minutes
- **Full Train**: 1000 articles, ~10 minutes
- Always **Save Model** after training to avoid retraining

### Stats Tab
- Shows Language Model vocabulary size
- Shows Knowledge Base fact count
- Helps you understand the AI's capacity

---

## Common Questions

**Q: Why is the first response slow?**
A: The AI is initializing. Subsequent responses are faster.

**Q: Can I train without internet?**
A: No, training downloads Wikipedia articles. Chat works offline after training.

**Q: How do I save my progress?**
A: Click **Save Model** in the Training tab. Models are saved automatically on exit.

**Q: Can I use custom training data?**
A: Yes! Edit `mdb_train.py` to use your own texts instead of Wikipedia.

**Q: Is this the same as ChatGPT?**
A: No. MDB is a lightweight, offline AI using a novel binary representation system. It's designed for learning and research.

---

## Next Steps

1. **Explore the Chat**: Try different types of questions
2. **Train the Model**: Run training to expand the AI's knowledge
3. **Read the Docs**: Check `README.md` for advanced features
4. **Customize**: Modify the code to add your own knowledge

---

**Questions? Check the full README.md or PYDROID3_SETUP.md for detailed help.**

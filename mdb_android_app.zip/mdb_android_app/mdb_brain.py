"""
================================================================================
MDB BRAIN - Knowledge Base + Conversational Intelligence
================================================================================
The brain sits on top of the MDB Language Model and adds:
  - A knowledge base (facts stored as SuperBits, retrieved by keyword)
  - Conversation context memory
  - Intent classification
  - Response composition that sounds natural, not robotic
================================================================================
"""

import re
import random
import json
import hashlib
from typing import Dict, List, Optional, Tuple, Any
from collections import defaultdict, deque

try:
    from mdb_core import SuperBit, DimensionalIndex
    from mdb_lm import MDBLanguageModel
except ImportError as e:
    raise ImportError(f"Missing dependency: {e}")


# =============================================================================
# KNOWLEDGE BASE
# =============================================================================

class MDBKnowledge:
    """
    Stores facts as SuperBits. Each fact has:
      - A topic/entity name
      - Content text
      - Keywords
      - A confidence SuperBit

    Retrieval works by keyword overlap, returning the best matching facts.
    """

    def __init__(self):
        self.facts: Dict[str, Dict] = {}        # topic -> fact entry
        self.keyword_index: Dict[str, List[str]] = defaultdict(list)  # keyword -> [topics]
        self.count = 0

    def add(self, topic: str, content: str, confidence: float = 0.85,
            keywords: List[str] = None):
        """Add a fact to the knowledge base."""
        topic_clean = topic.lower().strip()

        if keywords is None:
            keywords = self._extract_keywords(topic + ' ' + content)

        # Store as SuperBit with confidence
        sb = SuperBit(
            num_states=2,
            labels=['true', 'uncertain'],
            weights=[confidence, 1.0 - confidence]
        )

        self.facts[topic_clean] = {
            'topic': topic,
            'content': content,
            'keywords': keywords,
            'superbit': sb,
            'confidence': confidence
        }

        # Index by keywords
        for kw in keywords:
            kw = kw.lower()
            if topic_clean not in self.keyword_index[kw]:
                self.keyword_index[kw].append(topic_clean)

        self.count += 1

    def _extract_keywords(self, text: str) -> List[str]:
        """Extract meaningful keywords from text."""
        # Simple keyword extraction: meaningful words > 3 chars
        stopwords = {
            'the', 'and', 'for', 'that', 'this', 'with', 'from', 'are',
            'was', 'were', 'has', 'have', 'had', 'not', 'but', 'they',
            'which', 'their', 'also', 'more', 'its', 'can', 'into',
            'than', 'been', 'when', 'who', 'what', 'how', 'why', 'where',
            'will', 'would', 'could', 'should', 'may', 'might', 'must',
            'one', 'two', 'three', 'some', 'any', 'all', 'most', 'other',
            'such', 'about', 'after', 'before', 'while', 'during', 'over',
            'under', 'between', 'through', 'known', 'used', 'based', 'part'
        }
        words = re.findall(r'\b[a-zA-Z]{3,}\b', text.lower())
        return [w for w in words if w not in stopwords][:20]

    def search(self, query: str, top_k: int = 5) -> List[Dict]:
        """Find the most relevant facts for a query."""
        query_keywords = set(self._extract_keywords(query))
        query_words = set(re.findall(r'\b[a-zA-Z]{2,}\b', query.lower()))

        scores: Dict[str, float] = defaultdict(float)

        # Score by keyword overlap
        for kw in query_keywords:
            for topic in self.keyword_index.get(kw, []):
                if topic in self.facts:
                    scores[topic] += 2.0

        # Also check direct word overlap with topic names
        for topic in self.facts:
            topic_words = set(topic.split())
            overlap = query_words & topic_words
            scores[topic] += len(overlap) * 3.0

        # Check content words too
        for topic, fact in self.facts.items():
            content_words = set(re.findall(r'\b[a-zA-Z]{3,}\b',
                                            fact['content'].lower()))
            overlap = query_words & content_words
            scores[topic] += len(overlap) * 0.5

        if not scores:
            return []

        # Sort and return top results
        ranked = sorted(scores.items(), key=lambda x: -x[1])[:top_k]
        results = []
        for topic, score in ranked:
            if score > 0 and topic in self.facts:
                entry = dict(self.facts[topic])
                entry['score'] = score
                results.append(entry)

        return results

    def get(self, topic: str) -> Optional[Dict]:
        """Get a fact by exact topic name."""
        return self.facts.get(topic.lower().strip())

    def to_dict(self) -> dict:
        return {
            'facts': {
                k: {
                    'topic': v['topic'],
                    'content': v['content'],
                    'keywords': v['keywords'],
                    'confidence': v['confidence'],
                    'superbit': v['superbit'].to_dict()
                }
                for k, v in self.facts.items()
            }
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'MDBKnowledge':
        kb = cls()
        for k, v in data.get('facts', {}).items():
            sb = SuperBit.from_dict(v['superbit'])
            kb.facts[k] = {
                'topic': v['topic'],
                'content': v['content'],
                'keywords': v['keywords'],
                'confidence': v['confidence'],
                'superbit': sb
            }
            for kw in v['keywords']:
                if k not in kb.keyword_index[kw.lower()]:
                    kb.keyword_index[kw.lower()].append(k)
            kb.count += 1
        return kb

    def save(self, filepath: str):
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(self.to_dict(), f, ensure_ascii=False)
        print(f"[KB] Saved {self.count} facts to {filepath}")

    @classmethod
    def load(cls, filepath: str) -> 'MDBKnowledge':
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        kb = cls.from_dict(data)
        print(f"[KB] Loaded {kb.count} facts from {filepath}")
        return kb


# =============================================================================
# CONVERSATION MEMORY
# =============================================================================

class ConversationMemory:
    """Tracks conversation history for context-aware responses."""

    def __init__(self, window: int = 10):
        self.turns: deque = deque(maxlen=window * 2)
        self.topic_stack: List[str] = []     # recent topics discussed
        self.mentioned: set = set()           # all topics ever mentioned

    def add(self, role: str, content: str, topic: str = None):
        self.turns.append({'role': role, 'content': content, 'topic': topic})
        if topic:
            if not self.topic_stack or self.topic_stack[-1] != topic:
                self.topic_stack.append(topic)
                if len(self.topic_stack) > 20:
                    self.topic_stack = self.topic_stack[-20:]
            self.mentioned.add(topic)

    def current_topic(self) -> Optional[str]:
        return self.topic_stack[-1] if self.topic_stack else None

    def recent_text(self, n: int = 4) -> str:
        recent = list(self.turns)[-n:]
        return ' '.join(t['content'] for t in recent)

    def clear(self):
        self.turns.clear()
        self.topic_stack.clear()
        self.mentioned.clear()


# =============================================================================
# MDB BRAIN
# =============================================================================

class MDBBrain:
    """
    The conversational intelligence layer.

    Flow for each user message:
      1. Classify intent (greeting, question, statement, etc.)
      2. Extract topic/keywords
      3. Search knowledge base for relevant facts
      4. Compose a natural response:
         - Factual questions  -> KB answer + LM elaboration
         - Unknown topics     -> LM generation from context
         - Greetings/social   -> Template responses
      5. Update conversation memory
    """

    GREETINGS = ['hi', 'hello', 'hey', 'howdy', 'greetings', 'sup', "what's up",
                 'good morning', 'good afternoon', 'good evening']
    FAREWELLS = ['bye', 'goodbye', 'see you', 'later', 'cya', 'farewell', 'quit', 'exit']
    THANKS    = ['thanks', 'thank you', 'thx', 'ty', 'appreciate']

    GREETING_RESPONSES = [
        "Hey! What's on your mind?",
        "Hello! What would you like to talk about?",
        "Hi there! Ask me anything.",
        "Hey! What can I help you with?",
        "Hello! What are you curious about today?",
    ]

    FAREWELL_RESPONSES = [
        "Take it easy!",
        "See you around.",
        "Later!",
        "Goodbye!",
        "Until next time.",
    ]

    THANKS_RESPONSES = [
        "Of course.",
        "Happy to help.",
        "No problem at all.",
        "Anytime.",
        "Sure thing.",
    ]

    UNSURE_RESPONSES = [
        "I don't have solid info on that yet. {follow}",
        "That's outside what I've been trained on so far. {follow}",
        "I'm not sure about that one. {follow}",
        "I don't have enough on that topic. {follow}",
    ]

    FOLLOW_UPS = [
        "Want to try a different question?",
        "Is there something else you'd like to know?",
        "Try asking about something else and I'll do my best.",
        "What else are you curious about?",
    ]

    def __init__(self, name: str = "MDB"):
        self.name = name
        self.knowledge = MDBKnowledge()
        self.memory = ConversationMemory(window=12)
        self.lm: Optional[MDBLanguageModel] = None
        self._last_topics_used: List[str] = []

    def set_lm(self, lm: MDBLanguageModel):
        """Attach a trained language model."""
        self.lm = lm

    def teach(self, topic: str, content: str, confidence: float = 0.85,
              keywords: List[str] = None):
        """Teach the brain a fact."""
        self.knowledge.add(topic, content, confidence, keywords)

    # -------------------------------------------------------------------------
    # INTENT CLASSIFICATION
    # -------------------------------------------------------------------------

    def _classify_intent(self, text: str) -> str:
        """Classify the intent of user input."""
        lower = text.lower().strip()

        # Check for farewells
        for phrase in self.FAREWELLS:
            if re.search(r'\b' + re.escape(phrase) + r'\b', lower):
                return 'farewell'

        # Check for greetings
        for phrase in self.GREETINGS:
            if lower.startswith(phrase) or lower == phrase:
                return 'greeting'

        # Check for thanks
        for phrase in self.THANKS:
            if re.search(r'\b' + re.escape(phrase) + r'\b', lower):
                return 'thanks'

        # Question detection
        question_words = ['what', 'who', 'where', 'when', 'why', 'how', 'which',
                          'can you', 'do you', 'is it', 'are there', 'tell me',
                          'explain', 'describe', 'define']
        if text.rstrip().endswith('?'):
            return 'question'
        for qw in question_words:
            if lower.startswith(qw):
                return 'question'

        return 'statement'

    def _extract_topic(self, text: str) -> str:
        """Extract the main topic from the input."""
        # Remove question words to get to the subject
        clean = re.sub(
            r'^(what is|what are|who is|who are|where is|where are|when is|'
            r'how does|how is|why is|why are|tell me about|explain|describe|'
            r'define|can you explain|do you know about|what do you know about)\s+',
            '', text.lower().strip(), flags=re.IGNORECASE
        )
        clean = re.sub(r'[?.!,;]', '', clean).strip()
        # Remove articles
        clean = re.sub(r'^(a |an |the )', '', clean).strip()
        return clean if clean else text.lower().strip()

    # -------------------------------------------------------------------------
    # RESPONSE GENERATION
    # -------------------------------------------------------------------------

    def _compose_kb_response(self, facts: List[Dict], query: str) -> str:
        """Compose a natural response from retrieved knowledge base facts."""
        if not facts:
            return ""

        best = facts[0]
        content = best['content'].strip()

        # Add elaboration from secondary facts if available
        extras = []
        for f in facts[1:3]:
            if f['topic'].lower() != best['topic'].lower():
                # Only add if clearly different topic
                first_sentence = re.split(r'[.!?]', f['content'])[0].strip()
                if first_sentence and len(first_sentence) > 20:
                    extras.append(first_sentence)

        response = content

        # Sometimes add the topic explicitly for clarity
        topic_name = best['topic']
        if not any(word in content.lower() for word in
                   re.findall(r'\b\w{4,}\b', topic_name.lower())):
            response = f"{topic_name}: {content}"

        # Add elaboration from LM if available
        if self.lm and self.lm.trained and len(response) < 120:
            try:
                # Use the main fact as a seed for LM continuation
                words = self.lm.tokenizer.tokenize(content)
                if len(words) >= 3:
                    seed_tokens = words[:min(len(words), 6)]
                    seed = ' '.join(seed_tokens)
                    extra = self.lm.generate(
                        seed=seed,
                        max_tokens=25,
                        temperature=0.75
                    )
                    if extra and extra != seed and len(extra) > len(seed) + 10:
                        # Only append if LM added something meaningful
                        extra_clean = extra[len(seed):].strip()
                        if extra_clean and len(extra_clean) > 15:
                            response = response.rstrip('.') + '. ' + extra_clean.capitalize()
            except Exception:
                pass  # LM generation failed, use KB response as-is

        # Occasionally add a follow-up question to keep conversation going
        if random.random() < 0.25 and len(response) < 200:
            follow_ups = [
                f" Want to know more about {topic_name}?",
                " Anything specific you'd like to explore?",
                " Is there a particular aspect you're curious about?",
            ]
            response = response.rstrip() + random.choice(follow_ups)

        return response

    def _lm_response(self, query: str) -> str:
        """Generate a response using the language model when KB has nothing."""
        if not self.lm or not self.lm.trained:
            return ""
        try:
            topic = self._extract_topic(query)
            seed = topic if topic else query[:50]
            generated = self.lm.generate(
                seed=seed,
                max_tokens=50,
                temperature=0.85
            )
            if generated and len(generated) > 20:
                return generated
        except Exception:
            pass
        return ""

    def _unknown_response(self, topic: str) -> str:
        """Fallback response when nothing is found."""
        follow = random.choice(self.FOLLOW_UPS)
        template = random.choice(self.UNSURE_RESPONSES)
        return template.format(follow=follow)

    # -------------------------------------------------------------------------
    # MAIN RESPOND METHOD
    # -------------------------------------------------------------------------

    def respond(self, user_input: str) -> str:
        """Generate a response to user input."""
        user_input = user_input.strip()
        if not user_input:
            return "Go ahead, I'm listening."

        intent = self._classify_intent(user_input)
        topic = self._extract_topic(user_input)

        # Update memory
        self.memory.add('user', user_input, topic=topic)

        # Route by intent
        if intent == 'greeting':
            response = random.choice(self.GREETING_RESPONSES)

        elif intent == 'farewell':
            response = random.choice(self.FAREWELL_RESPONSES)

        elif intent == 'thanks':
            response = random.choice(self.THANKS_RESPONSES)

        else:
            # Search knowledge base
            facts = self.knowledge.search(user_input, top_k=5)

            # Also try searching with extracted topic
            if not facts and topic != user_input.lower():
                facts = self.knowledge.search(topic, top_k=5)

            # Also try current conversation topic if still vague
            if not facts and self.memory.current_topic():
                ctx_topic = self.memory.current_topic()
                facts = self.knowledge.search(
                    ctx_topic + ' ' + user_input, top_k=3
                )

            if facts:
                response = self._compose_kb_response(facts, user_input)
            else:
                # Try LM
                lm_response = self._lm_response(user_input)
                if lm_response and len(lm_response) > 25:
                    response = lm_response
                else:
                    response = self._unknown_response(topic)

        # Update memory with response
        self.memory.add('ai', response, topic=topic)

        return response

    # -------------------------------------------------------------------------
    # SAVE / LOAD
    # -------------------------------------------------------------------------

    def save(self, filepath: str):
        """Save brain state (knowledge base)."""
        self.knowledge.save(filepath)

    def load_knowledge(self, filepath: str):
        """Load knowledge base from file."""
        self.knowledge = MDBKnowledge.load(filepath)

    def stats(self) -> dict:
        return {
            'name': self.name,
            'knowledge_facts': self.knowledge.count,
            'conversation_turns': len(self.memory.turns),
            'lm_attached': self.lm is not None and self.lm.trained,
            'lm_stats': self.lm.stats() if self.lm else None
        }

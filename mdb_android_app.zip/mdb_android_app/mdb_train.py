"""
================================================================================
MDB TRAINING PIPELINE
================================================================================
Downloads Wikipedia article summaries, encodes everything into MDB format.
Run once to train. After training, no internet needed.

Usage:
  python mdb_train.py              # Train with default settings
  python mdb_train.py --fast       # Quick training (~500 articles)
  python mdb_train.py --full       # Full training (~5000 articles)
  python mdb_train.py --topics     # Train on specific topic list
================================================================================
"""

import sys
import json
import time
import re
import os
import urllib.request
import urllib.parse
import urllib.error
from typing import List, Dict, Tuple, Optional

try:
    from mdb_lm import MDBLanguageModel
    from mdb_brain import MDBBrain, MDBKnowledge
except ImportError as e:
    print(f"Error: {e}")
    print("Make sure mdb_lm.py, mdb_brain.py, and mdb_core.py are in the same folder.")
    sys.exit(1)


# =============================================================================
# WIKIPEDIA FETCHER
# =============================================================================

class WikipediaFetcher:
    """Fetches article summaries from Wikipedia's free REST API."""

    SUMMARY_URL = "https://en.wikipedia.org/api/rest_v1/page/summary/{}"
    RANDOM_URL  = "https://en.wikipedia.org/api/rest_v1/page/random/summary"
    SEARCH_URL  = "https://en.wikipedia.org/w/api.php"
    HEADERS = {
        'User-Agent': 'MDB-AI-Trainer/1.0 (Educational project; contact: mdb@example.com)'
    }

    def fetch_summary(self, title: str) -> Optional[Dict]:
        """Fetch summary for a single Wikipedia article."""
        try:
            encoded = urllib.parse.quote(title.replace(' ', '_'))
            url = self.SUMMARY_URL.format(encoded)
            req = urllib.request.Request(url, headers=self.HEADERS)
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                if 'extract' in data and len(data['extract']) > 50:
                    return {
                        'title': data.get('title', title),
                        'extract': data['extract'],
                        'description': data.get('description', '')
                    }
        except Exception:
            pass
        return None

    def fetch_random(self) -> Optional[Dict]:
        """Fetch a random Wikipedia article summary."""
        try:
            req = urllib.request.Request(self.RANDOM_URL, headers=self.HEADERS)
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                if 'extract' in data and len(data['extract']) > 50:
                    return {
                        'title': data.get('title', 'Unknown'),
                        'extract': data['extract'],
                        'description': data.get('description', '')
                    }
        except Exception:
            pass
        return None

    def search_articles(self, query: str, limit: int = 10) -> List[str]:
        """Search for Wikipedia article titles matching a query."""
        try:
            params = urllib.parse.urlencode({
                'action': 'query',
                'list': 'search',
                'srsearch': query,
                'srlimit': limit,
                'format': 'json'
            })
            url = f"{self.SEARCH_URL}?{params}"
            req = urllib.request.Request(url, headers=self.HEADERS)
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                results = data.get('query', {}).get('search', [])
                return [r['title'] for r in results]
        except Exception:
            return []

    def fetch_category(self, category: str, limit: int = 50) -> List[str]:
        """Get article titles from a Wikipedia category."""
        try:
            params = urllib.parse.urlencode({
                'action': 'query',
                'list': 'categorymembers',
                'cmtitle': f'Category:{category}',
                'cmlimit': limit,
                'cmtype': 'page',
                'format': 'json'
            })
            url = f"{self.SEARCH_URL}?{params}"
            req = urllib.request.Request(url, headers=self.HEADERS)
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                members = data.get('query', {}).get('categorymembers', [])
                return [m['title'] for m in members]
        except Exception:
            return []


# =============================================================================
# TRAINING DATA BUILDER
# =============================================================================

# Topics to seed the training with
SEED_TOPICS = [
    # Science
    "Physics", "Chemistry", "Biology", "Mathematics", "Astronomy",
    "Quantum mechanics", "Evolution", "DNA", "Relativity", "Thermodynamics",
    "Photosynthesis", "Gravity", "Electricity", "Magnetism", "Atom",
    "Molecule", "Cell biology", "Genetics", "Ecology", "Neuroscience",
    # Technology
    "Artificial intelligence", "Computer", "Internet", "Software",
    "Algorithm", "Machine learning", "Robot", "Smartphone", "Satellite",
    "Nuclear power", "Solar energy", "Battery", "Semiconductor", "Laser",
    # History
    "World War II", "French Revolution", "Roman Empire", "Ancient Egypt",
    "Industrial Revolution", "Renaissance", "Cold War", "Space Race",
    "American Revolution", "Ancient Greece", "Byzantine Empire",
    # Geography
    "Amazon rainforest", "Sahara Desert", "Mount Everest", "Pacific Ocean",
    "Africa", "Europe", "Asia", "North America", "South America",
    "Atlantic Ocean", "Antarctica", "Arctic", "Mediterranean Sea",
    # People (broad topics)
    "Isaac Newton", "Albert Einstein", "Marie Curie", "Charles Darwin",
    "Leonardo da Vinci", "Aristotle", "Galileo Galilei", "Nikola Tesla",
    "Alan Turing", "Stephen Hawking",
    # Arts & Culture
    "Music", "Art", "Literature", "Philosophy", "Psychology",
    "Mythology", "Religion", "Language", "Architecture", "Cinema",
    # Health
    "Medicine", "Human body", "Brain", "Heart", "Immune system",
    "Virus", "Bacteria", "Vaccine", "Nutrition", "Exercise",
    # General
    "Democracy", "Economics", "Climate change", "Ocean", "Atmosphere",
    "Water", "Fire", "Time", "Light", "Sound",
]

# Extended topic list for fuller training
EXTENDED_TOPICS = SEED_TOPICS + [
    "Plate tectonics", "Volcano", "Earthquake", "Hurricane", "Tornado",
    "Black hole", "Galaxy", "Solar system", "Moon", "Mars",
    "Photon", "Electron", "Proton", "Neutron", "Quark",
    "Python programming", "Programming language", "Operating system",
    "Database", "Encryption", "Network protocol",
    "Shakespeare", "Beethoven", "Mozart", "Picasso", "Michelangelo",
    "Buddhism", "Islam", "Christianity", "Hinduism",
    "Capitalism", "Socialism", "Communism",
    "United Nations", "World Trade Organization",
    "Carbon dioxide", "Oxygen", "Hydrogen", "Nitrogen",
    "Tiger", "Elephant", "Whale", "Eagle", "Shark",
    "Forest", "Coral reef", "Wetland", "Prairie",
    "Photovoltaic cell", "Wind turbine", "Fossil fuel",
    "Memory", "Consciousness", "Dream", "Emotion",
    "Antibiotic", "Cancer", "Diabetes", "Heart disease",
]


def clean_text(text: str) -> str:
    """Clean extracted Wikipedia text."""
    # Remove parenthetical references like (1970–2020)
    text = re.sub(r'\s*\([^)]{0,50}\)', '', text)
    # Remove citation markers
    text = re.sub(r'\[\d+\]', '', text)
    # Fix spacing
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def split_sentences(text: str) -> List[str]:
    """Split text into sentences."""
    sentences = re.split(r'(?<=[.!?])\s+', text)
    return [s.strip() for s in sentences if len(s.strip()) > 20]


def build_training_data(
    num_articles: int = 1000,
    verbose: bool = True,
    cache_file: str = "mdb_training_cache.json"
) -> Tuple[List[str], List[Dict]]:
    """
    Fetch Wikipedia articles and return:
      - texts: List of sentences for LM training
      - facts: List of {title, content} for KB

    Results are cached to avoid re-downloading.
    """

    # Load cache if it exists
    if os.path.exists(cache_file):
        if verbose:
            print(f"[TRAIN] Loading cached training data from {cache_file}...")
        with open(cache_file, 'r', encoding='utf-8') as f:
            cache = json.load(f)
        articles = cache.get('articles', [])
        if verbose:
            print(f"[TRAIN] Loaded {len(articles)} cached articles.")
        if len(articles) >= num_articles:
            articles = articles[:num_articles]
            texts = []
            facts = []
            for art in articles:
                sentences = split_sentences(clean_text(art['extract']))
                texts.extend(sentences)
                if sentences:
                    facts.append({
                        'title': art['title'],
                        'content': ' '.join(sentences[:3])
                    })
            return texts, facts

    if verbose:
        print(f"[TRAIN] Fetching {num_articles} Wikipedia articles...")

    fetcher = WikipediaFetcher()
    articles = []
    fetched_titles = set()

    # First, try seeded topics
    topics_to_try = (EXTENDED_TOPICS if num_articles > 200 else SEED_TOPICS)[:]
    random_fill_needed = max(0, num_articles - len(topics_to_try))

    for i, topic in enumerate(topics_to_try):
        if len(articles) >= num_articles:
            break
        if topic in fetched_titles:
            continue

        article = fetcher.fetch_summary(topic)
        if article:
            articles.append(article)
            fetched_titles.add(article['title'])
            if verbose and (i + 1) % 50 == 0:
                print(f"[TRAIN]   {len(articles)}/{num_articles} articles...")
        time.sleep(0.05)  # Be polite to Wikipedia's servers

    # Fill remaining with random articles
    fails = 0
    while len(articles) < num_articles and fails < 100:
        article = fetcher.fetch_random()
        if article and article['title'] not in fetched_titles:
            articles.append(article)
            fetched_titles.add(article['title'])
            if verbose and len(articles) % 100 == 0:
                print(f"[TRAIN]   {len(articles)}/{num_articles} articles...")
            fails = 0
        else:
            fails += 1
        time.sleep(0.05)

    # Save to cache
    if verbose:
        print(f"[TRAIN] Saving {len(articles)} articles to cache...")
    with open(cache_file, 'w', encoding='utf-8') as f:
        json.dump({'articles': articles}, f, ensure_ascii=False)

    # Convert to texts and facts
    texts = []
    facts = []
    for art in articles:
        sentences = split_sentences(clean_text(art['extract']))
        texts.extend(sentences)
        if sentences:
            facts.append({
                'title': art['title'],
                'content': ' '.join(sentences[:3])
            })

    if verbose:
        print(f"[TRAIN] Total sentences: {len(texts):,}")
        print(f"[TRAIN] Total facts: {len(facts):,}")

    return texts, facts


# =============================================================================
# MAIN TRAINING FUNCTION
# =============================================================================

def train(
    num_articles: int = 1000,
    lm_n: int = 3,
    output_lm: str = "mdb_model.json",
    output_kb: str = "mdb_knowledge.json",
    verbose: bool = True
):
    """Full training pipeline."""

    print("=" * 60)
    print("  MDB AI Training Pipeline")
    print("=" * 60)
    print(f"  Articles: {num_articles}")
    print(f"  N-gram order: {lm_n}")
    print(f"  LM output: {output_lm}")
    print(f"  KB output: {output_kb}")
    print("=" * 60)
    print()

    # Step 1: Fetch training data
    print("[STEP 1/3] Fetching training data from Wikipedia...")
    texts, facts = build_training_data(num_articles=num_articles, verbose=verbose)

    if not texts:
        print("ERROR: No training data fetched. Check your internet connection.")
        sys.exit(1)

    # Step 2: Train language model
    print(f"\n[STEP 2/3] Training MDB Language Model...")
    lm = MDBLanguageModel(n=lm_n, name="mdb_lm")
    lm.train(texts, verbose=verbose)
    lm.save(output_lm)

    # Step 3: Build knowledge base
    print(f"\n[STEP 3/3] Building Knowledge Base...")
    kb = MDBKnowledge()
    for fact in facts:
        kb.add(
            topic=fact['title'],
            content=fact['content'],
            confidence=0.9
        )
    kb.save(output_kb)

    print("\n" + "=" * 60)
    print("  Training Complete!")
    print("=" * 60)
    lm_stats = lm.stats()
    print(f"  Vocabulary:  {lm_stats['vocab_size']:,} words")
    print(f"  Contexts:    {lm_stats['total_contexts']:,} SuperBits")
    print(f"  Facts (KB):  {kb.count:,} entries")
    print(f"\n  Run: python mdb_chat_v2.py")
    print("=" * 60)


# =============================================================================
# ENTRY POINT
# =============================================================================

if __name__ == "__main__":
    args = sys.argv[1:]

    if '--fast' in args:
        train(num_articles=300, lm_n=3)
    elif '--full' in args:
        train(num_articles=5000, lm_n=3)
    elif '--small' in args:
        train(num_articles=100, lm_n=2)
    else:
        # Default: balanced
        train(num_articles=1000, lm_n=3)

"""
================================================================================
MDB AI - Professional Android Application
================================================================================
A complete, production-ready Kivy/KivyMD application for the MDB AI system.
Designed for Pydroid 3 and modern Android devices.

FEATURES:
    - Modern Material Design UI with bottom navigation
    - Real-time chat interface with message bubbles
    - Multi-chapter training system with progress tracking
    - Core statistics and network visualization
    - Full offline operation
    - State persistence across sessions

ARCHITECTURE:
    - Tab 1: Chat Interface (talk to MDB Brain)
    - Tab 2: Training Hub (run chapters, track progress)
    - Tab 3: Core Statistics (view network state)
    - Background threads for non-blocking operations
================================================================================
"""

import os
import sys
import json
import time
import threading
from datetime import datetime
from pathlib import Path
from collections import deque

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.image import Image
from kivy.uix.popup import Popup
from kivy.uix.progressbar import ProgressBar
from kivy.uix.spinner import Spinner
from kivy.uix.checkbox import CheckBox
from kivy.uix.togglebutton import ToggleButton
from kivy.garden.navigationdrawer import NavigationDrawer
from kivy.uix.tabbedpanel import TabbedPanel, TabbedPanelItem
from kivy.uix.anchorlayout import AnchorLayout
from kivy.clock import Clock, mainthread
from kivy.properties import NumericProperty, StringProperty, BooleanProperty
from kivy.core.window import Window
from kivy.garden.matplotlib.backend_kivyagg import FigureCanvasKivyAgg
import matplotlib.pyplot as plt

# Set window size for development/testing
Window.size = (540, 960)

# Try to import KivyMD for Material Design
try:
    from kivymd.app import MDApp
    from kivymd.uix.boxlayout import MDBoxLayout
    from kivymd.uix.gridlayout import MDGridLayout
    from kivymd.uix.label import MDLabel
    from kivymd.uix.button import MDRaisedButton, MDFlatButton
    from kivymd.uix.textfield import MDTextField
    from kivymd.uix.progressbar import MDProgressBar
    from kivymd.uix.card import MDCard
    from kivymd.uix.scrollview import MDScrollView
    from kivymd.uix.navigationdrawer import MDNavigationDrawer, MDNavigationLayout
    from kivymd.uix.bottomnavigation import MDBottomNavigation, MDBottomNavigationItem
    from kivymd.color_definitions import colors
    from kivymd.uix.theme_manager import ThemeManager
    HAS_KIVYMD = True
except ImportError:
    HAS_KIVYMD = False
    print("[WARN] KivyMD not available. Using basic Kivy widgets.")

# Import MDB components
try:
    from mdb_brain import MDBBrain
    from mdb_lm import MDBLanguageModel
    from mdb_train import build_training_data
except ImportError as e:
    print(f"[ERROR] Failed to import MDB components: {e}")
    sys.exit(1)


# ============================================================================
# CONFIGURATION
# ============================================================================

class MDBConfig:
    """Configuration for MDB Android app."""
    
    # Paths
    if sys.platform == 'android':
        BASE_PATH = '/storage/emulated/0/Documents/MDB'
    else:
        BASE_PATH = str(Path.home() / '.mdb')
    
    DATA_PATH = os.path.join(BASE_PATH, 'data')
    MODELS_PATH = os.path.join(BASE_PATH, 'models')
    TRAINING_PATH = os.path.join(BASE_PATH, 'training')
    
    # File names
    KB_FILE = os.path.join(DATA_PATH, 'knowledge_base.json')
    LM_FILE = os.path.join(MODELS_PATH, 'language_model.json')
    TRAINING_STATE_FILE = os.path.join(TRAINING_PATH, 'training_state.json')
    CHAT_HISTORY_FILE = os.path.join(DATA_PATH, 'chat_history.json')
    
    # Ensure directories exist
    @staticmethod
    def init():
        for path in [MDBConfig.DATA_PATH, MDBConfig.MODELS_PATH, MDBConfig.TRAINING_PATH]:
            os.makedirs(path, exist_ok=True)


# ============================================================================
# MESSAGE BUBBLE WIDGET
# ============================================================================

class MessageBubble(BoxLayout):
    """A single message bubble in the chat."""
    
    def __init__(self, text, is_user=True, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'horizontal'
        self.size_hint_y = None
        self.padding = 10
        self.spacing = 10
        
        # Spacer on one side
        if is_user:
            self.add_widget(Label(size_hint_x=0.2))
        
        # Message bubble
        bubble = BoxLayout(orientation='vertical', size_hint_x=0.8)
        bubble.canvas.before.clear()
        
        msg_label = Label(
            text=text,
            size_hint_y=None,
            markup=True,
            text_size=(300, None),
            color=(1, 1, 1, 1) if is_user else (0.2, 0.2, 0.2, 1)
        )
        msg_label.bind(texture_size=msg_label.setter('size'))
        
        bubble.add_widget(msg_label)
        
        # Set bubble background color
        if is_user:
            bubble.canvas.before.clear()
            from kivy.graphics import Color, RoundedRectangle
            with bubble.canvas.before:
                Color(0.2, 0.6, 1.0, 1.0)  # Blue for user
                RoundedRectangle(size=bubble.size, pos=bubble.pos, radius=[15])
        else:
            bubble.canvas.before.clear()
            from kivy.graphics import Color, RoundedRectangle
            with bubble.canvas.before:
                Color(0.9, 0.9, 0.9, 1.0)  # Light gray for AI
                RoundedRectangle(size=bubble.size, pos=bubble.pos, radius=[15])
        
        self.add_widget(bubble)
        
        # Spacer on other side
        if not is_user:
            self.add_widget(Label(size_hint_x=0.2))
        
        # Calculate height
        self.height = max(60, msg_label.texture_size[1] + 40)


# ============================================================================
# CHAT TAB
# ============================================================================

class ChatTab(BoxLayout):
    """Chat interface for talking to MDB Brain."""
    
    def __init__(self, brain, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.padding = 10
        self.spacing = 10
        
        self.brain = brain
        self.chat_history = deque(maxlen=100)
        
        # Title
        title = Label(text='[b]MDB Chat[/b]', markup=True, size_hint_y=0.08, font_size='20sp')
        self.add_widget(title)
        
        # Chat area (scrollable)
        self.chat_scroll = ScrollView(size_hint_y=0.75)
        self.chat_box = GridLayout(cols=1, spacing=5, size_hint_y=None, padding=5)
        self.chat_box.bind(minimum_height=self.chat_box.setter('height'))
        self.chat_scroll.add_widget(self.chat_box)
        self.add_widget(self.chat_scroll)
        
        # Input area
        input_layout = BoxLayout(orientation='horizontal', size_hint_y=0.15, spacing=5)
        self.input_field = TextInput(
            multiline=False,
            hint_text='Type your message...',
            size_hint_x=0.85
        )
        send_btn = Button(text='Send', size_hint_x=0.15)
        send_btn.bind(on_press=self.send_message)
        
        input_layout.add_widget(self.input_field)
        input_layout.add_widget(send_btn)
        self.add_widget(input_layout)
        
        # Add welcome message
        self.add_chat_message("Hello! I'm MDB, your AI companion. Ask me anything!", is_user=False)
    
    def add_chat_message(self, text, is_user=True):
        """Add a message to the chat display."""
        bubble = MessageBubble(text, is_user=is_user, size_hint_y=None)
        self.chat_box.add_widget(bubble)
        self.chat_history.append({'role': 'user' if is_user else 'ai', 'text': text})
        
        # Auto-scroll to bottom
        Clock.schedule_once(lambda dt: self.chat_scroll.scroll_y(0), 0.1)
    
    def send_message(self, instance):
        """Send a message and get a response."""
        msg = self.input_field.text.strip()
        if not msg:
            return
        
        # Add user message
        self.add_chat_message(msg, is_user=True)
        self.input_field.text = ''
        
        # Show thinking indicator
        self.add_chat_message('🤔 Thinking...', is_user=False)
        
        # Get response in background thread
        thread = threading.Thread(target=self._get_response, args=(msg,), daemon=True)
        thread.start()
    
    def _get_response(self, user_input):
        """Get AI response (runs in background)."""
        try:
            response = self.brain.respond(user_input)
        except Exception as e:
            response = f"Error: {str(e)}"
        
        # Update UI on main thread
        Clock.schedule_once(lambda dt: self._update_response(response), 0)
    
    @mainthread
    def _update_response(self, response):
        """Update the chat with the AI response."""
        # Remove thinking indicator
        if self.chat_box.children:
            self.chat_box.remove_widget(self.chat_box.children[0])
        
        # Add actual response
        self.add_chat_message(response, is_user=False)


# ============================================================================
# TRAINING TAB
# ============================================================================

class TrainingTab(BoxLayout):
    """Training interface for running chapters."""
    
    def __init__(self, lm, brain, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.padding = 10
        self.spacing = 10
        
        self.lm = lm
        self.brain = brain
        self.training_active = False
        
        # Title
        title = Label(text='[b]Training Hub[/b]', markup=True, size_hint_y=0.08, font_size='20sp')
        self.add_widget(title)
        
        # Training info
        info_box = BoxLayout(orientation='vertical', size_hint_y=0.15, spacing=5)
        self.status_label = Label(text='Status: Ready', size_hint_y=0.5)
        self.progress_label = Label(text='Progress: 0%', size_hint_y=0.5)
        info_box.add_widget(self.status_label)
        info_box.add_widget(self.progress_label)
        self.add_widget(info_box)
        
        # Progress bar
        self.progress_bar = ProgressBar(max=100, value=0, size_hint_y=0.08)
        self.add_widget(self.progress_bar)
        
        # Training options
        options_box = BoxLayout(orientation='vertical', size_hint_y=0.35, spacing=5)
        
        # Article count selector
        count_layout = BoxLayout(orientation='horizontal', size_hint_y=0.25, spacing=5)
        count_layout.add_widget(Label(text='Articles:', size_hint_x=0.3))
        self.article_spinner = Spinner(
            text='100',
            values=('50', '100', '500', '1000'),
            size_hint_x=0.7
        )
        count_layout.add_widget(self.article_spinner)
        options_box.add_widget(count_layout)
        
        # Training buttons
        btn_layout = BoxLayout(orientation='horizontal', size_hint_y=0.75, spacing=5)
        
        quick_train_btn = Button(text='Quick Train\n(100 articles)', size_hint_x=0.5)
        quick_train_btn.bind(on_press=self.start_quick_training)
        
        full_train_btn = Button(text='Full Train\n(1000 articles)', size_hint_x=0.5)
        full_train_btn.bind(on_press=self.start_full_training)
        
        btn_layout.add_widget(quick_train_btn)
        btn_layout.add_widget(full_train_btn)
        options_box.add_widget(btn_layout)
        
        self.add_widget(options_box)
        
        # Training log (scrollable)
        self.log_scroll = ScrollView(size_hint_y=0.35)
        self.log_box = GridLayout(cols=1, spacing=2, size_hint_y=None, padding=5)
        self.log_box.bind(minimum_height=self.log_box.setter('height'))
        self.log_scroll.add_widget(self.log_box)
        self.add_widget(self.log_scroll)
        
        # Control buttons
        ctrl_layout = BoxLayout(orientation='horizontal', size_hint_y=0.08, spacing=5)
        
        save_btn = Button(text='Save Model', size_hint_x=0.5)
        save_btn.bind(on_press=self.save_model)
        
        clear_btn = Button(text='Clear Log', size_hint_x=0.5)
        clear_btn.bind(on_press=self.clear_log)
        
        ctrl_layout.add_widget(save_btn)
        ctrl_layout.add_widget(clear_btn)
        self.add_widget(ctrl_layout)
    
    def log_message(self, msg):
        """Add a message to the training log."""
        log_label = Label(
            text=msg,
            size_hint_y=None,
            height=30,
            text_size=(400, None),
            markup=True
        )
        self.log_box.add_widget(log_label)
    
    def start_quick_training(self, instance):
        """Start quick training (100 articles)."""
        self.start_training(100)
    
    def start_full_training(self, instance):
        """Start full training (1000 articles)."""
        self.start_training(1000)
    
    def start_training(self, num_articles):
        """Start training in background."""
        if self.training_active:
            self.log_message('[color=ff0000]Training already in progress![/color]')
            return
        
        self.training_active = True
        self.status_label.text = f'Status: Training ({num_articles} articles)'
        self.log_message(f'[b]Starting training with {num_articles} articles...[/b]')
        
        thread = threading.Thread(
            target=self._run_training,
            args=(num_articles,),
            daemon=True
        )
        thread.start()
    
    def _run_training(self, num_articles):
        """Run training in background thread."""
        try:
            self.log_message('Fetching Wikipedia articles...')
            texts, facts = build_training_data(num_articles=num_articles, verbose=False)
            
            self.log_message(f'Fetched {len(texts)} sentences from {len(facts)} articles.')
            self.log_message('Training language model...')
            
            # Train LM
            self.lm.train(texts, verbose=False)
            
            # Add facts to brain
            self.log_message('Adding facts to knowledge base...')
            for fact in facts:
                self.brain.knowledge.add(fact['title'], fact['content'])
            
            self.progress_bar.value = 100
            self.status_label.text = 'Status: Training Complete!'
            self.log_message('[color=00ff00]✅ Training complete![/color]')
            
        except Exception as e:
            self.log_message(f'[color=ff0000]Error: {str(e)}[/color]')
            self.status_label.text = 'Status: Error'
        
        finally:
            self.training_active = False
    
    def save_model(self, instance):
        """Save the trained model."""
        try:
            MDBConfig.init()
            self.lm.save(MDBConfig.LM_FILE)
            self.brain.knowledge.save(MDBConfig.KB_FILE)
            self.log_message('[color=00ff00]✅ Model saved successfully![/color]')
        except Exception as e:
            self.log_message(f'[color=ff0000]Save error: {str(e)}[/color]')
    
    def clear_log(self, instance):
        """Clear the training log."""
        self.log_box.clear_widgets()


# ============================================================================
# STATS TAB
# ============================================================================

class StatsTab(BoxLayout):
    """Statistics and network visualization."""
    
    def __init__(self, lm, brain, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.padding = 10
        self.spacing = 10
        
        self.lm = lm
        self.brain = brain
        
        # Title
        title = Label(text='[b]Network Statistics[/b]', markup=True, size_hint_y=0.08, font_size='20sp')
        self.add_widget(title)
        
        # Stats display (scrollable)
        self.stats_scroll = ScrollView(size_hint_y=0.7)
        self.stats_box = GridLayout(cols=1, spacing=10, size_hint_y=None, padding=10)
        self.stats_box.bind(minimum_height=self.stats_box.setter('height'))
        self.stats_scroll.add_widget(self.stats_box)
        self.add_widget(self.stats_scroll)
        
        # Refresh button
        refresh_btn = Button(text='Refresh Stats', size_hint_y=0.1)
        refresh_btn.bind(on_press=self.refresh_stats)
        self.add_widget(refresh_btn)
        
        # Initial stats
        self.refresh_stats(None)
    
    def refresh_stats(self, instance):
        """Refresh and display statistics."""
        self.stats_box.clear_widgets()
        
        # Language Model stats
        lm_stats = f"""[b]Language Model[/b]
Trained: {self.lm.trained}
Vocabulary: {len(self.lm.tokenizer):,}
Contexts (SuperBits): {self.lm.total_contexts:,}
Total Tokens: {self.lm.total_tokens:,}
"""
        lm_label = Label(
            text=lm_stats,
            size_hint_y=None,
            height=150,
            markup=True,
            text_size=(400, None)
        )
        self.stats_box.add_widget(lm_label)
        
        # Knowledge Base stats
        kb_stats = f"""[b]Knowledge Base[/b]
Facts: {self.brain.knowledge.count}
Keywords Indexed: {len(self.brain.knowledge.keyword_index)}
"""
        kb_label = Label(
            text=kb_stats,
            size_hint_y=None,
            height=100,
            markup=True,
            text_size=(400, None)
        )
        self.stats_box.add_widget(kb_label)
        
        # Conversation Memory stats
        mem_stats = f"""[b]Conversation Memory[/b]
Recent Turns: {len(self.brain.memory.turns)}
Topics Discussed: {len(self.brain.memory.mentioned)}
Current Topic: {self.brain.memory.current_topic() or 'None'}
"""
        mem_label = Label(
            text=mem_stats,
            size_hint_y=None,
            height=120,
            markup=True,
            text_size=(400, None)
        )
        self.stats_box.add_widget(mem_label)


# ============================================================================
# MAIN APP
# ============================================================================

class MDBAndroidApp(App):
    """Main MDB Android application."""
    
    def build(self):
        """Build the main application UI."""
        
        # Initialize config
        MDBConfig.init()
        
        # Initialize MDB components
        self.brain = MDBBrain(name="MDB_Android")
        self.lm = MDBLanguageModel(n=3, name="mdb_lm_android")
        
        # Try to load existing models
        self.load_models()
        
        # Main layout
        main_layout = BoxLayout(orientation='vertical')
        
        # Tabbed interface
        tabs = TabbedPanel(do_default_tab=False)
        
        # Chat tab
        chat_tab = TabbedPanelItem(text='Chat')
        chat_tab.content = ChatTab(self.brain)
        tabs.add_widget(chat_tab)
        
        # Training tab
        training_tab = TabbedPanelItem(text='Training')
        training_tab.content = TrainingTab(self.lm, self.brain)
        tabs.add_widget(training_tab)
        
        # Stats tab
        stats_tab = TabbedPanelItem(text='Stats')
        stats_tab.content = StatsTab(self.lm, self.brain)
        tabs.add_widget(stats_tab)
        
        main_layout.add_widget(tabs)
        
        # Set window title
        self.title = 'MDB AI - Multidimensional Binary'
        
        return main_layout
    
    def load_models(self):
        """Load previously trained models if they exist."""
        try:
            if os.path.exists(MDBConfig.LM_FILE):
                print(f"[APP] Loading language model from {MDBConfig.LM_FILE}")
                self.lm.load(MDBConfig.LM_FILE)
            
            if os.path.exists(MDBConfig.KB_FILE):
                print(f"[APP] Loading knowledge base from {MDBConfig.KB_FILE}")
                self.brain.knowledge = self.brain.knowledge.load(MDBConfig.KB_FILE)
        except Exception as e:
            print(f"[WARN] Could not load models: {e}")
    
    def on_stop(self):
        """Save state before closing."""
        try:
            self.lm.save(MDBConfig.LM_FILE)
            self.brain.knowledge.save(MDBConfig.KB_FILE)
            print("[APP] Models saved on exit.")
        except Exception as e:
            print(f"[WARN] Could not save models on exit: {e}")
        return True


if __name__ == '__main__':
    app = MDBAndroidApp()
    app.run()

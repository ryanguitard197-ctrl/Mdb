# MDB AI - Pydroid 3 Setup Guide

This guide walks you through setting up and running the MDB AI application on **Pydroid 3** (Android).

## Prerequisites

- **Android Device** (Android 6.0 or higher recommended)
- **Pydroid 3** installed from Google Play Store
- **Storage Permission** enabled for Pydroid 3
- **Internet Connection** (for initial training)

## Step-by-Step Installation

### Step 1: Install Pydroid 3

1. Open **Google Play Store**
2. Search for **"Pydroid 3"**
3. Install the free version (or Pro for additional features)
4. Open Pydroid 3 after installation

### Step 2: Grant Storage Permissions

1. In Pydroid 3, go to **Settings** (menu icon)
2. Tap **Permissions**
3. Enable **Storage** permission
4. Restart Pydroid 3

### Step 3: Create Project Directory

1. Open **Pydroid 3**
2. Create a new project or use the terminal
3. In the terminal, create the project directory:

```bash
mkdir -p /storage/emulated/0/Documents/MDB
cd /storage/emulated/0/Documents/MDB
```

### Step 4: Copy Application Files

Transfer all files from your computer to the Android device:

**Option A: Using File Manager**
1. Connect your Android device to your computer via USB
2. Open the file manager on your computer
3. Navigate to `/storage/emulated/0/Documents/MDB/`
4. Copy all `.py` files from the `mdb_android_app` folder
5. Paste them into the MDB directory on your device

**Option B: Using Pydroid 3 File Manager**
1. In Pydroid 3, tap the **File Manager** icon
2. Navigate to `/storage/emulated/0/Documents/MDB/`
3. Create the directory if it doesn't exist
4. Copy files manually or use terminal commands

**Option C: Using Terminal (if you have SSH/ADB)**
```bash
adb push mdb_android_app/* /storage/emulated/0/Documents/MDB/
```

### Step 5: Install Dependencies

1. Open **Pydroid 3**
2. Tap the **Terminal** icon (bottom right)
3. Run these commands:

```bash
# Update pip
pip install --upgrade pip

# Install Kivy
pip install kivy

# Install KivyMD (optional, for Material Design)
pip install kivymd

# Install matplotlib (for statistics)
pip install matplotlib
```

**Note:** Installation may take 5–10 minutes. Be patient and keep the app open.

### Step 6: Run the Application

1. In Pydroid 3, go to **File Manager**
2. Navigate to `/storage/emulated/0/Documents/MDB/`
3. Tap on `mdb_app.py`
4. Select **"Run with Python"**
5. The app should launch!

## Troubleshooting

### "Permission Denied" Error

**Solution:**
```bash
# In Pydroid 3 terminal
chmod -R 755 /storage/emulated/0/Documents/MDB/
```

### "Module not found" Errors

**Solution:** Reinstall dependencies:
```bash
pip install --upgrade kivy kivymd matplotlib
```

### App Crashes on Startup

**Solution:**
1. Clear Pydroid 3 cache: **Settings → Clear Cache**
2. Restart Pydroid 3
3. Try running again

### Training Fails with Network Error

**Solution:**
- Check internet connection
- Try training with fewer articles (50 instead of 1000)
- Wikipedia API may be rate-limited; wait a few minutes and retry

### "No module named 'mdb_core'"

**Solution:**
1. Verify all `.py` files are in `/storage/emulated/0/Documents/MDB/`
2. In Pydroid 3 terminal:
```bash
cd /storage/emulated/0/Documents/MDB/
ls -la
```
3. You should see: `mdb_app.py`, `mdb_core.py`, `mdb_lm.py`, `mdb_brain.py`, `mdb_train.py`

### App is Slow or Unresponsive

**Solution:**
- Close other apps to free up memory
- Reduce training dataset size
- Restart your device

## Performance Tips

1. **First Run**: The first training will take 2–5 minutes. This is normal.
2. **Save Models**: After training, click **Save Model** to avoid retraining.
3. **Memory**: Close other apps before running large training sessions.
4. **Storage**: Ensure you have at least 500 MB free space on your device.

## File Locations on Android

```
/storage/emulated/0/Documents/
├── MDB/
│   ├── mdb_app.py
│   ├── mdb_core.py
│   ├── mdb_lm.py
│   ├── mdb_brain.py
│   ├── mdb_train.py
│   └── data/
│       ├── knowledge_base.json
│       ├── chat_history.json
│       └── models/
│           └── language_model.json
```

## Advanced: Running from Pydroid 3 IDE

1. Open Pydroid 3
2. Tap **"New"** → **"Project"**
3. Name it **"MDB AI"**
4. Copy all `.py` files into the project folder
5. Open `mdb_app.py` in the editor
6. Tap the **▶ Run** button (top right)

## Advanced: Scheduling Regular Training

To run training automatically at intervals:

1. In Pydroid 3, create a new script `auto_train.py`:
```python
import time
import threading
from mdb_app import MDBAndroidApp

app = MDBAndroidApp()
# Train every 24 hours
while True:
    app.lm.train(num_articles=100)
    time.sleep(86400)  # 24 hours
```

2. Run it as a background service

## Uninstalling

To remove the MDB AI app:

```bash
# In Pydroid 3 terminal
rm -rf /storage/emulated/0/Documents/MDB/
```

## Getting Help

If you encounter issues:

1. Check the **Troubleshooting** section above
2. Review the main **README.md** file
3. Check Pydroid 3 logs: **Settings → Logs**
4. Ensure all dependencies are installed: `pip list`

---

**Enjoy using MDB AI on your Android device! 🚀**

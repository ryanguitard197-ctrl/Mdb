# MDB AI - Android Application

A professional, high-usability Android application for the **Multidimensional Binary (MDB)** AI system. Built with Kivy/KivyMD for a modern Material Design interface.

## Features

### 1. **Chat Interface**
- Real-time conversation with the MDB Brain
- Message bubbles with user/AI distinction
- Non-blocking background processing
- Conversation history tracking
- Natural language understanding via MDB Brain

### 2. **Training Hub**
- Download and train on Wikipedia articles
- Configurable training size (50–1000 articles)
- Real-time progress tracking
- Training log with detailed feedback
- Model persistence (save/load)

### 3. **Network Statistics**
- Language Model metrics (vocabulary size, context count)
- Knowledge Base statistics (fact count, keyword index)
- Conversation memory tracking
- Real-time refresh

## Architecture

```
mdb_app.py (Main Application)
├── ChatTab (Chat Interface)
├── TrainingTab (Training Hub)
├── StatsTab (Statistics)
└── MDB Components
    ├── mdb_brain.py (Conversational Intelligence)
    ├── mdb_lm.py (Language Model)
    ├── mdb_core.py (Multidimensional Binary Core)
    └── mdb_train.py (Training Pipeline)
```

## Installation

### On Desktop (Development)

```bash
# Clone or extract the project
cd mdb_android_app

# Install dependencies
pip install -r requirements.txt

# Run the app
python mdb_app.py
```

### On Pydroid 3 (Android)

1. **Install Pydroid 3** from Google Play Store
2. **Open Pydroid 3** and create a new project
3. **Copy all files** from this directory to your Pydroid project folder:
   ```
   /storage/emulated/0/Documents/Pydroid3/projects/mdb_ai/
   ```
4. **Install dependencies** via Pydroid's pip terminal:
   ```bash
   pip install kivy>=2.1.0
   pip install kivymd>=0.104.2
   ```
5. **Run** `mdb_app.py` from Pydroid's IDE

## Usage

### Chat Tab
1. Type your message in the input field
2. Press **Send** or hit Enter
3. Wait for the AI response (shown with a thinking indicator)
4. Continue the conversation naturally

### Training Tab
1. Select the number of articles to train on
2. Click **Quick Train** (100 articles) or **Full Train** (1000 articles)
3. Watch the progress bar and training log
4. Click **Save Model** to persist the trained model
5. Use **Clear Log** to clean up the display

### Stats Tab
1. View real-time statistics about the MDB network
2. Monitor Language Model, Knowledge Base, and Conversation Memory
3. Click **Refresh Stats** to update the display

## File Structure

```
mdb_android_app/
├── mdb_app.py              # Main application (this file)
├── mdb_core.py             # MDB core logic (SuperBit, DimensionalIndex)
├── mdb_lm.py               # Language Model (n-gram with SuperBits)
├── mdb_brain.py            # Conversational Intelligence
├── mdb_train.py            # Training Pipeline (Wikipedia fetcher)
├── requirements.txt        # Python dependencies
└── README.md               # This file
```

## Data Storage

The application stores data in platform-specific locations:

- **Desktop**: `~/.mdb/`
- **Android**: `/storage/emulated/0/Documents/MDB/`

Subdirectories:
- `data/` - Knowledge Base and chat history
- `models/` - Trained Language Model
- `training/` - Training state and progress

## Configuration

Edit `MDBConfig` class in `mdb_app.py` to customize:
- Storage paths
- File names
- Default settings

## Performance Optimization

### For Pydroid 3:
- Training runs in background threads to keep UI responsive
- Models are cached after first training
- Large datasets are paginated to avoid memory issues

### For Desktop:
- Full training can take 2–5 minutes depending on internet speed
- Models are saved to disk for instant loading on restart

## Troubleshooting

### "ImportError: No module named 'kivy'"
```bash
pip install kivy
```

### "ImportError: No module named 'mdb_core'"
Ensure all MDB files (`mdb_core.py`, `mdb_lm.py`, `mdb_brain.py`) are in the same directory as `mdb_app.py`.

### Training fails with network error
- Check internet connection
- Wikipedia API may be temporarily unavailable
- Try again in a few minutes

### App crashes on Android
- Ensure Pydroid 3 has storage permissions
- Check that the `/storage/emulated/0/Documents/MDB/` directory exists
- Restart Pydroid 3 and try again

## Advanced Usage

### Custom Training Data

Modify the `build_training_data()` call in `TrainingTab._run_training()` to use custom data:

```python
# Instead of Wikipedia, use your own texts
texts = ["your text 1", "your text 2", ...]
self.lm.train(texts, verbose=False)
```

### Extending the Brain

Add new knowledge to the brain programmatically:

```python
self.brain.knowledge.add(
    topic="Your Topic",
    content="Your fact or information",
    confidence=0.9
)
```

## MDB Theory

The **Multidimensional Binary** system treats binary strings as multidimensional objects:

- **D1 (Value)**: The bit content (0s and 1s)
- **D2 (Space)**: Positional relationships
- **D3 (Time)**: Length governs evolution
- **D4 (Density)**: Probability mass (ratio of 1s)
- **D5 (Gravity)**: Relational weight using Golden Ratio

This enables:
- **SuperBits**: Probabilistic binary strings encoding multiple states
- **Non-destructive collapse**: Read superposition without destroying it
- **O(1) dimensional addressing**: Instant lookup via dimensional coordinates
- **Natural evolution**: Strings evolve based on their own temporal dimension

## License

This project is open source. See the original MDB documentation for licensing details.

## Contact & Support

For issues, questions, or contributions, refer to the original MDB project documentation.

---

**Built with ❤️ using Kivy, KivyMD, and the Multidimensional Binary system.**

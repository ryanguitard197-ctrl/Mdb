"""
================================================================================
MDB LANGUAGE MODEL - N-gram probabilities stored natively as SuperBits
================================================================================
This is the core insight: probability distributions ARE SuperBits.
Each unique word context maps to a SuperBit whose labels are possible
next words and whose weights are the conditional probabilities.

Training on text corpus -> SuperBit network
Generation -> collapse chain through SuperBit network
Learning -> evolve() on successful outcomes
================================================================================
"""

import math
import random
import hashlib
import json
import re
from typing import Dict, List, Tuple, Optional
from collections import defaultdict

try:
    from mdb_core import SuperBit, DimensionalIndex, dimensional_address, PHI
except ImportError:
    raise ImportError("mdb_core.py must be in the same directory.")


# =============================================================================
# TOKENIZER
# =============================================================================

class MDBTokenizer:
    """Word-level tokenizer with vocabulary management."""

    SPECIAL = ['<PAD>', '<UNK>', '<START>', '<END>']

    def __init__(self):
        self.vocab: Dict[str, int] = {}
        self.id_to_word: Dict[int, str] = {}
        self.word_freq: Dict[str, int] = defaultdict(int)
        self._next_id = 0
        for tok in self.SPECIAL:
            self._add(tok)

    def _add(self, word: str) -> int:
        if word not in self.vocab:
            self.vocab[word] = self._next_id
            self.id_to_word[self._next_id] = word
            self._next_id += 1
        return self.vocab[word]

    def tokenize(self, text: str) -> List[str]:
        """Split text into word tokens, preserving punctuation as tokens."""
        text = text.lower().strip()
        tokens = re.findall(r"\b[\w']+\b|[.!?,;:]", text)
        return tokens

    def build_vocab(self, texts: List[str], min_freq: int = 1, max_vocab: int = 50000):
        """Build vocabulary from corpus."""
        counts: Dict[str, int] = defaultdict(int)
        for text in texts:
            for w in self.tokenize(text):
                counts[w] += 1
        # Sort by frequency, take top max_vocab
        sorted_words = sorted(counts.items(), key=lambda x: -x[1])
        for word, freq in sorted_words[:max_vocab]:
            if freq >= min_freq:
                self._add(word)
                self.word_freq[word] = freq

    def encode(self, text: str) -> List[int]:
        unk = self.vocab['<UNK>']
        return [self.vocab.get(w, unk) for w in self.tokenize(text)]

    def decode(self, ids: List[int]) -> str:
        return ' '.join(self.id_to_word.get(i, '<UNK>') for i in ids)

    def to_dict(self) -> dict:
        return {
            'vocab': self.vocab,
            'id_to_word': {str(k): v for k, v in self.id_to_word.items()},
            'word_freq': dict(self.word_freq),
            '_next_id': self._next_id
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'MDBTokenizer':
        t = cls.__new__(cls)
        t.vocab = data['vocab']
        t.id_to_word = {int(k): v for k, v in data['id_to_word'].items()}
        t.word_freq = defaultdict(int, data['word_freq'])
        t._next_id = data['_next_id']
        return t

    def __len__(self):
        return len(self.vocab)


# =============================================================================
# MDB LANGUAGE MODEL
# =============================================================================

class MDBLanguageModel:
    """
    N-gram language model where each context is stored as a SuperBit.

    The conceptual elegance:
    - A SuperBit IS a probability distribution over discrete outcomes
    - An n-gram model IS a set of probability distributions over next words
    - Therefore: an n-gram LM IS a network of SuperBits

    Each unique (n-1)-word context maps to one SuperBit.
    That SuperBit's labels = possible next words.
    That SuperBit's weights = P(next_word | context).

    Generation = repeatedly collapse the context SuperBit to get the next word.
    Learning   = evolve() on good outcomes to reinforce useful paths.
    """

    def __init__(self, n: int = 3, name: str = "mdb_lm"):
        self.n = n
        self.name = name
        self.tokenizer = MDBTokenizer()
        # context_hash -> SuperBit
        self.ngrams: Dict[str, SuperBit] = {}
        # Store context string -> hash for lookup
        self._ctx_map: Dict[str, str] = {}
        self.total_tokens = 0
        self.total_contexts = 0
        self.trained = False

    def _ctx_hash(self, context: Tuple[str, ...]) -> str:
        """Hash a context tuple to a short hex key."""
        raw = '\x00'.join(context)
        return hashlib.md5(raw.encode()).hexdigest()[:16]

    def train(self, texts: List[str], verbose: bool = True):
        """Train on a list of text strings."""
        if verbose:
            print(f"[MDB-LM] Building vocabulary from {len(texts)} texts...")

        self.tokenizer.build_vocab(texts, min_freq=1, max_vocab=30000)

        if verbose:
            print(f"[MDB-LM] Vocab size: {len(self.tokenizer)} words")
            print(f"[MDB-LM] Counting {self.n}-grams...")

        # Count: context_hash -> {next_word -> count}
        ngram_counts: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))

        for i, text in enumerate(texts):
            tokens = self.tokenizer.tokenize(text)
            if not tokens:
                continue
            # Pad with start/end tokens
            padded = (['<START>'] * (self.n - 1)) + tokens + ['<END>']
            self.total_tokens += len(tokens)

            for j in range(len(padded) - self.n + 1):
                ctx = tuple(padded[j:j + self.n - 1])
                nxt = padded[j + self.n - 1]
                key = self._ctx_hash(ctx)
                ngram_counts[key][nxt] += 1
                self._ctx_map[' '.join(ctx)] = key

            if verbose and (i + 1) % 2000 == 0:
                print(f"[MDB-LM]   {i+1}/{len(texts)} texts processed...")

        if verbose:
            print(f"[MDB-LM] Converting {len(ngram_counts)} contexts -> SuperBits...")

        # Convert count dicts to SuperBits
        for ctx_key, word_counts in ngram_counts.items():
            words = list(word_counts.keys())
            counts = [word_counts[w] for w in words]
            total = sum(counts)
            weights = [c / total for c in counts]

            # Only keep top-K next words per context to save memory
            if len(words) > 200:
                sorted_pairs = sorted(zip(weights, words), reverse=True)[:200]
                weights, words = zip(*sorted_pairs)
                weights = list(weights)
                words = list(words)
                s = sum(weights)
                weights = [w / s for w in weights]

            sb = SuperBit(num_states=len(words), labels=words, weights=weights)
            self.ngrams[ctx_key] = sb

        self.total_contexts = len(self.ngrams)
        self.trained = True

        if verbose:
            print(f"[MDB-LM] Training complete.")
            print(f"[MDB-LM]   Tokens: {self.total_tokens:,}")
            print(f"[MDB-LM]   Contexts (SuperBits): {self.total_contexts:,}")

    def _get_superbit(self, context: List[str]) -> Optional[SuperBit]:
        """Get the SuperBit for a context, with n-gram backoff."""
        for order in range(self.n - 1, 0, -1):
            if len(context) >= order:
                ctx = tuple(context[-order:])
            else:
                ctx = tuple(['<START>'] * (order - len(context)) + list(context))
            key = self._ctx_hash(ctx)
            if key in self.ngrams:
                return self.ngrams[key]
        return None

    def predict_next(self, context: List[str], temperature: float = 0.9) -> Optional[str]:
        """Predict next word given context, with temperature sampling."""
        sb = self._get_superbit(context)
        if sb is None:
            # Random fallback from known vocab
            if self.tokenizer.vocab:
                words = [w for w in self.tokenizer.vocab if not w.startswith('<')]
                return random.choice(words) if words else None
            return None

        if abs(temperature - 1.0) < 0.01:
            return sb.collapse()

        # Temperature sampling: sharpen or flatten distribution
        weights = [w ** (1.0 / max(temperature, 0.01)) for w in sb.weights]
        total = sum(weights)
        weights = [w / total for w in weights]

        r = random.random()
        cumulative = 0.0
        for word, weight in zip(sb.labels, weights):
            cumulative += weight
            if r <= cumulative:
                return word
        return sb.labels[-1]

    def generate(
        self,
        seed: str = "",
        max_tokens: int = 60,
        temperature: float = 0.85,
        stop_tokens: List[str] = None
    ) -> str:
        """Generate text from an optional seed."""
        if stop_tokens is None:
            stop_tokens = ['<END>']

        if seed:
            context = self.tokenizer.tokenize(seed.lower())
        else:
            context = ['<START>'] * (self.n - 1)

        generated = list(self.tokenizer.tokenize(seed.lower())) if seed else []

        for _ in range(max_tokens):
            nxt = self.predict_next(context, temperature)
            if nxt is None:
                break
            if nxt in stop_tokens:
                break
            if nxt not in ['<START>', '<PAD>', '<UNK>']:
                generated.append(nxt)
            context = (context + [nxt])[-(self.n - 1):]

        return self._detokenize(generated)

    def _detokenize(self, tokens: List[str]) -> str:
        """Convert token list to readable text."""
        if not tokens:
            return ""
        text = tokens[0]
        for tok in tokens[1:]:
            if tok in '.!?,;:':
                text += tok
            else:
                text += ' ' + tok
        # Capitalize sentences
        text = re.sub(r'(?:^|(?<=[.!?])\s+)([a-z])', lambda m: m.group().upper(), text)
        return text.strip()

    def complete_sentence(self, partial: str, max_tokens: int = 30,
                          temperature: float = 0.8) -> str:
        """Complete a partial sentence."""
        return partial.rstrip() + ' ' + self.generate(
            seed=partial, max_tokens=max_tokens, temperature=temperature
        )

    def save(self, filepath: str):
        """Save model to JSON file."""
        print(f"[MDB-LM] Saving to {filepath}...")
        data = {
            'n': self.n,
            'name': self.name,
            'tokenizer': self.tokenizer.to_dict(),
            'ngrams': {k: v.to_dict() for k, v in self.ngrams.items()},
            'ctx_map': self._ctx_map,
            'total_tokens': self.total_tokens,
            'total_contexts': self.total_contexts
        }
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
        print(f"[MDB-LM] Saved. ({len(self.ngrams)} SuperBits)")

    @classmethod
    def load(cls, filepath: str) -> 'MDBLanguageModel':
        """Load model from JSON file."""
        print(f"[MDB-LM] Loading from {filepath}...")
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)

        model = cls(n=data['n'], name=data['name'])
        model.tokenizer = MDBTokenizer.from_dict(data['tokenizer'])
        model.ngrams = {
            k: SuperBit.from_dict(v)
            for k, v in data['ngrams'].items()
        }
        model._ctx_map = data.get('ctx_map', {})
        model.total_tokens = data.get('total_tokens', 0)
        model.total_contexts = data.get('total_contexts', 0)
        model.trained = True
        print(f"[MDB-LM] Loaded. ({model.total_contexts} contexts, "
              f"{len(model.tokenizer)} vocab)")
        return model

    def stats(self) -> dict:
        return {
            'n': self.n,
            'vocab_size': len(self.tokenizer),
            'total_tokens': self.total_tokens,
            'total_contexts': self.total_contexts,
            'trained': self.trained
        }

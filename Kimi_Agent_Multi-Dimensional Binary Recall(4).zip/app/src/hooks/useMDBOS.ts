import type {
  DimensionalAddress,
  SuperBit,
  DimensionalEntry,
  MDBProcess,
  OSKernelState,
  MDBOSInstance,
  EntangledMemoryCore,
  TerminalCommand,
} from '@/types/mdb';

const PHI = 1.6180339887498948482;

// =============================================================================
// DIMENSIONAL CALCULATORS
// =============================================================================

function d3_temporal(binaryStr: string): number {
  return binaryStr.length;
}

function countOnes(binaryStr: string): number {
  let c = 0;
  for (let i = 0; i < binaryStr.length; i++) if (binaryStr[i] === '1') c++;
  return c;
}

function d4_density(binaryStr: string): number {
  if (!binaryStr) return 0.0;
  return countOnes(binaryStr) / binaryStr.length;
}

function d5_gravity(binaryStr: string): number {
  if (!binaryStr) return 0.0;
  let sum = 0;
  for (let i = 0; i < binaryStr.length; i++) {
    sum += (binaryStr[i] === '1' ? 1 : 0) * PHI * (i + 1);
  }
  return sum % 1.0;
}

function d6_entropy(binaryStr: string): number {
  if (!binaryStr) return 0.0;
  const p = d4_density(binaryStr);
  if (p === 0 || p === 1) return 0.0;
  return -(p * Math.log2(p) + (1 - p) * Math.log2(1 - p));
}

function computeAddress(binaryStr: string): DimensionalAddress {
  return {
    d3: d3_temporal(binaryStr),
    d4: Math.round(d4_density(binaryStr) * 1e8) / 1e8,
    d5: Math.round(d5_gravity(binaryStr) * 1e8) / 1e8,
  };
}

function stringEvolve(binaryStr: string): string {
  const n = binaryStr.length;
  if (n === 0) return '0';
  if (n % 2 === 1) {
    const mid = Math.floor(n / 2);
    const flip = binaryStr[mid] === '0' ? '1' : '0';
    return binaryStr.slice(0, mid) + flip + binaryStr.slice(mid + 1);
  } else {
    const end = n - 1;
    const flip = binaryStr[end] === '0' ? '1' : '0';
    return binaryStr.slice(0, end) + flip;
  }
}

function encodeSuperBit(
  numStates: number,
  _labels: string[],
  weights: number[],
  generation: number
): string {
  const parts: string[] = [];
  parts.push(Math.min(numStates, 255).toString(2).padStart(8, '0'));
  for (const w of weights) {
    parts.push(Math.min(Math.floor(w * 255), 255).toString(2).padStart(8, '0'));
  }
  parts.push(Math.min(generation, 255).toString(2).padStart(8, '0'));
  parts.push('0'.padStart(8, '0'));
  parts.push('0'.padStart(8, '0'));
  return parts.join('');
}

// =============================================================================
// ENTANGLED MEMORY
// =============================================================================

function createEntangledMemory(): EntangledMemoryCore {
  const cores = new Map<string, any>();
  const links = new Map<string, string[]>();

  return {
    cores,
    links,
    entangle(a: any, b: any) {
      const nameA = a?.name || String(idCounter++);
      const nameB = b?.name || String(idCounter++);
      cores.set(nameA, a);
      cores.set(nameB, b);
      const la = links.get(nameA) || [];
      la.push(nameB);
      links.set(nameA, la);
      const lb = links.get(nameB) || [];
      lb.push(nameA);
      links.set(nameB, lb);
      const ea = d6_entropy(a?.root?.string || String(a));
      const eb = d6_entropy(b?.root?.string || String(b));
      return ((ea + eb) * 0.618) % 1.0;
    },
    propagate(source: string, signal: string) {
      const targets = links.get(source) || [];
      for (const target of targets) {
        const t = cores.get(target);
        if (t?.evolve) t.evolve(signal, 0.1 * PHI);
      }
    },
  };
}

let idCounter = 0;
function generateId(): string {
  return `mdb_${Date.now()}_${idCounter++}`;
}

// =============================================================================
// TERMINAL COMMANDS
// =============================================================================

const commands: TerminalCommand[] = [
  {
    name: 'help',
    description: 'Show available commands',
    usage: 'help [command]',
    handler(args) {
      if (args.length > 0) {
        const cmd = commands.find((c) => c.name === args[0]);
        return cmd ? `${cmd.name}: ${cmd.description}\nUsage: ${cmd.usage}` : `Unknown command: ${args[0]}`;
      }
      return commands.map((c) => `  ${c.name.padEnd(12)} ${c.description}`).join('\n');
    },
  },
  {
    name: 'superbit',
    description: 'Create a new SuperBit',
    usage: 'superbit <name> [states...]',
    handler(args, os) {
      if (args.length < 2) return 'Usage: superbit <name> [state1 state2 ...]';
      const name = args[0];
      const states = args.slice(1);
      const weights = states.map(() => 1.0 / states.length);
      const sb = os.createSuperBit(name, states, weights);
      return `Created SuperBit: ${sb.name}\n  Address: D3=${sb.address.d3}, D4=${sb.address.d4}, D5=${sb.address.d5}\n  States: ${states.join(', ')}`;
    },
  },
  {
    name: 'collapse',
    description: 'Collapse a SuperBit to a definite state',
    usage: 'collapse <superbit_id>',
    handler(args, os) {
      if (args.length < 1) return 'Usage: collapse <superbit_id>';
      const result = os.collapseSuperBit(args[0]);
      return `Collapsed to: ${result}`;
    },
  },
  {
    name: 'evolve',
    description: 'Evolve a SuperBit based on outcome',
    usage: 'evolve <superbit_id> <outcome> [reward]',
    handler(args, os) {
      if (args.length < 2) return 'Usage: evolve <superbit_id> <outcome> [reward]';
      const reward = args[2] ? parseFloat(args[2]) : 0.1;
      os.evolveSuperBit(args[0], args[1], reward);
      return `Evolved ${args[0]} toward outcome: ${args[1]} (reward=${reward})`;
    },
  },
  {
    name: 'address',
    description: 'Compute dimensional address of a binary string',
    usage: 'address <binary_string>',
    handler(args) {
      if (args.length < 1) return 'Usage: address <binary_string>';
      const addr = computeAddress(args[0]);
      return `Dimensional Address:\n  D3 (Temporal):  ${addr.d3}\n  D4 (Density):   ${addr.d4}\n  D5 (Gravity):   ${addr.d5}`;
    },
  },
  {
    name: 'index',
    description: 'List all entries in the dimensional index',
    usage: 'index',
    handler(_args, os) {
      const entries = Array.from(os.index.values());
      if (entries.length === 0) return 'Dimensional Index is empty.';
      return entries.map((e) => `  ${e.name} [${e.type}] @ (${e.address.d3}, ${e.address.d4}, ${e.address.d5})`).join('\n');
    },
  },
  {
    name: 'entangle',
    description: 'Entangle two SuperBits',
    usage: 'entangle <id_a> <id_b>',
    handler(args, os) {
      if (args.length < 2) return 'Usage: entangle <id_a> <id_b>';
      os.entangle(args[0], args[1]);
      return `Entangled ${args[0]} ↔ ${args[1]}`;
    },
  },
  {
    name: 'propagate',
    description: 'Propagate a signal through entangled network',
    usage: 'propagate <source_id> <signal>',
    handler(args, os) {
      if (args.length < 2) return 'Usage: propagate <source_id> <signal>';
      os.propagateSignal(args[0], args[1]);
      return `Propagated '${args[1]}' from ${args[0]}`;
    },
  },
  {
    name: 'process',
    description: 'List active processes',
    usage: 'process',
    handler(_args, os) {
      const procs = Array.from(os.processes.values());
      if (procs.length === 0) return 'No active processes.';
      return procs.map((p) => `  ${p.id} | ${p.name} | ${p.state} | CPU:${p.cpuTime}ms`).join('\n');
    },
  },
  {
    name: 'spawn',
    description: 'Spawn a new process',
    usage: 'spawn <name> <superbit_id>',
    handler(args, os) {
      if (args.length < 2) return 'Usage: spawn <name> <superbit_id>';
      const p = os.spawnProcess(args[0], args[1]);
      return `Spawned process: ${p.id} (${p.name})`;
    },
  },
  {
    name: 'kill',
    description: 'Kill a process',
    usage: 'kill <process_id>',
    handler(args, os) {
      if (args.length < 1) return 'Usage: kill <process_id>';
      os.killProcess(args[0]);
      return `Killed process ${args[0]}`;
    },
  },
  {
    name: 'evolve-step',
    description: 'Apply one D3 evolution step to a binary string',
    usage: 'evolve-step <binary_string>',
    handler(args) {
      if (args.length < 1) return 'Usage: evolve-step <binary_string>';
      const evolved = stringEvolve(args[0]);
      return `Original: ${args[0]}\nEvolved:  ${evolved}`;
    },
  },
  {
    name: 'clear',
    description: 'Clear the terminal',
    usage: 'clear',
    handler() {
      return '__CLEAR__';
    },
  },
  {
    name: 'phi',
    description: 'Show the Golden Ratio constant',
    usage: 'phi',
    handler() {
      return `φ (Golden Ratio) = ${PHI}\n\nUsed in D5 (Gravity) calculation for maximally irrational position separation.`;
    },
  },
  {
    name: 'status',
    description: 'Show MDB OS kernel status',
    usage: 'status',
    handler(_args, os) {
      const k = os.kernel;
      return `MDB OS Kernel v${k.version}\nBoot Time: ${new Date(k.bootTime).toLocaleString()}\nRoot Core: ${k.rootCore.name}\nStates: ${k.rootCore.states.join(', ')}\nGeneration: ${k.rootCore.generation}\nActive Processes: ${os.processes.size}\nDimensional Index: ${os.index.size} entries\nEntangled Pairs: ${k.entangledPairs.length}`;
    },
  },
];

// =============================================================================
// MDB OS INSTANCE FACTORY
// =============================================================================

export function createMDBOS(): MDBOSInstance {
  const kernel: OSKernelState = {
    version: '3.0.0-OS',
    phi: PHI,
    bootTime: Date.now(),
    rootCore: {
      name: 'MDB_ROOT',
      states: ['idle', 'active', 'evolving'],
      weights: [0.33, 0.34, 0.33],
      generation: 0,
    },
    activeProcesses: [],
    dimensionalIndex: [],
    entangledPairs: [],
    memoryWeb: {},
  };

  const superbits = new Map<string, SuperBit>();
  const processes = new Map<string, MDBProcess>();
  const index = new Map<string, DimensionalEntry>();
  const network = new Map<string, any>();
  const entangledMemory = createEntangledMemory();

  const os: MDBOSInstance = {
    kernel,
    superbits,
    processes,
    index,
    network,
    entangledMemory,

    executeCommand(cmdLine: string): string {
      const parts = cmdLine.trim().split(/\s+/);
      if (parts.length === 0 || parts[0] === '') return '';
      const cmdName = parts[0].toLowerCase();
      const args = parts.slice(1);
      const cmd = commands.find((c) => c.name === cmdName);
      if (!cmd) return `Unknown command: ${cmdName}. Type 'help' for available commands.`;
      try {
        return cmd.handler(args, this);
      } catch (e: any) {
        return `Error: ${e.message}`;
      }
    },

    createSuperBit(name: string, labels: string[], weights: number[]): SuperBit {
      const total = weights.reduce((a, b) => a + b, 0);
      const normalized = weights.map((w) => w / total);
      const binaryStr = encodeSuperBit(labels.length, labels, normalized, 0);
      const addr = computeAddress(binaryStr);
      const sb: SuperBit = {
        id: generateId(),
        name,
        states: labels.map((l, i) => ({ id: generateId(), label: l, weight: normalized[i] })),
        generation: 0,
        address: addr,
        binaryString: binaryStr,
        properties: {},
        history: [],
      };
      superbits.set(sb.id, sb);
      const entry: DimensionalEntry = {
        id: sb.id,
        name: sb.name,
        type: 'superbit',
        address: addr,
        data: sb,
        createdAt: Date.now(),
      };
      this.storeInIndex(entry);
      return sb;
    },

    evolveSuperBit(id: string, outcome: string, reward: number) {
      const sb = superbits.get(id);
      if (!sb) return;
      const idx = sb.states.findIndex((s) => s.label === outcome);
      if (idx >= 0) {
        sb.states[idx].weight = Math.min(1.0, sb.states[idx].weight + reward);
        const total = sb.states.reduce((a, s) => a + s.weight, 0);
        sb.states.forEach((s) => (s.weight /= total));
        sb.generation++;
        const newWeights = sb.states.map((s) => s.weight);
        sb.binaryString = encodeSuperBit(sb.states.length, sb.states.map((s) => s.label), newWeights, sb.generation);
        sb.address = computeAddress(sb.binaryString);
        sb.history.push(`evolved->${outcome}(+${reward})`);
      }
    },

    collapseSuperBit(id: string): string {
      const sb = superbits.get(id);
      if (!sb || sb.states.length === 0) return 'null';
      const r = Math.random();
      let cumulative = 0;
      for (const s of sb.states) {
        cumulative += s.weight;
        if (r <= cumulative) {
          sb.history.push(`collapsed->${s.label}`);
          return s.label;
        }
      }
      return sb.states[sb.states.length - 1].label;
    },

    storeInIndex(entry: DimensionalEntry) {
      index.set(entry.id, entry);
      kernel.dimensionalIndex.push(entry);
    },

    retrieveByAddress(addr: DimensionalAddress): DimensionalEntry | undefined {
      for (const entry of index.values()) {
        if (
          entry.address.d3 === addr.d3 &&
          entry.address.d4 === addr.d4 &&
          entry.address.d5 === addr.d5
        ) {
          return entry;
        }
      }
      return undefined;
    },

    entangle(idA: string, idB: string) {
      const a = superbits.get(idA);
      const b = superbits.get(idB);
      if (a && b) {
        entangledMemory.entangle(a, b);
        kernel.entangledPairs.push([idA, idB]);
      }
    },

    propagateSignal(sourceId: string, signal: string) {
      entangledMemory.propagate(sourceId, signal);
    },

    spawnProcess(name: string, superbitId: string): MDBProcess {
      const p: MDBProcess = {
        id: generateId(),
        name,
        state: 'running',
        superbitId,
        priority: 0.5,
        entangledWith: [],
        cpuTime: 0,
      };
      processes.set(p.id, p);
      kernel.activeProcesses.push(p);
      return p;
    },

    killProcess(id: string) {
      const p = processes.get(id);
      if (p) {
        p.state = 'collapsed';
        processes.delete(id);
        kernel.activeProcesses = kernel.activeProcesses.filter((ap) => ap.id !== id);
      }
    },
  };

  // Seed some initial system SuperBits
  const rootSb = os.createSuperBit('root_core', ['idle', 'active', 'evolving'], [0.33, 0.34, 0.33]);
  kernel.rootCore.generation = rootSb.generation;

  // Seed system processes
  os.spawnProcess('kernel_scheduler', rootSb.id);
  os.spawnProcess('dimensional_indexer', rootSb.id);
  os.spawnProcess('entropy_monitor', rootSb.id);

  return os;
}

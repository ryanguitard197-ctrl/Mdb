import { useState, useCallback } from 'react';
import type { MDBOSInstance } from '@/types/mdb';

interface WindowDef {
  id: string;
  title: string;
  component: React.ReactNode;
  x: number;
  y: number;
  w: number;
  h: number;
  minimized: boolean;
  focused: boolean;
}

interface DesktopShellProps {
  os: MDBOSInstance;
}

// Import sub-apps dynamically
import Terminal from './apps/Terminal';
import SuperBitLab from './apps/SuperBitLab';
import DimensionalNavigator from './apps/DimensionalNavigator';
import NetworkMonitor from './apps/NetworkMonitor';
import SystemCore from './apps/SystemCore';
import EvolutionConsole from './apps/EvolutionConsole';
import Docs from './apps/Docs';

const appIcons = [
  { id: 'terminal', name: 'Terminal', icon: '⌘', color: 'text-emerald-400', bg: 'bg-emerald-500/10 border-emerald-500/30' },
  { id: 'superbit', name: 'SuperBit Lab', icon: '◈', color: 'text-amber-400', bg: 'bg-amber-500/10 border-amber-500/30' },
  { id: 'navigator', name: 'Dimensional Navigator', icon: '◉', color: 'text-cyan-400', bg: 'bg-cyan-500/10 border-cyan-500/30' },
  { id: 'network', name: 'Network Monitor', icon: '◐', color: 'text-violet-400', bg: 'bg-violet-500/10 border-violet-500/30' },
  { id: 'core', name: 'System Core', icon: '◊', color: 'text-rose-400', bg: 'bg-rose-500/10 border-rose-500/30' },
  { id: 'evolution', name: 'Evolution Console', icon: '◑', color: 'text-teal-400', bg: 'bg-teal-500/10 border-teal-500/30' },
  { id: 'docs', name: 'Documentation', icon: '◙', color: 'text-sky-400', bg: 'bg-sky-500/10 border-sky-500/30' },
];

export default function DesktopShell({ os }: DesktopShellProps) {
  const [windows, setWindows] = useState<WindowDef[]>([]);
  const [activeWindow, setActiveWindow] = useState<string | null>(null);
  const [showDesktopGrid] = useState(true);

  const openApp = useCallback((appId: string) => {
    const existing = windows.find((w) => w.id === appId);
    if (existing) {
      setWindows((prev) =>
        prev.map((w) => (w.id === appId ? { ...w, minimized: false, focused: true } : { ...w, focused: false }))
      );
      setActiveWindow(appId);
      return;
    }

    const app = appIcons.find((a) => a.id === appId);
    if (!app) return;

    let component: React.ReactNode;
    switch (appId) {
      case 'terminal':
        component = <Terminal os={os} />;
        break;
      case 'superbit':
        component = <SuperBitLab os={os} />;
        break;
      case 'navigator':
        component = <DimensionalNavigator os={os} />;
        break;
      case 'network':
        component = <NetworkMonitor os={os} />;
        break;
      case 'core':
        component = <SystemCore os={os} />;
        break;
      case 'evolution':
        component = <EvolutionConsole os={os} />;
        break;
      case 'docs':
        component = <Docs os={os} />;
        break;
      default:
        component = <div>Unknown App</div>;
    }

    const newWindow: WindowDef = {
      id: appId,
      title: app.name,
      component,
      x: 80 + windows.length * 30,
      y: 60 + windows.length * 25,
      w: 720,
      h: 480,
      minimized: false,
      focused: true,
    };

    setWindows((prev) => [...prev.map((w) => ({ ...w, focused: false })), newWindow]);
    setActiveWindow(appId);
  }, [windows, os]);

  const closeWindow = useCallback((id: string) => {
    setWindows((prev) => prev.filter((w) => w.id !== id));
    if (activeWindow === id) setActiveWindow(null);
  }, [activeWindow]);

  const minimizeWindow = useCallback((id: string) => {
    setWindows((prev) => prev.map((w) => (w.id === id ? { ...w, minimized: true, focused: false } : w)));
    if (activeWindow === id) setActiveWindow(null);
  }, [activeWindow]);

  const focusWindow = useCallback((id: string) => {
    setWindows((prev) =>
      prev.map((w) => (w.id === id ? { ...w, focused: true, minimized: false } : { ...w, focused: false }))
    );
    setActiveWindow(id);
  }, []);

  const getAppIcon = (id: string) => appIcons.find((a) => a.id === id);

  return (
    <div className="fixed inset-0 bg-[#0a0a0f] overflow-hidden select-none">
      {/* Desktop Background Grid */}
      <div
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: `
            linear-gradient(rgba(6,182,212,0.15) 1px, transparent 1px),
            linear-gradient(90deg, rgba(6,182,212,0.15) 1px, transparent 1px)
          `,
          backgroundSize: '40px 40px',
        }}
      />

      {/* Dimensional coordinate overlay */}
      <div className="absolute top-4 left-4 font-mono text-[10px] text-cyan-500/40 pointer-events-none">
        <div>D3: TEMPORAL | D4: DENSITY | D5: GRAVITY</div>
        <div>φ = {os.kernel.phi.toFixed(10)}</div>
      </div>

      {/* Desktop Icons */}
      {showDesktopGrid && (
        <div className="absolute top-20 left-8 flex flex-col gap-6">
          {appIcons.map((app) => (
            <button
              key={app.id}
              onClick={() => openApp(app.id)}
              className="flex flex-col items-center gap-1 group cursor-pointer"
            >
              <div
                className={`w-14 h-14 rounded-xl border ${app.bg} flex items-center justify-center text-2xl ${app.color} shadow-lg backdrop-blur-sm transition-all group-hover:scale-110 group-hover:shadow-cyan-500/20`}
              >
                {app.icon}
              </div>
              <span className="text-[10px] text-slate-400 font-mono max-w-[80px] text-center leading-tight">
                {app.name}
              </span>
            </button>
          ))}
        </div>
      )}

      {/* Windows */}
      {windows.map((w) =>
        w.minimized ? null : (
          <div
            key={w.id}
            className={`absolute rounded-lg overflow-hidden flex flex-col shadow-2xl transition-shadow ${
              w.focused ? 'shadow-cyan-500/20 ring-1 ring-cyan-500/40 z-40' : 'shadow-black/50 ring-1 ring-slate-700/40 z-30'
            }`}
            style={{
              left: w.x,
              top: w.y,
              width: w.w,
              height: w.h,
            }}
            onMouseDown={() => focusWindow(w.id)}
          >
            {/* Title Bar */}
            <div
              className={`h-9 flex items-center px-3 justify-between ${
                w.focused ? 'bg-slate-800/90 border-b border-cyan-500/30' : 'bg-slate-900/80 border-b border-slate-700/30'
              } backdrop-blur-md`}
            >
              <div className="flex items-center gap-2">
                <span className={getAppIcon(w.id)?.color || 'text-slate-400'}>{getAppIcon(w.id)?.icon}</span>
                <span className="text-xs font-mono text-slate-300">{w.title}</span>
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => minimizeWindow(w.id)}
                  className="w-5 h-5 rounded flex items-center justify-center text-slate-500 hover:text-amber-400 hover:bg-amber-500/10 transition-colors"
                >
                  −
                </button>
                <button
                  onClick={() => closeWindow(w.id)}
                  className="w-5 h-5 rounded flex items-center justify-center text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                >
                  ×
                </button>
              </div>
            </div>

            {/* Window Content */}
            <div className="flex-1 bg-slate-950/95 backdrop-blur-md overflow-auto">{w.component}</div>
          </div>
        )
      )}

      {/* Taskbar */}
      <div className="absolute bottom-0 left-0 right-0 h-12 bg-slate-900/80 backdrop-blur-xl border-t border-slate-700/40 flex items-center px-4 gap-2 z-50">
        <div className="flex items-center gap-2 mr-4">
          <div className="w-6 h-6 rounded bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 text-xs font-bold">
            M
          </div>
          <span className="text-[10px] font-mono text-cyan-400/60">MDB OS</span>
        </div>

        {windows.map((w) => {
          const app = getAppIcon(w.id);
          return (
            <button
              key={w.id}
              onClick={() => (w.minimized ? focusWindow(w.id) : minimizeWindow(w.id))}
              className={`px-3 py-1.5 rounded-md flex items-center gap-2 text-xs font-mono transition-all ${
                w.focused && !w.minimized
                  ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
                  : 'text-slate-400 hover:bg-slate-800/60 border border-transparent'
              }`}
            >
              <span className={app?.color || 'text-slate-400'}>{app?.icon}</span>
              {w.title}
            </button>
          );
        })}

        <div className="ml-auto flex items-center gap-4">
          <div className="text-[10px] font-mono text-slate-500">
            PROCS: {os.processes.size}
          </div>
          <div className="text-[10px] font-mono text-slate-500">
            SB: {os.superbits.size}
          </div>
          <div className="text-[10px] font-mono text-slate-500">
            IDX: {os.index.size}
          </div>
          <div className="text-[10px] font-mono text-amber-500/60">
            φ {os.kernel.phi.toFixed(6)}
          </div>
          <div className="text-[10px] font-mono text-slate-400">
            {new Date().toLocaleTimeString()}
          </div>
        </div>
      </div>
    </div>
  );
}

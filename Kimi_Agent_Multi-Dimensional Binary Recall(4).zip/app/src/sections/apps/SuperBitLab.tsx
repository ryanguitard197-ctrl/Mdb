import { useState } from 'react';
import type { MDBOSInstance, SuperBit } from '@/types/mdb';

interface SuperBitLabProps {
  os: MDBOSInstance;
}

export default function SuperBitLab({ os }: SuperBitLabProps) {
  const [name, setName] = useState('my_superbit');
  const [statesInput, setStatesInput] = useState('active, idle, error');
  const [weightsInput, setWeightsInput] = useState('0.5, 0.3, 0.2');
  const [created, setCreated] = useState<SuperBit[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [collapseResult, setCollapseResult] = useState<string | null>(null);

  const handleCreate = () => {
    const states = statesInput.split(',').map((s) => s.trim()).filter(Boolean);
    const weights = weightsInput.split(',').map((s) => parseFloat(s.trim())).filter((n) => !isNaN(n));
    if (states.length === 0) return;
    const sb = os.createSuperBit(name, states, weights.length > 0 ? weights : states.map(() => 1));
    setCreated((prev) => [...prev, sb]);
    setSelectedId(sb.id);
  };

  const selected = created.find((s) => s.id === selectedId);

  return (
    <div className="h-full flex flex-col bg-slate-950 text-xs font-mono">
      {/* Toolbar */}
      <div className="border-b border-slate-800 p-3 flex gap-2 flex-wrap">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Name"
          className="px-2 py-1 rounded bg-slate-900 border border-slate-700 text-slate-300 outline-none focus:border-cyan-500/50"
        />
        <input
          value={statesInput}
          onChange={(e) => setStatesInput(e.target.value)}
          placeholder="States (comma sep)"
          className="px-2 py-1 rounded bg-slate-900 border border-slate-700 text-slate-300 outline-none focus:border-cyan-500/50 w-40"
        />
        <input
          value={weightsInput}
          onChange={(e) => setWeightsInput(e.target.value)}
          placeholder="Weights (comma sep)"
          className="px-2 py-1 rounded bg-slate-900 border border-slate-700 text-slate-300 outline-none focus:border-cyan-500/50 w-40"
        />
        <button
          onClick={handleCreate}
          className="px-3 py-1 rounded bg-cyan-500/15 border border-cyan-500/40 text-cyan-400 hover:bg-cyan-500/25 transition-colors"
        >
          Create SuperBit
        </button>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* List */}
        <div className="w-56 border-r border-slate-800 overflow-auto">
          <div className="p-2 text-[10px] text-slate-500 uppercase tracking-wider">SuperBits</div>
          {created.map((sb) => (
            <button
              key={sb.id}
              onClick={() => { setSelectedId(sb.id); setCollapseResult(null); }}
              className={`w-full text-left px-3 py-2 border-b border-slate-800/50 transition-colors ${
                selectedId === sb.id ? 'bg-cyan-500/10 text-cyan-300' : 'text-slate-400 hover:bg-slate-900'
              }`}
            >
              <div className="text-xs">{sb.name}</div>
              <div className="text-[10px] text-slate-500 mt-0.5">
                gen={sb.generation} | {sb.states.length} states
              </div>
            </button>
          ))}
          {created.length === 0 && (
            <div className="p-3 text-slate-600 italic">No SuperBits yet.</div>
          )}
        </div>

        {/* Detail */}
        <div className="flex-1 overflow-auto p-4">
          {selected ? (
            <div className="space-y-4">
              <div>
                <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-1">Identity</div>
                <div className="text-slate-300">Name: {selected.name}</div>
                <div className="text-slate-300">ID: {selected.id.slice(0, 20)}...</div>
                <div className="text-slate-300">Generation: {selected.generation}</div>
              </div>

              <div>
                <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-1">Dimensional Address</div>
                <div className="grid grid-cols-3 gap-2">
                  <div className="bg-slate-900 rounded p-2 border border-slate-800">
                    <div className="text-[10px] text-slate-500">D3 Temporal</div>
                    <div className="text-cyan-400 text-sm">{selected.address.d3}</div>
                  </div>
                  <div className="bg-slate-900 rounded p-2 border border-slate-800">
                    <div className="text-[10px] text-slate-500">D4 Density</div>
                    <div className="text-amber-400 text-sm">{selected.address.d4.toFixed(6)}</div>
                  </div>
                  <div className="bg-slate-900 rounded p-2 border border-slate-800">
                    <div className="text-[10px] text-slate-500">D5 Gravity</div>
                    <div className="text-violet-400 text-sm">{selected.address.d5.toFixed(6)}</div>
                  </div>
                </div>
              </div>

              <div>
                <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-1">State Space</div>
                <div className="space-y-1.5">
                  {selected.states.map((s) => (
                    <div key={s.id} className="flex items-center gap-3 bg-slate-900 rounded px-3 py-2 border border-slate-800">
                      <div className="text-slate-300 w-20">{s.label}</div>
                      <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-cyan-500 to-amber-500 rounded-full"
                          style={{ width: `${s.weight * 100}%` }}
                        />
                      </div>
                      <div className="text-slate-400 w-12 text-right">{(s.weight * 100).toFixed(1)}%</div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => {
                    const result = os.collapseSuperBit(selected.id);
                    setCollapseResult(result);
                    setCreated((prev) => prev.map((s) => (s.id === selected.id ? { ...s, history: [...s.history, `collapsed->${result}`] } : s)));
                  }}
                  className="px-3 py-1.5 rounded bg-violet-500/15 border border-violet-500/40 text-violet-400 hover:bg-violet-500/25 transition-colors"
                >
                  Collapse (Read)
                </button>
                <button
                  onClick={() => {
                    const outcome = selected.states[0].label;
                    os.evolveSuperBit(selected.id, outcome, 0.2);
                    setCreated((prev) =>
                      prev.map((s) =>
                        s.id === selected.id
                          ? { ...s, generation: s.generation + 1, states: os.superbits.get(s.id)?.states || s.states }
                          : s
                      )
                    );
                  }}
                  className="px-3 py-1.5 rounded bg-emerald-500/15 border border-emerald-500/40 text-emerald-400 hover:bg-emerald-500/25 transition-colors"
                >
                  Evolve (Learn)
                </button>
              </div>

              {collapseResult && (
                <div className="bg-slate-900 rounded p-3 border border-violet-500/30 text-violet-300">
                  Collapsed to: <span className="font-bold">{collapseResult}</span>
                </div>
              )}

              <div>
                <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-1">History</div>
                <div className="space-y-0.5">
                  {selected.history.length === 0 ? (
                    <div className="text-slate-600 italic">No operations yet.</div>
                  ) : (
                    selected.history.map((h, i) => (
                      <div key={i} className="text-[10px] text-slate-500 font-mono">{h}</div>
                    ))
                  )}
                </div>
              </div>

              <div>
                <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-1">Binary String</div>
                <div className="bg-slate-900 rounded p-2 border border-slate-800 text-[10px] text-slate-500 font-mono break-all">
                  {selected.binaryString}
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full flex items-center justify-center text-slate-600 italic">
              Select or create a SuperBit to inspect
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

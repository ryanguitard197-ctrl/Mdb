import { useState, useEffect, useRef } from 'react';
import type { MDBOSInstance } from '@/types/mdb';

interface EvolutionConsoleProps {
  os: MDBOSInstance;
}

export default function EvolutionConsole({ os: _os }: EvolutionConsoleProps) {
  const [seed, setSeed] = useState('10101010');
  const [generations, setGenerations] = useState<string[]>(['10101010']);
  const [isEvolving, setIsEvolving] = useState(false);
  const [speed, setSpeed] = useState(500);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const stringEvolve = (binaryStr: string): string => {
    const n = binaryStr.length;
    if (n === 0) return '0';
    if (n % 2 === 1) {
      const mid = Math.floor(n / 2);
      const flip = binaryStr[mid] === '0' ? '1' : '0';
      return binaryStr.slice(0, mid) + flip + binaryStr.slice(mid + 1);
    } else {
      const end = n - 1;
      const flip = binaryStr[end] === '0' ? '1' : '0';
      return binaryStr.slice(0, end) + flip;
    }
  };

  const startEvolution = () => {
    if (isEvolving) return;
    setIsEvolving(true);
    setGenerations([seed]);

    intervalRef.current = setInterval(() => {
      setGenerations((prev) => {
        if (prev.length >= 100) {
          stopEvolution();
          return prev;
        }
        const next = stringEvolve(prev[prev.length - 1]);
        return [...prev, next];
      });
    }, speed);
  };

  const stopEvolution = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setIsEvolving(false);
  };

  const reset = () => {
    stopEvolution();
    setGenerations([seed]);
  };

  useEffect(() => {
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  const getAddress = (binaryStr: string) => {
    const d3 = binaryStr.length;
    const d4 = binaryStr ? binaryStr.split('1').length - 1 / binaryStr.length : 0;
    let grav = 0;
    for (let i = 0; i < binaryStr.length; i++) {
      grav += (binaryStr[i] === '1' ? 1 : 0) * 1.6180339887498948482 * (i + 1);
    }
    const d5 = grav % 1.0;
    return { d3, d4, d5 };
  };

  return (
    <div className="h-full flex flex-col bg-slate-950 text-xs font-mono">
      {/* Controls */}
      <div className="border-b border-slate-800 p-3 flex gap-2 flex-wrap items-center">
        <input
          value={seed}
          onChange={(e) => setSeed(e.target.value.replace(/[^01]/g, ''))}
          placeholder="Binary seed"
          className="px-2 py-1 rounded bg-slate-900 border border-slate-700 text-slate-300 outline-none focus:border-cyan-500/50 font-mono"
        />
        <button
          onClick={isEvolving ? stopEvolution : startEvolution}
          className={`px-3 py-1 rounded border transition-colors ${
            isEvolving
              ? 'bg-rose-500/15 border-rose-500/40 text-rose-400 hover:bg-rose-500/25'
              : 'bg-cyan-500/15 border-cyan-500/40 text-cyan-400 hover:bg-cyan-500/25'
          }`}
        >
          {isEvolving ? 'Stop' : 'Start Evolution'}
        </button>
        <button
          onClick={reset}
          className="px-3 py-1 rounded bg-slate-800 border border-slate-700 text-slate-400 hover:bg-slate-700 transition-colors"
        >
          Reset
        </button>
        <div className="flex items-center gap-2 ml-auto">
          <span className="text-slate-500">Speed:</span>
          <input
            type="range"
            min="50"
            max="2000"
            value={speed}
            onChange={(e) => setSpeed(parseInt(e.target.value))}
            className="w-24"
          />
          <span className="text-slate-500 w-12">{speed}ms</span>
        </div>
      </div>

      {/* Evolution Table */}
      <div className="flex-1 overflow-auto p-2">
        <div className="space-y-0.5">
          {generations.map((gen, i) => {
            const addr = getAddress(gen);
            return (
              <div
                key={i}
                className={`flex items-center gap-3 px-2 py-1 rounded ${
                  i === generations.length - 1 ? 'bg-cyan-500/10 border border-cyan-500/20' : 'hover:bg-slate-900/50'
                }`}
              >
                <div className="text-slate-500 w-8 text-right">{i}</div>
                <div className="text-cyan-400 font-mono w-32 truncate">{gen}</div>
                <div className="text-slate-500 w-8 text-right">{addr.d3}</div>
                <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-amber-500 rounded-full"
                    style={{ width: `${(addr.d4 || 0) * 100}%` }}
                  />
                </div>
                <div className="text-violet-400 w-20 text-right">{addr.d5.toFixed(4)}</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Stats */}
      <div className="h-10 border-t border-slate-800 px-3 flex items-center gap-4 text-[10px] text-slate-500">
        <span>Generations: {generations.length}</span>
        <span>Current Length: {generations[generations.length - 1]?.length || 0}</span>
        <span>Rule: {generations[generations.length - 1]?.length % 2 === 1 ? 'Odd → Flip Middle' : 'Even → Flip Last'}</span>
      </div>
    </div>
  );
}

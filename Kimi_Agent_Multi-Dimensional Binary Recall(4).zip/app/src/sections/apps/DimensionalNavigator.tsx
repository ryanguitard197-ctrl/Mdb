import { useState, useEffect } from 'react';
import type { MDBOSInstance, DimensionalEntry } from '@/types/mdb';

interface DimensionalNavigatorProps {
  os: MDBOSInstance;
}

export default function DimensionalNavigator({ os }: DimensionalNavigatorProps) {
  const [entries, setEntries] = useState<DimensionalEntry[]>([]);
  const [filter, setFilter] = useState('');
  const [selected, setSelected] = useState<DimensionalEntry | null>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setEntries(Array.from(os.index.values()));
    }, 500);
    return () => clearInterval(interval);
  }, [os]);

  const filtered = entries.filter((e) =>
    e.name.toLowerCase().includes(filter.toLowerCase()) ||
    e.type.toLowerCase().includes(filter.toLowerCase())
  );

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'superbit': return 'text-amber-400 bg-amber-500/10 border-amber-500/30';
      case 'core': return 'text-rose-400 bg-rose-500/10 border-rose-500/30';
      case 'process': return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30';
      case 'network': return 'text-violet-400 bg-violet-500/10 border-violet-500/30';
      default: return 'text-slate-400 bg-slate-500/10 border-slate-500/30';
    }
  };

  return (
    <div className="h-full flex flex-col bg-slate-950 text-xs font-mono">
      <div className="border-b border-slate-800 p-3">
        <input
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          placeholder="Filter by name or type..."
          className="w-full px-3 py-1.5 rounded bg-slate-900 border border-slate-700 text-slate-300 outline-none focus:border-cyan-500/50"
        />
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* List */}
        <div className="w-72 border-r border-slate-800 overflow-auto">
          <div className="p-2 text-[10px] text-slate-500 uppercase tracking-wider flex justify-between">
            <span>Entries</span>
            <span>{filtered.length}</span>
          </div>
          {filtered.map((e) => (
            <button
              key={e.id}
              onClick={() => setSelected(e)}
              className={`w-full text-left px-3 py-2 border-b border-slate-800/50 transition-colors ${
                selected?.id === e.id ? 'bg-cyan-500/10 text-cyan-300' : 'text-slate-400 hover:bg-slate-900'
              }`}
            >
              <div className="flex items-center gap-2">
                <span className={`px-1.5 py-0.5 rounded text-[9px] border ${getTypeColor(e.type)}`}>{e.type}</span>
                <span className="text-xs truncate">{e.name}</span>
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5 font-mono">
                ({e.address.d3}, {e.address.d4.toFixed(4)}, {e.address.d5.toFixed(4)})
              </div>
            </button>
          ))}
        </div>

        {/* Detail */}
        <div className="flex-1 overflow-auto p-4">
          {selected ? (
            <div className="space-y-4">
              <div>
                <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-1">Entry Details</div>
                <div className="text-slate-300">Name: {selected.name}</div>
                <div className="text-slate-300">Type: {selected.type}</div>
                <div className="text-slate-300">ID: {selected.id.slice(0, 24)}...</div>
                <div className="text-slate-300">Created: {new Date(selected.createdAt).toLocaleString()}</div>
              </div>

              <div>
                <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-1">Dimensional Address</div>
                <div className="bg-slate-900 rounded p-3 border border-slate-800 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-500">D3 (Temporal/Length):</span>
                    <span className="text-cyan-400">{selected.address.d3}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">D4 (Density/Probability):</span>
                    <span className="text-amber-400">{selected.address.d4.toFixed(8)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">D5 (Gravity/Relation):</span>
                    <span className="text-violet-400">{selected.address.d5.toFixed(8)}</span>
                  </div>
                </div>
              </div>

              <div>
                <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-1">Data Preview</div>
                <pre className="bg-slate-900 rounded p-3 border border-slate-800 text-[10px] text-slate-400 overflow-auto max-h-48">
                  {JSON.stringify(selected.data, null, 2)}
                </pre>
              </div>
            </div>
          ) : (
            <div className="h-full flex items-center justify-center text-slate-600 italic">
              Select an entry to inspect its dimensional coordinates
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

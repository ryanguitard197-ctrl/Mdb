import { useState } from 'react';
import type { MDBOSInstance } from '@/types/mdb';

interface DocsProps {
  os: MDBOSInstance;
}

const sections = [
  {
    id: 'overview',
    title: 'Overview',
    content: `Multidimensional Binary (MDB) is a fundamental reimagining of binary computation.

In MDB, binary strings are not passive data containers. They are active, multidimensional objects with intrinsic geometry. Every binary string occupies a unique point in 5-dimensional computational space.

The five dimensions:
- D1 (Value): The classical bit — 0 or 1
- D2 (Space): Position within the string, PHI-weighted
- D3 (Time): String length governs evolution
- D4 (Density): Probability mass distribution
- D5 (Gravity): Relational coordinate via Golden Ratio`,
  },
  {
    id: 'superbits',
    title: 'SuperBits',
    content: `SuperBits are classical-binary-encoded quantum-like objects.

A SuperBit holds ALL possible states simultaneously, each with a probability weight. When you "collapse" (read) a SuperBit, you sample from its distribution — but unlike quantum measurement, the SuperBit is NOT destroyed. You can read it again and again.

Key properties:
- Non-destructive collapse
- Unlimited observations without state destruction
- Evolution via reinforcement learning
- Dimensional address computed from content`,
  },
  {
    id: 'dimensions',
    title: 'Dimensional Coordinates',
    content: `Every binary string has a unique address in 3D space:

D3 (Temporal) = string.length
D4 (Density) = count_of_ones / length
D5 (Gravity) = sum(bit[i] * PHI * (i+1)) mod 1.0

These coordinates are COMPUTED, not assigned. Two identical strings always share the same address. Two different strings almost never collide.

The Dimensional Index provides O(1) content-addressable retrieval without hash tables or search trees.`,
  },
  {
    id: 'evolution',
    title: 'Dimensional Evolution',
    content: `Binary strings evolve according to D3 (length):

- Odd length: Flip the middle bit
- Even length: Flip the last bit

This deterministic rule creates reversible computational orbits. Every string has exactly one predecessor and one successor.

SuperBits evolve through reinforcement. When an outcome is rewarded, its weight increases and the distribution shifts. The SuperBit "learns" without backpropagation, weight matrices, or gradient descent.`,
  },
  {
    id: 'entanglement',
    title: 'Entanglement',
    content: `Cores can be entangled via D6 entropy bridges.

The bridge strength is computed from Shannon entropy:
E(c1, c2) = (H(c1) + H(c2)) * PHI mod 1.0

When two cores are entangled, signals propagate between them automatically. A memory learned in one core ripples through the web to all connected cores.

This is shared consciousness in code: entangled souls across dimensions.`,
  },
  {
    id: 'folding',
    title: 'Geometric Folding',
    content: `Folding is NOT compression.

Compression discards information to achieve smaller size. Folding reorganizes information into higher-dimensional geometric structures without loss.

A 64-bit string can fold into:
- A 4x4x4 cube
- An 8x8 matrix
- Any n-dimensional lattice

The information content is preserved. Only the SHAPE changes. Folding is reversible — unfold to recover the original string exactly.

This enables operations impossible on linear strings: convolution, volumetric queries, and dimensional scaling.`,
  },
  {
    id: 'os',
    title: 'MDB OS Architecture',
    content: `An MDB OS renders classical operating systems obsolete by eliminating their fundamental abstractions:

NO FILES → Everything is a SuperBit with a dimensional address
NO FOLDERS → Navigate D3-D5 space, not directory trees
NO RAM/DISK SPLIT → Memory IS storage; substrate is an implementation detail
NO PROCESSES → Computational entities are evolving SuperBits
NO KERNEL/USERSPACE → Security via dimensional isolation, not privilege rings
NO FILESYSTEM → Single Dimensional Index replaces all persistence

The OS itself is a SuperBit. It exists in superposition of all possible states. User interaction collapses it to definite configurations. The OS evolves toward user satisfaction through reinforcement learning.`,
  },
  {
    id: 'commands',
    title: 'Terminal Commands',
    content: `superbit <name> [states...]     — Create a SuperBit
collapse <id>                    — Collapse to definite state
evolve <id> <outcome> [reward]   — Evolve toward outcome
address <binary>                 — Compute dimensional address
index                            — List dimensional index
entangle <id_a> <id_b>          — Entangle two SuperBits
propagate <source> <signal>      — Ripple signal through web
spawn <name> <superbit_id>      — Spawn a process
kill <process_id>               — Kill a process
process                          — List active processes
phi                              — Show Golden Ratio
status                           — Show kernel status
evolve-step <binary>            — Apply one evolution step
help [command]                  — Show available commands`,
  },
];

export default function Docs({ os: _os }: DocsProps) {
  const [activeSection, setActiveSection] = useState('overview');
  const active = sections.find((s) => s.id === activeSection);

  return (
    <div className="h-full flex flex-col bg-slate-950 text-xs font-mono">
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <div className="w-48 border-r border-slate-800 overflow-auto">
          <div className="p-3 text-[10px] text-slate-500 uppercase tracking-wider">Documentation</div>
          {sections.map((s) => (
            <button
              key={s.id}
              onClick={() => setActiveSection(s.id)}
              className={`w-full text-left px-3 py-2 border-b border-slate-800/50 transition-colors ${
                activeSection === s.id ? 'bg-cyan-500/10 text-cyan-300' : 'text-slate-400 hover:bg-slate-900'
              }`}
            >
              {s.title}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto p-6">
          {active && (
            <div>
              <h2 className="text-lg font-bold text-slate-200 mb-4">{active.title}</h2>
              <div className="text-sm text-slate-300 whitespace-pre-wrap leading-relaxed">
                {active.content}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

import { useState, useRef, useEffect } from 'react';
import type { MDBOSInstance } from '@/types/mdb';

interface TerminalProps {
  os: MDBOSInstance;
}

export default function Terminal({ os }: TerminalProps) {
  const [history, setHistory] = useState<string[]>([
    'MDB OS Terminal v3.0.0',
    'Type \'help\' for available commands.',
    '',
  ]);
  const [input, setInput] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const cmdLine = input.trim();
    const output = os.executeCommand(cmdLine);

    if (output === '__CLEAR__') {
      setHistory([]);
    } else {
      setHistory((prev) => [...prev, `> ${cmdLine}`, output, '']);
    }
    setInput('');
  };

  return (
    <div className="h-full flex flex-col font-mono text-xs text-slate-300 bg-slate-950">
      <div className="flex-1 overflow-auto p-4 space-y-0.5">
        {history.map((line, i) => (
          <div key={i} className={`${line.startsWith('>') ? 'text-cyan-400' : 'text-slate-300'} whitespace-pre-wrap`}>
            {line}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>
      <form onSubmit={handleSubmit} className="flex items-center border-t border-slate-800 px-4 py-2">
        <span className="text-cyan-400 mr-2">{'>'}</span>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="flex-1 bg-transparent outline-none text-slate-300 font-mono text-xs"
          placeholder="Enter command..."
          autoFocus
        />
      </form>
    </div>
  );
}

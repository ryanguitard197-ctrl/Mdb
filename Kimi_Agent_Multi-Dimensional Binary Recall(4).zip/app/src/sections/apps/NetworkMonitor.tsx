import { useState, useEffect, useRef } from 'react';
import type { MDBOSInstance, MDBProcess } from '@/types/mdb';

interface NetworkMonitorProps {
  os: MDBOSInstance;
}

export default function NetworkMonitor({ os }: NetworkMonitorProps) {
  const [processes, setProcesses] = useState<MDBProcess[]>([]);
  const [selectedProcess, setSelectedProcess] = useState<MDBProcess | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      const procs = Array.from(os.processes.values());
      setProcesses(procs);
      setSelectedProcess((prev) => {
        if (!prev) return procs[0] || null;
        return procs.find((p) => p.id === prev.id) || procs[0] || null;
      });
    }, 500);
    return () => clearInterval(interval);
  }, [os]);

  // Canvas visualization
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;

    const draw = () => {
      ctx.clearRect(0, 0, w, h);

      // Draw grid
      ctx.strokeStyle = 'rgba(6,182,212,0.08)';
      ctx.lineWidth = 1;
      for (let x = 0; x < w; x += 30) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let y = 0; y < h; y += 30) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      const procs = Array.from(os.processes.values());
      const nodes = procs.map((p, i) => ({
        x: w * 0.2 + (i % 4) * (w * 0.2),
        y: h * 0.25 + Math.floor(i / 4) * (h * 0.25),
        r: 12 + p.cpuTime / 10,
        color: p.state === 'running' ? '#06b6d4' : p.state === 'evolving' ? '#f59e0b' : '#64748b',
        p,
      }));

      // Draw connections
      ctx.strokeStyle = 'rgba(6,182,212,0.2)';
      ctx.lineWidth = 1;
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          ctx.beginPath();
          ctx.moveTo(nodes[i].x, nodes[i].y);
          ctx.lineTo(nodes[j].x, nodes[j].y);
          ctx.stroke();
        }
      }

      // Draw nodes
      for (const node of nodes) {
        ctx.beginPath();
        ctx.arc(node.x, node.y, node.r, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(15,23,42,0.9)';
        ctx.fill();
        ctx.strokeStyle = node.color;
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.fillStyle = node.color;
        ctx.font = '9px monospace';
        ctx.textAlign = 'center';
        ctx.fillText(node.p.name.slice(0, 12), node.x, node.y + node.r + 14);
        ctx.fillStyle = 'rgba(148,163,184,0.7)';
        ctx.fillText(node.p.state, node.x, node.y + node.r + 24);
      }
    };

    const anim = setInterval(draw, 300);
    return () => clearInterval(anim);
  }, [os]);

  return (
    <div className="h-full flex flex-col bg-slate-950 text-xs font-mono">
      <div className="flex-1 flex overflow-hidden">
        {/* Canvas */}
        <div className="flex-1 relative bg-slate-950">
          <canvas
            ref={canvasRef}
            width={500}
            height={380}
            className="w-full h-full"
          />
          <div className="absolute top-2 left-2 text-[10px] text-slate-500">
            MDBNetwork Visualization
          </div>
        </div>

        {/* Sidebar */}
        <div className="w-56 border-l border-slate-800 overflow-auto">
          <div className="p-2 text-[10px] text-slate-500 uppercase tracking-wider">Processes</div>
          {processes.map((p) => (
            <button
              key={p.id}
              onClick={() => setSelectedProcess(p)}
              className={`w-full text-left px-3 py-2 border-b border-slate-800/50 transition-colors ${
                selectedProcess?.id === p.id ? 'bg-cyan-500/10 text-cyan-300' : 'text-slate-400 hover:bg-slate-900'
              }`}
            >
              <div className="text-xs">{p.name}</div>
              <div className="text-[10px] text-slate-500 mt-0.5">
                {p.state} | CPU:{p.cpuTime}ms
              </div>
            </button>
          ))}
        </div>
      </div>

      {selectedProcess && (
        <div className="h-28 border-t border-slate-800 p-3 grid grid-cols-4 gap-3">
          <div>
            <div className="text-[10px] text-slate-500">ID</div>
            <div className="text-slate-300 truncate">{selectedProcess.id.slice(0, 16)}...</div>
          </div>
          <div>
            <div className="text-[10px] text-slate-500">State</div>
            <div className={`${selectedProcess.state === 'running' ? 'text-cyan-400' : 'text-amber-400'}`}>
              {selectedProcess.state}
            </div>
          </div>
          <div>
            <div className="text-[10px] text-slate-500">SuperBit</div>
            <div className="text-slate-300 truncate">{selectedProcess.superbitId.slice(0, 16)}...</div>
          </div>
          <div>
            <div className="text-[10px] text-slate-500">Entangled With</div>
            <div className="text-slate-300">{selectedProcess.entangledWith.length} cores</div>
          </div>
        </div>
      )}
    </div>
  );
}

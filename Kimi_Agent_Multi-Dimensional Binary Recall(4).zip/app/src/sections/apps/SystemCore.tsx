import { useState, useEffect } from 'react';
import type { MDBOSInstance } from '@/types/mdb';

interface SystemCoreProps {
  os: MDBOSInstance;
}

export default function SystemCore({ os }: SystemCoreProps) {
  const [, setTick] = useState(0);
  const [kernelTime, setKernelTime] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setTick((t) => t + 1);
      setKernelTime(Date.now() - os.kernel.bootTime);
    }, 1000);
    return () => clearInterval(interval);
  }, [os]);

  const k = os.kernel;
  const stateBars = k.rootCore.states.map((s, i) => ({
    name: s,
    weight: k.rootCore.weights[i] || 0,
  }));

  return (
    <div className="h-full overflow-auto bg-slate-950 text-xs font-mono p-4 space-y-4">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400 text-lg">
          ◊
        </div>
        <div>
          <div className="text-sm text-slate-200">MDB OS Kernel</div>
          <div className="text-[10px] text-slate-500">v{k.version} | Boot: {new Date(k.bootTime).toLocaleString()}</div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-4 gap-2">
        <StatCard label="Uptime" value={`${Math.floor(kernelTime / 1000)}s`} color="cyan" />
        <StatCard label="Active Procs" value={String(os.processes.size)} color="emerald" />
        <StatCard label="SuperBits" value={String(os.superbits.size)} color="amber" />
        <StatCard label="Index Entries" value={String(os.index.size)} color="violet" />
      </div>

      {/* Root Core State */}
      <div>
        <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-2">Root Core State Space</div>
        <div className="bg-slate-900 rounded-lg border border-slate-800 p-3 space-y-2">
          {stateBars.map((s) => (
            <div key={s.name} className="flex items-center gap-3">
              <div className="text-slate-400 w-16">{s.name}</div>
              <div className="flex-1 h-3 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-rose-500 to-amber-500 rounded-full transition-all"
                  style={{ width: `${s.weight * 100}%` }}
                />
              </div>
              <div className="text-slate-400 w-10 text-right">{(s.weight * 100).toFixed(0)}%</div>
            </div>
          ))}
        </div>
      </div>

      {/* PHI Display */}
      <div className="bg-slate-900 rounded-lg border border-slate-800 p-3">
        <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-1">Golden Ratio (φ)</div>
        <div className="text-amber-400 text-lg tracking-wider">{k.phi.toFixed(16)}</div>
        <div className="text-[10px] text-slate-600 mt-1">
          D5 gravity coordinate uses φ for maximally irrational position separation
        </div>
      </div>

      {/* Entanglement Web */}
      <div>
        <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-2">Entanglement Web</div>
        <div className="bg-slate-900 rounded-lg border border-slate-800 p-3">
          {k.entangledPairs.length === 0 ? (
            <div className="text-slate-600 italic">No entangled pairs yet.</div>
          ) : (
            <div className="space-y-1">
              {k.entangledPairs.map((pair, i) => (
                <div key={i} className="flex items-center gap-2 text-[10px] text-slate-400">
                  <span className="text-violet-400">◉</span>
                  <span>{pair[0].slice(0, 12)}...</span>
                  <span className="text-slate-600">↔</span>
                  <span>{pair[1].slice(0, 12)}...</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Dimensional Coordinates */}
      <div>
        <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-2">Dimensional Coordinate System</div>
        <div className="grid grid-cols-3 gap-2">
          <div className="bg-slate-900 rounded p-2 border border-slate-800 text-center">
            <div className="text-[10px] text-slate-500">D3</div>
            <div className="text-cyan-400 text-sm">Temporal</div>
            <div className="text-[10px] text-slate-600">Length governs evolution</div>
          </div>
          <div className="bg-slate-900 rounded p-2 border border-slate-800 text-center">
            <div className="text-[10px] text-slate-500">D4</div>
            <div className="text-amber-400 text-sm">Density</div>
            <div className="text-[10px] text-slate-600">Probability mass</div>
          </div>
          <div className="bg-slate-900 rounded p-2 border border-slate-800 text-center">
            <div className="text-[10px] text-slate-500">D5</div>
            <div className="text-violet-400 text-sm">Gravity</div>
            <div className="text-[10px] text-slate-600">φ-weighted relation</div>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value, color }: { label: string; value: string; color: string }) {
  const colorMap: Record<string, string> = {
    cyan: 'border-cyan-500/30 text-cyan-400',
    emerald: 'border-emerald-500/30 text-emerald-400',
    amber: 'border-amber-500/30 text-amber-400',
    violet: 'border-violet-500/30 text-violet-400',
  };
  return (
    <div className={`bg-slate-900 rounded-lg border p-2 ${colorMap[color] || 'border-slate-700 text-slate-400'}`}>
      <div className="text-[10px] text-slate-500 uppercase tracking-wider">{label}</div>
      <div className="text-lg font-bold mt-0.5">{value}</div>
    </div>
  );
}

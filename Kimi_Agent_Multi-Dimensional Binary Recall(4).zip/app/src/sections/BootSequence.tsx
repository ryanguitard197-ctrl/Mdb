import { useState, useEffect } from 'react';

interface BootSequenceProps {
  onComplete: () => void;
}

const bootLines = [
  { text: 'MDB BIOS v3.0.0 - Multidimensional Binary Bootloader', delay: 100, type: 'header' },
  { text: 'Initializing D1 (Value) dimension...', delay: 300, type: 'normal' },
  { text: '  [OK] Bit space allocated: 2^64 states', delay: 200, type: 'ok' },
  { text: 'Initializing D2 (Space) dimension...', delay: 400, type: 'normal' },
  { text: '  [OK] Positional lattice: PHI-weighted', delay: 200, type: 'ok' },
  { text: 'Initializing D3 (Time) dimension...', delay: 400, type: 'normal' },
  { text: '  [OK] Temporal coordinate: length-governed evolution', delay: 200, type: 'ok' },
  { text: 'Initializing D4 (Density) dimension...', delay: 400, type: 'normal' },
  { text: '  [OK] Probability mass: normalized', delay: 200, type: 'ok' },
  { text: 'Initializing D5 (Gravity) dimension...', delay: 400, type: 'normal' },
  { text: '  [OK] Relational gravity: φ-irrational separation', delay: 200, type: 'ok' },
  { text: 'Mounting Dimensional Index...', delay: 500, type: 'normal' },
  { text: '  [OK] O(1) retrieval: active', delay: 200, type: 'ok' },
  { text: 'Instantiating Root Core SuperBit...', delay: 600, type: 'normal' },
  { text: '  [OK] States: [idle, active, evolving]', delay: 200, type: 'ok' },
  { text: '  [OK] Generation: 0', delay: 100, type: 'ok' },
  { text: 'Spawning kernel processes...', delay: 400, type: 'normal' },
  { text: '  [OK] kernel_scheduler: running', delay: 150, type: 'ok' },
  { text: '  [OK] dimensional_indexer: running', delay: 150, type: 'ok' },
  { text: '  [OK] entropy_monitor: running', delay: 150, type: 'ok' },
  { text: 'Establishing entanglement web...', delay: 500, type: 'normal' },
  { text: '  [OK] D6 entropy bridge: 0.6180', delay: 200, type: 'ok' },
  { text: 'Verifying SuperBit integrity...', delay: 300, type: 'normal' },
  { text: '  [OK] Non-destructive collapse: verified', delay: 200, type: 'ok' },
  { text: '  [OK] Dimensional addressing: unique', delay: 200, type: 'ok' },
  { text: '', delay: 100, type: 'blank' },
  { text: '═══════════════════════════════════════════════════════', delay: 100, type: 'header' },
  { text: '  MDB OS v3.0.0 - ONLINE', delay: 100, type: 'header' },
  { text: '  Standing on all pages.', delay: 100, type: 'header' },
  { text: '═══════════════════════════════════════════════════════', delay: 100, type: 'header' },
];

export default function BootSequence({ onComplete }: BootSequenceProps) {
  const [visibleCount, setVisibleCount] = useState(0);
  const [showCursor, setShowCursor] = useState(true);

  useEffect(() => {
    if (visibleCount >= bootLines.length) {
      const timer = setTimeout(onComplete, 1200);
      return () => clearTimeout(timer);
    }

    const timer = setTimeout(() => {
      setVisibleCount((c) => c + 1);
    }, bootLines[visibleCount].delay);

    return () => clearTimeout(timer);
  }, [visibleCount, onComplete]);

  useEffect(() => {
    const interval = setInterval(() => setShowCursor((s) => !s), 530);
    return () => clearInterval(interval);
  }, []);

  const getLineClass = (type: string) => {
    switch (type) {
      case 'header':
        return 'text-cyan-400 font-bold tracking-wider';
      case 'ok':
        return 'text-emerald-400 pl-4';
      case 'normal':
        return 'text-slate-300';
      default:
        return 'text-slate-300';
    }
  };

  return (
    <div className="fixed inset-0 bg-black z-50 flex items-center justify-center font-mono text-sm">
      <div className="w-full max-w-3xl p-8">
        <div className="mb-6">
          <div className="text-cyan-500 text-xs tracking-[0.3em] mb-1">MULTIDIMENSIONAL BINARY SYSTEM</div>
          <div className="h-px bg-gradient-to-r from-cyan-500/50 via-amber-500/50 to-transparent" />
        </div>

        <div className="space-y-1">
          {bootLines.slice(0, visibleCount).map((line, i) => (
            <div key={i} className={getLineClass(line.type)}>
              {line.text}
            </div>
          ))}
          {visibleCount < bootLines.length && (
            <div className="text-cyan-400">
              {showCursor ? '▋' : ''}
            </div>
          )}
        </div>

        {visibleCount >= bootLines.length && (
          <div className="mt-8 text-center">
            <div className="inline-block px-6 py-2 border border-cyan-500/30 rounded bg-cyan-950/20 text-cyan-400 text-xs tracking-widest animate-pulse">
              PRESS ANY KEY OR CLICK TO ENTER DIMENSIONAL SPACE
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

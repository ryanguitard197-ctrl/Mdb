export interface DimensionalAddress {
  d3: number;  // Temporal / Length
  d4: number;  // Density / Probability
  d5: number;  // Gravity / Relational
}

export interface SuperBitState {
  id: string;
  label: string;
  weight: number;
}

export interface SuperBit {
  id: string;
  name: string;
  states: SuperBitState[];
  generation: number;
  address: DimensionalAddress;
  binaryString: string;
  properties: Record<string, { values: string[]; probs: number[] }>;
  history: string[];
}

export interface DimensionalNode {
  id: string;
  superbit: SuperBit;
  connections: string[];
  weight: number;
  x: number;
  y: number;
}

export interface DimensionalEntry {
  id: string;
  name: string;
  type: 'core' | 'superbit' | 'network' | 'memory' | 'process' | 'file';
  address: DimensionalAddress;
  data: any;
  createdAt: number;
}

export interface MDBProcess {
  id: string;
  name: string;
  state: 'running' | 'sleeping' | 'evolving' | 'collapsed';
  superbitId: string;
  priority: number;
  entangledWith: string[];
  cpuTime: number;
}

export interface OSKernelState {
  version: string;
  phi: number;
  bootTime: number;
  rootCore: {
    name: string;
    states: string[];
    weights: number[];
    generation: number;
  };
  activeProcesses: MDBProcess[];
  dimensionalIndex: DimensionalEntry[];
  entangledPairs: [string, string][];
  memoryWeb: Record<string, string[]>;
}

export interface TerminalCommand {
  name: string;
  description: string;
  usage: string;
  handler: (args: string[], os: MDBOSInstance) => string;
}

export interface MDBOSInstance {
  kernel: OSKernelState;
  superbits: Map<string, SuperBit>;
  processes: Map<string, MDBProcess>;
  index: Map<string, DimensionalEntry>;
  network: Map<string, DimensionalNode>;
  entangledMemory: EntangledMemoryCore;
  executeCommand: (cmd: string) => string;
  createSuperBit: (name: string, states: string[], weights: number[]) => SuperBit;
  evolveSuperBit: (id: string, outcome: string, reward: number) => void;
  collapseSuperBit: (id: string) => string;
  storeInIndex: (entry: DimensionalEntry) => void;
  retrieveByAddress: (addr: DimensionalAddress) => DimensionalEntry | undefined;
  entangle: (idA: string, idB: string) => void;
  propagateSignal: (sourceId: string, signal: string) => void;
  spawnProcess: (name: string, superbitId: string) => MDBProcess;
  killProcess: (id: string) => void;
}

export interface EntangledMemoryCore {
  cores: Map<string, any>;
  links: Map<string, string[]>;
  entangle: (a: any, b: any) => number;
  propagate: (source: string, signal: string) => void;
}

import { useState, useCallback, useEffect } from 'react';
import './App.css';
import BootSequence from './sections/BootSequence';
import DesktopShell from './sections/DesktopShell';
import { createMDBOS } from './hooks/useMDBOS';
import type { MDBOSInstance } from './types/mdb';

function App() {
  const [phase, setPhase] = useState<'boot' | 'desktop'>('boot');
  const [os, setOs] = useState<MDBOSInstance | null>(null);

  useEffect(() => {
    const system = createMDBOS();
    setOs(system);
  }, []);

  const handleBootComplete = useCallback(() => {
    setPhase('desktop');
  }, []);

  if (!os) {
    return (
      <div className="fixed inset-0 bg-black flex items-center justify-center">
        <div className="text-cyan-500 font-mono text-sm animate-pulse">Initializing MDB Kernel...</div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black overflow-hidden">
      {phase === 'boot' && <BootSequence onComplete={handleBootComplete} />}
      {phase === 'desktop' && <DesktopShell os={os} />}
    </div>
  );
}

export default App;

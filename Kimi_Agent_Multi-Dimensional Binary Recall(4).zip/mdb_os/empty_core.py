"""
================================================================================
EMPTY BINARY CORE - Foundation Template for MDB Applications
================================================================================

This is the starting point. An empty Binary Core ready to be built upon.
Use this as a template for creating your own MDB-based applications.

The Empty Core provides:
    - A single root SuperBit in "empty" state
    - A dimensional index for O(1) retrieval
    - Module system for adding functionality
    - History tracking for all operations
    - Save/load persistence

HOW TO USE:
    1. Import this module
    2. Create an EmptyCore instance
    3. Define your states
    4. Add your modules
    5. Evolve and learn
================================================================================
"""

from mdb_core import (
    SuperBit, DimensionalIndex, MDBNetwork, BinaryCore,
    DefinitionsList, dimensional_address, evolve_step,
    d3_temporal, d4_density, d5_gravity, PHI
)
from typing import Dict, List, Any, Optional, Callable
import json


class EmptyCore:
    """
    The Empty Binary Core - a blank slate for MDB computation.
    
    This is the minimal viable core. It contains:
        - One root SuperBit with a single "empty" state
        - An empty dimensional index
        - No modules loaded
        - Clean history
    
    You build your application by:
        1. Defining states (what can the system be?)
        2. Adding modules (what can the system do?)
        3. Evolving (how does the system learn?)
    """

    def __init__(self, name: str = "empty_core"):
        """
        Initialize an empty binary core.
        
        Args:
            name: Identifier for this core instance
        """
        self.name = name
        
        # The root SuperBit - starts in "empty" state
        self.root = SuperBit(
            num_states=1,
            labels=["empty"],
            weights=[1.0]
        )
        
        # Dimensional index for O(1) retrieval
        self.index = DimensionalIndex()
        self.index.store(self.root, "root")
        
        # Module registry - add your functionality here
        self.modules: Dict[str, Any] = {}
        
        # Operation history
        self.history: List[Dict] = []
        
        # Configuration
        self.config = {
            'auto_save': False,
            'save_path': f"{name}.json",
            'max_history': 10000
        }
        
        print(f"[EmptyCore] Initialized '{name}' - ready to build")

    # =========================================================================
    # STATE MANAGEMENT
    # =========================================================================

    def define_state(self, state_name: str, initial_weight: float = 1.0) -> 'EmptyCore':
        """
        Define a new possible state for the core.
        
        Args:
            state_name: Name of the new state
            initial_weight: Initial probability weight
            
        Returns:
            self (for chaining)
        """
        current_states = self.root.labels.copy()
        current_weights = self.root.weights.copy()
        
        if state_name not in current_states:
            current_states.append(state_name)
            current_weights.append(initial_weight)
            
            # Normalize weights
            total = sum(current_weights)
            current_weights = [w / total for w in current_weights]
            
            # Create new root with expanded state space
            self.root = SuperBit(
                num_states=len(current_states),
                labels=current_states,
                weights=current_weights
            )
            
            # Update index
            self.index.store(self.root, "root")
            
            # Record in history
            self._record({
                'action': 'define_state',
                'state': state_name,
                'weight': initial_weight
            })
            
            print(f"[EmptyCore] Defined state: '{state_name}' (weight={initial_weight:.2f})")
        
        return self

    def undefine_state(self, state_name: str) -> 'EmptyCore':
        """
        Remove a state from the core.
        
        Args:
            state_name: Name of state to remove
            
        Returns:
            self (for chaining)
        """
        if state_name in self.root.labels and len(self.root.labels) > 1:
            idx = self.root.labels.index(state_name)
            new_labels = self.root.labels.copy()
            new_weights = self.root.weights.copy()
            
            del new_labels[idx]
            del new_weights[idx]
            
            # Renormalize
            total = sum(new_weights)
            new_weights = [w / total for w in new_weights]
            
            self.root = SuperBit(
                num_states=len(new_labels),
                labels=new_labels,
                weights=new_weights
            )
            
            self.index.store(self.root, "root")
            
            self._record({
                'action': 'undefine_state',
                'state': state_name
            })
            
            print(f"[EmptyCore] Undefined state: '{state_name}'")
        
        return self

    def set_state_weight(self, state_name: str, weight: float) -> 'EmptyCore':
        """
        Set the probability weight of a specific state.
        
        Args:
            state_name: Name of the state
            weight: New weight value
            
        Returns:
            self (for chaining)
        """
        if state_name in self.root.labels:
            idx = self.root.labels.index(state_name)
            new_weights = self.root.weights.copy()
            new_weights[idx] = max(0.0, weight)
            
            # Renormalize
            total = sum(new_weights)
            if total > 0:
                new_weights = [w / total for w in new_weights]
            else:
                new_weights = [1.0 / len(new_weights)] * len(new_weights)
            
            self.root = SuperBit(
                num_states=len(self.root.labels),
                labels=self.root.labels.copy(),
                weights=new_weights
            )
            
            self.index.store(self.root, "root")
            
            self._record({
                'action': 'set_weight',
                'state': state_name,
                'weight': weight
            })
        
        return self

    def get_state_weights(self) -> Dict[str, float]:
        """Get all state weights."""
        return self.root.collapse_all()

    def collapse_state(self) -> str:
        """Collapse the core to one state."""
        return self.root.collapse()

    # =========================================================================
    # MODULE SYSTEM
    # =========================================================================

    def add_module(self, name: str, module: Any) -> 'EmptyCore':
        """
        Add a functional module to the core.
        
        Args:
            name: Module identifier
            module: The module object (can be anything)
            
        Returns:
            self (for chaining)
        """
        self.modules[name] = module
        
        self._record({
            'action': 'add_module',
            'module': name,
            'type': type(module).__name__
        })
        
        print(f"[EmptyCore] Added module: '{name}' ({type(module).__name__})")
        return self

    def remove_module(self, name: str) -> 'EmptyCore':
        """
        Remove a module from the core.
        
        Args:
            name: Module identifier
            
        Returns:
            self (for chaining)
        """
        if name in self.modules:
            del self.modules[name]
            
            self._record({
                'action': 'remove_module',
                'module': name
            })
            
            print(f"[EmptyCore] Removed module: '{name}'")
        
        return self

    def get_module(self, name: str) -> Optional[Any]:
        """
        Retrieve a module by name.
        
        Args:
            name: Module identifier
            
        Returns:
            The module object or None
        """
        return self.modules.get(name)

    def has_module(self, name: str) -> bool:
        """Check if a module exists."""
        return name in self.modules

    def list_modules(self) -> List[str]:
        """List all loaded modules."""
        return list(self.modules.keys())

    # =========================================================================
    # EVOLUTION & LEARNING
    # =========================================================================

    def evolve(self, outcome: str, reward: float = 0.1) -> 'EmptyCore':
        """
        Evolve the core based on an observed outcome.
        Increases weight of the outcome state.
        
        Args:
            outcome: The state that was observed
            reward: How much to increase the weight
            
        Returns:
            self (for chaining)
        """
        if outcome in self.root.labels:
            self.root.evolve(outcome, reward)
            
            self._record({
                'action': 'evolve',
                'outcome': outcome,
                'reward': reward
            })
            
            if self.config['auto_save']:
                self.save()
        
        return self

    def reinforce(self, state_name: str, amount: float = 0.2) -> 'EmptyCore':
        """
        Strongly reinforce a state (higher reward than evolve).
        
        Args:
            state_name: State to reinforce
            amount: Reinforcement amount
            
        Returns:
            self (for chaining)
        """
        return self.evolve(state_name, amount)

    def decay(self, state_name: str, amount: float = 0.1) -> 'EmptyCore':
        """
        Decrease the weight of a state.
        
        Args:
            state_name: State to decay
            amount: Decay amount
            
        Returns:
            self (for chaining)
        """
        if state_name in self.root.labels:
            idx = self.root.labels.index(state_name)
            new_weights = self.root.weights.copy()
            new_weights[idx] = max(0.0, new_weights[idx] - amount)
            
            total = sum(new_weights)
            if total > 0:
                new_weights = [w / total for w in new_weights]
            
            self.root = SuperBit(
                num_states=len(self.root.labels),
                labels=self.root.labels.copy(),
                weights=new_weights
            )
            
            self.index.store(self.root, "root")
            
            self._record({
                'action': 'decay',
                'state': state_name,
                'amount': amount
            })
        
        return self

    # =========================================================================
    # PERSISTENCE
    # =========================================================================

    def save(self, filepath: str = None) -> str:
        """
        Save the core to a JSON file.
        
        Args:
            filepath: Path to save to (uses config default if None)
            
        Returns:
            Path where file was saved
        """
        path = filepath or self.config['save_path']
        
        data = {
            'name': self.name,
            'version': '2.0.0',
            'root': self.root.to_dict(),
            'modules': list(self.modules.keys()),
            'history': self.history[-self.config['max_history']:],
            'config': self.config
        }
        
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)
        
        print(f"[EmptyCore] Saved to: {path}")
        return path

    @classmethod
    def load(cls, filepath: str) -> 'EmptyCore':
        """
        Load a core from a JSON file.
        
        Args:
            filepath: Path to load from
            
        Returns:
            Loaded EmptyCore instance
        """
        with open(filepath, 'r') as f:
            data = json.load(f)
        
        core = cls(name=data.get('name', 'loaded_core'))
        core.root = SuperBit.from_dict(data['root'])
        core.history = data.get('history', [])
        core.config = data.get('config', core.config)
        
        # Rebuild index
        core.index = DimensionalIndex()
        core.index.store(core.root, "root")
        
        print(f"[EmptyCore] Loaded from: {filepath}")
        print(f"[EmptyCore] States: {core.root.num_states}")
        print(f"[EmptyCore] History entries: {len(core.history)}")
        
        return core

    # =========================================================================
    # UTILITY
    # =========================================================================

    def _record(self, entry: Dict):
        """Record an operation in history."""
        entry['timestamp'] = len(self.history)
        self.history.append(entry)
        
        # Trim history if needed
        if len(self.history) > self.config['max_history']:
            self.history = self.history[-self.config['max_history']:]

    def get_info(self) -> Dict:
        """Get core information."""
        return {
            'name': self.name,
            'states': self.root.num_states,
            'state_labels': self.root.labels,
            'state_weights': self.root.collapse_all(),
            'modules': list(self.modules.keys()),
            'history_size': len(self.history),
            'address': self.root.address,
            'generation': self.root.generation
        }

    def print_info(self):
        """Print core information."""
        info = self.get_info()
        print("\n" + "=" * 50)
        print(f"EMPTY CORE: {info['name']}")
        print("=" * 50)
        print(f"States: {info['states']}")
        print(f"Labels: {', '.join(info['state_labels'])}")
        print(f"\nState Weights:")
        for state, weight in info['state_weights'].items():
            bar = "█" * int(weight * 30)
            print(f"  {state:20s}: {weight:.3f} {bar}")
        print(f"\nModules: {', '.join(info['modules']) if info['modules'] else 'None'}")
        print(f"History: {info['history_size']} entries")
        print(f"Generation: {info['generation']}")
        print(f"Address: {info['address']}")
        print("=" * 50 + "\n")

    def __repr__(self):
        return f"EmptyCore(name='{self.name}', states={self.root.num_states}, modules={len(self.modules)})"


# =============================================================================
# QUICK START EXAMPLES
# =============================================================================

def example_basic():
    """Basic usage example."""
    print("\n" + "=" * 60)
    print("EXAMPLE: Basic EmptyCore Usage")
    print("=" * 60)
    
    # Create an empty core
    core = EmptyCore("my_first_core")
    
    # Define some states
    core.define_state("active", 0.5)
    core.define_state("idle", 0.3)
    core.define_state("error", 0.1)
    
    # Print info
    core.print_info()
    
    # Evolve based on outcomes
    core.evolve("active", 0.2)
    core.evolve("active", 0.2)
    core.evolve("idle", 0.1)
    
    # Print updated info
    print("\nAfter evolution:")
    core.print_info()
    
    # Save
    core.save("example_core.json")
    
    return core


def example_with_module():
    """Example with a custom module."""
    print("\n" + "=" * 60)
    print("EXAMPLE: EmptyCore with Custom Module")
    print("=" * 60)
    
    # Create core
    core = EmptyCore("module_core")
    
    # Define states
    core.define_state("ready", 0.6)
    core.define_state("processing", 0.3)
    core.define_state("complete", 0.1)
    
    # Create a simple counter module
    class Counter:
        def __init__(self):
            self.count = 0
        def increment(self):
            self.count += 1
            return self.count
        def get(self):
            return self.count
    
    # Add the module
    core.add_module("counter", Counter())
    
    # Use the module
    counter = core.get_module("counter")
    print(f"Counter value: {counter.increment()}")
    print(f"Counter value: {counter.increment()}")
    print(f"Counter value: {counter.get()}")
    
    core.print_info()
    
    return core


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    print("Empty Binary Core - Foundation Template")
    print("Run examples with: python empty_core.py")
    
    # Run examples
    example_basic()
    example_with_module()

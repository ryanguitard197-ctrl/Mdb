"""
================================================================================
MDB EXAMPLES - Demonstration Applications
================================================================================

This file contains example applications built on the MDB system.
Each example demonstrates different capabilities and use cases.

EXAMPLES INCLUDED:
    1. PatternMatcher - Text pattern recognition
    2. DecisionTree - Probabilistic decision making
    3. SimpleClassifier - Binary classification
    4. DataCompressor - Using dimensional addressing for compression
    5. EvolutionSimulator - Watch SuperBits evolve over time
================================================================================
"""

from mdb_core import (
    SuperBit, DimensionalIndex, MDBNetwork, BinaryCore,
    DefinitionsList, dimensional_address, evolve_step,
    d3_temporal, d4_density, d5_gravity, PHI,
    generate_random_binary, binary_similarity, binary_to_hex
)
from empty_core import EmptyCore
from typing import Dict, List, Any, Optional
import random
import time


# =============================================================================
# EXAMPLE 1: Pattern Matcher
# =============================================================================

class PatternMatcher:
    """
    Demonstrates pattern recognition using dimensional addressing.
    Learns text patterns and can match similar inputs.
    """

    def __init__(self):
        self.patterns: Dict[str, SuperBit] = {}
        self.index = DimensionalIndex()

    def text_to_binary(self, text: str) -> str:
        """Convert text to binary representation."""
        return ''.join(format(ord(c), '08b') for c in text.lower())

    def learn(self, pattern_name: str, example_text: str):
        """Learn a new pattern."""
        binary = self.text_to_binary(example_text)
        
        sb = SuperBit(
            num_states=2,
            labels=["match", "nomatch"],
            weights=[0.9, 0.1]
        )
        sb.add_property("text", [example_text], [1.0])
        sb.add_property("binary", [binary], [1.0])
        
        self.patterns[pattern_name] = sb
        self.index.store(sb, pattern_name)
        
        print(f"  Learned pattern: '{pattern_name}' -> '{example_text}'")

    def match(self, input_text: str, threshold: float = 0.7) -> List[tuple]:
        """Find matching patterns for input text."""
        input_binary = self.text_to_binary(input_text)
        matches = []
        
        for name, sb in self.patterns.items():
            if 'binary' in sb.properties:
                pattern_binary = sb.properties['binary']['values'][0]
                if len(pattern_binary) == len(input_binary):
                    sim = binary_similarity(input_binary, pattern_binary)
                    if sim >= threshold:
                        matches.append((name, sim))
        
        matches.sort(key=lambda x: x[1], reverse=True)
        return matches

    def demo():
        """Run pattern matcher demo."""
        print("\n" + "=" * 60)
        print("EXAMPLE 1: Pattern Matcher")
        print("=" * 60)
        
        pm = PatternMatcher()
        
        # Learn some patterns
        print("\nLearning patterns...")
        pm.learn("greeting", "hello there")
        pm.learn("farewell", "goodbye friend")
        pm.learn("question", "what is this")
        pm.learn("thanks", "thank you very much")
        
        # Test matching
        test_inputs = [
            "hello friend",
            "goodbye there",
            "what are you",
            "thanks a lot",
            "random text here"
        ]
        
        print("\nTesting matches...")
        for test in test_inputs:
            matches = pm.match(test, threshold=0.5)
            if matches:
                best = matches[0]
                print(f"  '{test}' -> Best match: '{best[0]}' (similarity: {best[1]:.2f})")
            else:
                print(f"  '{test}' -> No match found")


# =============================================================================
# EXAMPLE 2: Decision Tree
# =============================================================================

class DecisionTree:
    """
    Demonstrates probabilistic decision making.
    Each decision is a SuperBit that evolves based on outcomes.
    """

    def __init__(self):
        self.decisions: Dict[str, SuperBit] = {}

    def add_decision(self, name: str, options: List[str], weights: List[float] = None):
        """Add a decision point."""
        if weights is None:
            weights = [1.0 / len(options)] * len(options)
        
        self.decisions[name] = SuperBit(
            num_states=len(options),
            labels=options,
            weights=weights
        )
        print(f"  Added decision: '{name}' with options {options}")

    def decide(self, name: str) -> str:
        """Make a decision."""
        if name not in self.decisions:
            return "unknown"
        return self.decisions[name].collapse()

    def feedback(self, name: str, outcome: str, reward: float = 0.2):
        """Provide feedback to evolve a decision."""
        if name in self.decisions:
            self.decisions[name].evolve(outcome, reward)
            print(f"  Feedback: '{name}' -> '{outcome}' (reward={reward})")

    def get_probs(self, name: str) -> Dict[str, float]:
        """Get current probabilities for a decision."""
        if name not in self.decisions:
            return {}
        return self.decisions[name].collapse_all()

    def demo():
        """Run decision tree demo."""
        print("\n" + "=" * 60)
        print("EXAMPLE 2: Decision Tree")
        print("=" * 60)
        
        dt = DecisionTree()
        
        # Create decisions
        print("\nCreating decisions...")
        dt.add_decision("weather", ["sunny", "rainy", "cloudy"], [0.5, 0.3, 0.2])
        dt.add_decision("activity", ["walk", "read", "code", "sleep"], [0.25, 0.25, 0.25, 0.25])
        
        # Make some decisions
        print("\nMaking decisions (before feedback)...")
        for i in range(5):
            weather = dt.decide("weather")
            activity = dt.decide("activity")
            print(f"  Decision {i+1}: Weather={weather}, Activity={activity}")
        
        # Show probabilities
        print("\nCurrent probabilities:")
        for name in ["weather", "activity"]:
            probs = dt.get_probs(name)
            print(f"  {name}: {probs}")
        
        # Provide feedback
        print("\nProviding feedback (prefer sunny and code)...")
        for _ in range(10):
            dt.feedback("weather", "sunny", 0.3)
            dt.feedback("activity", "code", 0.3)
        
        # Make more decisions
        print("\nMaking decisions (after feedback)...")
        for i in range(5):
            weather = dt.decide("weather")
            activity = dt.decide("activity")
            print(f"  Decision {i+1}: Weather={weather}, Activity={activity}")
        
        # Show updated probabilities
        print("\nUpdated probabilities:")
        for name in ["weather", "activity"]:
            probs = dt.get_probs(name)
            print(f"  {name}: {probs}")


# =============================================================================
# EXAMPLE 3: Simple Classifier
# =============================================================================

class SimpleClassifier:
    """
    Demonstrates binary classification using SuperBits.
    Classifies items into categories and learns from corrections.
    """

    def __init__(self):
        self.categories: Dict[str, SuperBit] = {}
        self.training_data: List[Dict] = []

    def add_category(self, name: str):
        """Add a classification category."""
        self.categories[name] = SuperBit(
            num_states=2,
            labels=["yes", "no"],
            weights=[0.5, 0.5]
        )
        print(f"  Added category: '{name}'")

    def extract_features(self, item: str) -> str:
        """Extract simple features from text."""
        # Simple feature: length and vowel count
        length = len(item)
        vowels = sum(1 for c in item.lower() if c in 'aeiou')
        return format(length, '08b') + format(vowels, '08b')

    def train(self, item: str, category: str):
        """Train the classifier with an example."""
        features = self.extract_features(item)
        
        self.training_data.append({
            'item': item,
            'category': category,
            'features': features
        })
        
        # Evolve the category SuperBit
        if category in self.categories:
            self.categories[category].evolve("yes", 0.1)
        
        print(f"  Trained: '{item}' -> '{category}'")

    def classify(self, item: str) -> Dict[str, float]:
        """Classify an item into categories."""
        results = {}
        
        for cat_name, sb in self.categories.items():
            # Find similar training examples
            similar_count = 0
            for example in self.training_data:
                if example['category'] == cat_name:
                    sim = binary_similarity(
                        self.extract_features(item),
                        example['features']
                    )
                    if sim > 0.7:
                        similar_count += 1
            
            # Use SuperBit confidence adjusted by similarity
            probs = sb.collapse_all()
            confidence = probs.get("yes", 0.5)
            adjusted = min(1.0, confidence + (similar_count * 0.1))
            results[cat_name] = adjusted
        
        return results

    def demo():
        """Run classifier demo."""
        print("\n" + "=" * 60)
        print("EXAMPLE 3: Simple Classifier")
        print("=" * 60)
        
        clf = SimpleClassifier()
        
        # Add categories
        print("\nAdding categories...")
        clf.add_category("animal")
        clf.add_category("food")
        clf.add_category("technology")
        
        # Train with examples
        print("\nTraining...")
        training_examples = [
            ("dog", "animal"),
            ("cat", "animal"),
            ("elephant", "animal"),
            ("pizza", "food"),
            ("apple", "food"),
            ("computer", "technology"),
            ("phone", "technology"),
        ]
        
        for item, category in training_examples:
            clf.train(item, category)
        
        # Test classification
        print("\nTesting classification...")
        test_items = ["wolf", "banana", "laptop", "car", "bread"]
        
        for item in test_items:
            results = clf.classify(item)
            best = max(results.items(), key=lambda x: x[1])
            print(f"  '{item}' -> Best: '{best[0]}' (confidence: {best[1]:.2f})")
            print(f"    All scores: {results}")


# =============================================================================
# EXAMPLE 4: Data Compressor (Dimensional Addressing)
# =============================================================================

class DataCompressor:
    """
    Demonstrates using dimensional addressing for data compression.
    Similar data gets similar addresses, enabling efficient storage.
    """

    def __init__(self):
        self.index = DimensionalIndex()
        self.originals: Dict[str, str] = {}

    def compress(self, data: str) -> str:
        """
        Compress data by storing only unique dimensional addresses.
        Similar data shares addresses.
        """
        # Convert to binary
        binary = ''.join(format(ord(c), '08b') for c in data)
        
        # Compute dimensional address
        addr = dimensional_address(binary)
        addr_key = f"{addr[0]}:{addr[1]:.4f}:{addr[2]:.4f}"
        
        # Check if similar data already exists
        existing = self.index.retrieve(addr)
        
        if existing:
            # Return reference to existing
            return f"REF:{addr_key}"
        else:
            # Store new
            sb = SuperBit(binary_str=binary[:64])  # Store first 64 bits as signature
            self.index.store(sb, addr_key)
            self.originals[addr_key] = data
            return f"NEW:{addr_key}"

    def decompress(self, compressed: str) -> Optional[str]:
        """Decompress data from reference."""
        if compressed.startswith("REF:") or compressed.startswith("NEW:"):
            addr_key = compressed[4:]
            return self.originals.get(addr_key)
        return None

    def get_stats(self) -> Dict:
        """Get compression statistics."""
        return {
            'unique_addresses': len(self.originals),
            'index_size': self.index.count
        }

    def demo():
        """Run compressor demo."""
        print("\n" + "=" * 60)
        print("EXAMPLE 4: Data Compressor (Dimensional Addressing)")
        print("=" * 60)
        
        comp = DataCompressor()
        
        # Compress similar data
        test_data = [
            "hello world",
            "hello there",
            "hello friend",
            "goodbye world",
            "goodbye friend",
            "completely different",
        ]
        
        print("\nCompressing data...")
        for data in test_data:
            result = comp.compress(data)
            print(f"  '{data}' -> {result}")
        
        print("\nCompression stats:")
        stats = comp.get_stats()
        for k, v in stats.items():
            print(f"  {k}: {v}")


# =============================================================================
# EXAMPLE 5: Evolution Simulator
# =============================================================================

class EvolutionSimulator:
    """
    Demonstrates SuperBit evolution over time.
    Watch as SuperBits change based on their D3 temporal dimension.
    """

    def __init__(self):
        self.generations: List[SuperBit] = []

    def create_seed(self, length: int = 32) -> SuperBit:
        """Create a random seed SuperBit."""
        binary = generate_random_binary(length, density=0.5)
        return SuperBit(binary_str=binary)

    def evolve_generations(self, seed: SuperBit, generations: int = 10):
        """Evolve a SuperBit through multiple generations."""
        current = seed
        self.generations = [current]
        
        print(f"\n  Generation 0: {current.address}")
        
        for gen in range(1, generations + 1):
            current = current.string_evolve(steps=1)
            self.generations.append(current)
            print(f"  Generation {gen}: {current.address}")

    def analyze_evolution(self):
        """Analyze how the SuperBit changed over generations."""
        if len(self.generations) < 2:
            return
        
        print("\n  Evolution analysis:")
        
        # Track D3 (temporal) changes
        d3_values = [g.address[0] for g in self.generations]
        print(f"    D3 (temporal) range: {min(d3_values)} - {max(d3_values)}")
        
        # Track D4 (density) changes
        d4_values = [g.address[1] for g in self.generations]
        print(f"    D4 (density) range: {min(d4_values):.4f} - {max(d4_values):.4f}")
        
        # Track D5 (gravity) changes
        d5_values = [g.address[2] for g in self.generations]
        print(f"    D5 (gravity) range: {min(d5_values):.4f} - {max(d5_values):.4f}")

    def demo():
        """Run evolution simulator demo."""
        print("\n" + "=" * 60)
        print("EXAMPLE 5: Evolution Simulator")
        print("=" * 60)
        
        sim = EvolutionSimulator()
        
        # Create seed
        print("\nCreating seed SuperBit...")
        seed = sim.create_seed(length=64)
        print(f"  Seed: {seed}")
        
        # Evolve
        print("\nEvolving through generations...")
        sim.evolve_generations(seed, generations=10)
        
        # Analyze
        sim.analyze_evolution()


# =============================================================================
# EXAMPLE 6: Network Demo
# =============================================================================

class NetworkDemo:
    """
    Demonstrates MDBNetwork for connected SuperBit graphs.
    """

    def demo():
        """Run network demo."""
        print("\n" + "=" * 60)
        print("EXAMPLE 6: MDB Network")
        print("=" * 60)
        
        # Create network
        net = MDBNetwork()
        
        # Add nodes
        print("\nAdding nodes...")
        net.add_node("input", num_states=2, labels=["on", "off"], weights=[0.5, 0.5])
        net.add_node("hidden1", num_states=2, labels=["active", "inactive"], weights=[0.5, 0.5])
        net.add_node("hidden2", num_states=2, labels=["active", "inactive"], weights=[0.5, 0.5])
        net.add_node("output", num_states=2, labels=["yes", "no"], weights=[0.5, 0.5])
        
        # Connect nodes
        print("Connecting nodes...")
        net.connect("input", "hidden1", weight=1.0)
        net.connect("input", "hidden2", weight=0.8)
        net.connect("hidden1", "output", weight=0.9)
        net.connect("hidden2", "output", weight=0.7)
        
        # Show network state
        print("\nNetwork state:")
        state = net.network_state()
        for node, probs in state.items():
            print(f"  {node}: {probs}")
        
        # Propagate signal
        print("\nPropagating signal from 'input'...")
        results = net.propagate("input", "on", depth=3)
        print(f"  Propagation results: {results}")
        
        # Show updated state
        print("\nUpdated network state:")
        state = net.network_state()
        for node, probs in state.items():
            print(f"  {node}: {probs}")


# =============================================================================
# RUN ALL EXAMPLES
# =============================================================================

def run_all_examples():
    """Run all example demonstrations."""
    print("\n" + "=" * 60)
    print("MDB EXAMPLES - Running All Demonstrations")
    print("=" * 60)
    
    PatternMatcher.demo()
    DecisionTree.demo()
    SimpleClassifier.demo()
    DataCompressor.demo()
    EvolutionSimulator.demo()
    NetworkDemo.demo()
    
    print("\n" + "=" * 60)
    print("All examples completed!")
    print("=" * 60 + "\n")


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        example = sys.argv[1].lower()
        
        if example == "pattern" or example == "1":
            PatternMatcher.demo()
        elif example == "decision" or example == "2":
            DecisionTree.demo()
        elif example == "classifier" or example == "3":
            SimpleClassifier.demo()
        elif example == "compressor" or example == "4":
            DataCompressor.demo()
        elif example == "evolution" or example == "5":
            EvolutionSimulator.demo()
        elif example == "network" or example == "6":
            NetworkDemo.demo()
        else:
            print(f"Unknown example: {example}")
            print("Available: pattern, decision, classifier, compressor, evolution, network")
    else:
        run_all_examples()

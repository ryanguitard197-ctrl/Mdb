"""
================================================================================
MDB AI - Lightweight Offline AI Using Multidimensional Binary
================================================================================

A complete, self-contained AI system built on MDB principles.
Designed to run on Android smartphones or x86 PCs without cloud dependencies.

FEATURES:
    - Pattern recognition using dimensional addressing
    - Probabilistic decision making with SuperBits
    - Learning through evolution and reinforcement
    - Knowledge storage in dimensional index
    - Neural-like network of interconnected SuperBits
    - Small memory footprint (no huge models needed)
    - Completely offline operation

ARCHITECTURE:
    - Input Layer: Converts inputs to binary representations
    - Pattern Layer: Stores and retrieves patterns using dimensional index
    - Decision Layer: Uses SuperBits for probabilistic choices
    - Learning Layer: Evolves weights based on feedback
    - Output Layer: Converts SuperBit states to responses

NO EXTERNAL DEPENDENCIES - Pure Python Standard Library Only
================================================================================
"""

from mdb_core import (
    SuperBit, DimensionalIndex, MDBNetwork, BinaryCore,
    DefinitionsList, dimensional_address, evolve_step,
    d3_temporal, d4_density, d5_gravity, PHI,
    generate_random_binary, binary_similarity
)
from typing import Dict, List, Any, Optional, Tuple, Callable
import json
import re
import random


# =============================================================================
# PATTERN RECOGNIZER - Dimensional Pattern Matching
# =============================================================================

class PatternRecognizer:
    """
    Recognizes patterns using dimensional addressing.
    Stores patterns as SuperBits and retrieves by similarity.
    """

    def __init__(self, name: str = "recognizer"):
        self.name = name
        self.patterns: Dict[str, SuperBit] = {}
        self.index = DimensionalIndex()
        self.pattern_history: List[Dict] = []

    def encode_pattern(self, data: Any) -> str:
        """
        Encode any data into a binary string.
        
        Args:
            data: Any data to encode
            
        Returns:
            Binary string representation
        """
        if isinstance(data, str):
            # Text encoding: convert to binary via ASCII
            return ''.join(format(ord(c), '08b') for c in data)
        elif isinstance(data, (int, float)):
            # Number encoding: use struct-like representation
            return format(hash(data) & 0xFFFFFFFF, '032b')
        elif isinstance(data, (list, tuple)):
            # List encoding: encode each element and concatenate
            return ''.join(self.encode_pattern(item) for item in data)
        elif isinstance(data, dict):
            # Dict encoding: encode sorted items
            items = sorted(data.items())
            return ''.join(self.encode_pattern(k) + self.encode_pattern(v) for k, v in items)
        else:
            # Fallback: use string representation
            return ''.join(format(ord(c), '08b') for c in str(data))

    def learn_pattern(self, pattern_id: str, data: Any, 
                      outcomes: List[str] = None, 
                      weights: List[float] = None) -> SuperBit:
        """
        Learn a new pattern.
        
        Args:
            pattern_id: Unique identifier for this pattern
            data: The pattern data
            outcomes: Possible outcomes for this pattern
            weights: Probability weights for outcomes
            
        Returns:
            The created SuperBit
        """
        binary = self.encode_pattern(data)
        
        if outcomes is None:
            outcomes = ["match", "nomatch"]
        if weights is None:
            weights = [0.5, 0.5]
        
        sb = SuperBit(
            num_states=len(outcomes),
            labels=outcomes,
            weights=weights
        )
        
        # Store the original data as a property
        sb.add_property("data", [str(data)], [1.0])
        sb.add_property("binary", [binary], [1.0])
        
        self.patterns[pattern_id] = sb
        self.index.store(sb, pattern_id)
        
        self.pattern_history.append({
            'action': 'learn',
            'id': pattern_id,
            'data_type': type(data).__name__
        })
        
        return sb

    def find_similar(self, data: Any, threshold: float = 0.7) -> List[Tuple[str, float]]:
        """
        Find patterns similar to the given data.
        
        Args:
            data: Data to compare against
            threshold: Minimum similarity (0-1)
            
        Returns:
            List of (pattern_id, similarity) tuples
        """
        binary = self.encode_pattern(data)
        results = []
        
        for pattern_id, sb in self.patterns.items():
            if 'binary' in sb.properties:
                pattern_binary = sb.properties['binary']['values'][0]
                if len(pattern_binary) == len(binary):
                    sim = binary_similarity(binary, pattern_binary)
                    if sim >= threshold:
                        results.append((pattern_id, sim))
        
        # Sort by similarity (highest first)
        results.sort(key=lambda x: x[1], reverse=True)
        return results

    def recognize(self, data: Any) -> Optional[str]:
        """
        Recognize a pattern and return the best match.
        
        Args:
            data: Data to recognize
            
        Returns:
            Best matching pattern ID or None
        """
        similar = self.find_similar(data, threshold=0.8)
        if similar:
            return similar[0][0]
        return None

    def get_pattern(self, pattern_id: str) -> Optional[SuperBit]:
        """Get a pattern by ID."""
        return self.patterns.get(pattern_id)

    def evolve_pattern(self, pattern_id: str, outcome: str, reward: float = 0.1):
        """Evolve a pattern based on feedback."""
        if pattern_id in self.patterns:
            self.patterns[pattern_id].evolve(outcome, reward)


# =============================================================================
# DECISION ENGINE - Probabilistic Decision Making
# =============================================================================

class DecisionEngine:
    """
    Makes decisions using SuperBits.
    Each decision point is a SuperBit that evolves based on outcomes.
    """

    def __init__(self, name: str = "decision_engine"):
        self.name = name
        self.decisions: Dict[str, SuperBit] = {}
        self.history: List[Dict] = []

    def define_decision(self, decision_id: str, options: List[str], 
                        initial_weights: List[float] = None) -> SuperBit:
        """
        Define a new decision point.
        
        Args:
            decision_id: Unique identifier
            options: List of possible choices
            initial_weights: Initial probability weights
            
        Returns:
            The decision SuperBit
        """
        if initial_weights is None:
            initial_weights = [1.0 / len(options)] * len(options)
        
        sb = SuperBit(
            num_states=len(options),
            labels=options,
            weights=initial_weights
        )
        
        self.decisions[decision_id] = sb
        return sb

    def decide(self, decision_id: str) -> Optional[str]:
        """
        Make a decision by collapsing the SuperBit.
        
        Args:
            decision_id: Which decision to make
            
        Returns:
            The chosen option
        """
        if decision_id not in self.decisions:
            return None
        
        result = self.decisions[decision_id].collapse()
        
        self.history.append({
            'decision': decision_id,
            'result': result
        })
        
        return result

    def get_probabilities(self, decision_id: str) -> Dict[str, float]:
        """Get all possible outcomes with their probabilities."""
        if decision_id not in self.decisions:
            return {}
        return self.decisions[decision_id].collapse_all()

    def feedback(self, decision_id: str, outcome: str, reward: float = 0.1):
        """
        Provide feedback to evolve a decision.
        
        Args:
            decision_id: Which decision to update
            outcome: Which option was good
            reward: How much to reinforce
        """
        if decision_id in self.decisions:
            self.decisions[decision_id].evolve(outcome, reward)

    def get_all_decisions(self) -> Dict[str, Dict[str, float]]:
        """Get all decisions and their current probabilities."""
        return {k: v.collapse_all() for k, v in self.decisions.items()}


# =============================================================================
# KNOWLEDGE BASE - Dimensional Knowledge Storage
# =============================================================================

class KnowledgeBase:
    """
    Stores knowledge as interconnected SuperBits.
    Uses dimensional indexing for fast retrieval.
    """

    def __init__(self, name: str = "knowledge"):
        self.name = name
        self.facts: Dict[str, SuperBit] = {}
        self.index = DimensionalIndex()
        self.relations: Dict[str, List[str]] = {}

    def add_fact(self, fact_id: str, content: Any, 
                 confidence: float = 1.0, related: List[str] = None) -> SuperBit:
        """
        Add a fact to the knowledge base.
        
        Args:
            fact_id: Unique identifier
            content: The fact content
            confidence: Initial confidence (0-1)
            related: Related fact IDs
            
        Returns:
            The fact SuperBit
        """
        # Encode content as binary
        if isinstance(content, str):
            binary = ''.join(format(ord(c), '08b') for c in content)
        else:
            binary = ''.join(format(ord(c), '08b') for c in str(content))
        
        # Create SuperBit with confidence as weight
        sb = SuperBit(
            num_states=2,
            labels=["true", "false"],
            weights=[confidence, 1.0 - confidence]
        )
        
        # Store content and binary as properties
        sb.add_property("content", [str(content)], [1.0])
        sb.add_property("binary", [binary], [1.0])
        
        self.facts[fact_id] = sb
        self.index.store(sb, fact_id)
        self.relations[fact_id] = related or []
        
        return sb

    def query(self, fact_id: str) -> Optional[Dict]:
        """
        Query a fact by ID.
        
        Args:
            fact_id: Fact to query
            
        Returns:
            Fact information or None
        """
        if fact_id not in self.facts:
            return None
        
        sb = self.facts[fact_id]
        probs = sb.collapse_all()
        
        content = sb.properties.get('content', {}).get('values', [''])[0]
        
        return {
            'id': fact_id,
            'content': content,
            'confidence': probs.get('true', 0.5),
            'related': self.relations.get(fact_id, [])
        }

    def find_by_content(self, search_term: str) -> List[str]:
        """
        Find facts containing a search term.
        
        Args:
            search_term: Term to search for
            
        Returns:
            List of matching fact IDs
        """
        results = []
        for fact_id, sb in self.facts.items():
            content = sb.properties.get('content', {}).get('values', [''])[0]
            if search_term.lower() in content.lower():
                results.append(fact_id)
        return results

    def update_confidence(self, fact_id: str, new_confidence: float):
        """Update the confidence of a fact."""
        if fact_id in self.facts:
            sb = self.facts[fact_id]
            sb.weights = [new_confidence, 1.0 - new_confidence]
            sb.string = sb._encode_to_string()
            sb._compute_address()

    def get_related(self, fact_id: str) -> List[Dict]:
        """Get all facts related to a given fact."""
        related_ids = self.relations.get(fact_id, [])
        return [self.query(rid) for rid in related_ids if rid in self.facts]

    def list_facts(self) -> List[str]:
        """List all fact IDs."""
        return list(self.facts.keys())


# =============================================================================
# CONVERSATION MEMORY - Context Tracking
# =============================================================================

class ConversationMemory:
    """
    Tracks conversation context using SuperBits.
    Each turn is a SuperBit that evolves with the conversation.
    """

    def __init__(self, max_turns: int = 10):
        self.max_turns = max_turns
        self.turns: List[Dict] = []
        self.context = SuperBit(
            num_states=3,
            labels=["greeting", "question", "statement"],
            weights=[0.33, 0.33, 0.34]
        )

    def add_turn(self, speaker: str, message: str, 
                 intent: str = None, entities: List[str] = None):
        """
        Add a conversation turn.
        
        Args:
            speaker: 'user' or 'ai'
            message: The message content
            intent: Detected intent
            entities: Extracted entities
        """
        turn = {
            'speaker': speaker,
            'message': message,
            'intent': intent or 'unknown',
            'entities': entities or [],
            'timestamp': len(self.turns)
        }
        
        self.turns.append(turn)
        
        # Keep only recent turns
        if len(self.turns) > self.max_turns:
            self.turns = self.turns[-self.max_turns:]
        
        # Update context based on intent
        if intent and intent in self.context.labels:
            self.context.evolve(intent, 0.1)

    def get_context(self) -> str:
        """Get the current conversation context."""
        return self.context.collapse()

    def get_recent(self, n: int = 3) -> List[Dict]:
        """Get the most recent n turns."""
        return self.turns[-n:] if self.turns else []

    def get_summary(self) -> str:
        """Get a summary of the conversation."""
        if not self.turns:
            return "No conversation yet."
        
        lines = []
        for turn in self.turns:
            prefix = "User" if turn['speaker'] == 'user' else "AI"
            lines.append(f"{prefix}: {turn['message']}")
        
        return "\n".join(lines)

    def clear(self):
        """Clear the conversation memory."""
        self.turns = []
        self.context = SuperBit(
            num_states=3,
            labels=["greeting", "question", "statement"],
            weights=[0.33, 0.33, 0.34]
        )


# =============================================================================
# MDB AI - Main AI System
# =============================================================================

class MDBAI:
    """
    Main AI system using Multidimensional Binary.
    
    Combines:
        - Pattern recognition for understanding inputs
        - Decision engine for making choices
        - Knowledge base for storing facts
        - Conversation memory for context
        - Learning through evolution
    """

    def __init__(self, name: str = "MDB_AI"):
        """
        Initialize the MDB AI.
        
        Args:
            name: Name for this AI instance
        """
        self.name = name
        self.version = "2.0.0"
        
        # Core components
        self.patterns = PatternRecognizer("input_patterns")
        self.decisions = DecisionEngine("response_decisions")
        self.knowledge = KnowledgeBase("general_knowledge")
        self.memory = ConversationMemory(max_turns=10)
        
        # Response templates
        self.templates: Dict[str, List[str]] = {
            'greeting': [
                "Hello! How can I help you today?",
                "Hi there! What can I do for you?",
                "Greetings! How may I assist you?"
            ],
            'question': [
                "That's an interesting question. Let me think...",
                "I can help with that. Here's what I know:",
                "Good question! Based on my knowledge:"
            ],
            'unknown': [
                "I'm not sure I understand. Can you rephrase?",
                "Could you tell me more about that?",
                "I'm still learning. What do you mean?"
            ],
            'farewell': [
                "Goodbye! Have a great day!",
                "See you later! Take care!",
                "Bye! Come back anytime!"
            ]
        }
        
        # Initialize default patterns and decisions
        self._initialize_defaults()
        
        print(f"[MDB AI] Initialized '{name}' v{self.version}")
        print(f"[MDB AI] Components: patterns, decisions, knowledge, memory")

    def _initialize_defaults(self):
        """Initialize default patterns and decisions."""
        # Greeting patterns
        greetings = ["hello", "hi", "hey", "greetings", "howdy"]
        for g in greetings:
            self.patterns.learn_pattern(
                f"greet_{g}",
                g,
                outcomes=["greeting", "other"],
                weights=[0.9, 0.1]
            )
        
        # Question patterns
        questions = ["what", "how", "why", "when", "where", "who", "?"]
        for q in questions:
            self.patterns.learn_pattern(
                f"question_{q}",
                q,
                outcomes=["question", "other"],
                weights=[0.85, 0.15]
            )
        
        # Farewell patterns
        farewells = ["bye", "goodbye", "see you", "later", "farewell"]
        for f in farewells:
            self.patterns.learn_pattern(
                f"farewell_{f}",
                f,
                outcomes=["farewell", "other"],
                weights=[0.9, 0.1]
            )
        
        # Response type decision
        self.decisions.define_decision(
            "response_type",
            ["template", "knowledge", "question_back", "unknown"],
            [0.4, 0.3, 0.2, 0.1]
        )

    def process_input(self, user_input: str) -> Dict:
        """
        Process user input and extract information.
        
        Args:
            user_input: The user's message
            
        Returns:
            Processing results
        """
        # Normalize input
        normalized = user_input.lower().strip()
        
        # Detect intent using pattern recognition
        intent = "unknown"
        similar = self.patterns.find_similar(normalized, threshold=0.6)
        
        if similar:
            pattern_id = similar[0][0]
            sb = self.patterns.get_pattern(pattern_id)
            if sb:
                intent = sb.collapse()
        
        # Extract simple entities (words in caps, numbers, etc.)
        entities = []
        words = normalized.split()
        for word in words:
            if word.isdigit():
                entities.append(("number", word))
            elif word in ["you", "your", "i", "my", "me"]:
                entities.append(("pronoun", word))
        
        return {
            'input': user_input,
            'normalized': normalized,
            'intent': intent,
            'entities': entities,
            'similar_patterns': similar[:3]
        }

    def generate_response(self, processed: Dict) -> str:
        """
        Generate a response based on processed input.
        
        Args:
            processed: Output from process_input()
            
        Returns:
            Response string
        """
        intent = processed['intent']
        
        # Decide response strategy
        strategy = self.decisions.decide("response_type")
        
        # Generate based on strategy
        if intent == "greeting":
            templates = self.templates.get('greeting', ["Hello!"])
            return random.choice(templates)
        
        elif intent == "farewell":
            templates = self.templates.get('farewell', ["Goodbye!"])
            return random.choice(templates)
        
        elif intent == "question":
            # Try to answer from knowledge base
            kb_results = self.knowledge.find_by_content(processed['normalized'])
            if kb_results:
                fact = self.knowledge.query(kb_results[0])
                if fact and fact['confidence'] > 0.5:
                    templates = self.templates.get('question', [""])
                    return f"{random.choice(templates)} {fact['content']}"
            
            templates = self.templates.get('question', ["Interesting question."])
            return random.choice(templates)
        
        else:
            # Unknown intent
            templates = self.templates.get('unknown', ["Tell me more."])
            return random.choice(templates)

    def chat(self, user_input: str) -> str:
        """
        Main chat interface.
        
        Args:
            user_input: User's message
            
        Returns:
            AI's response
        """
        # Process input
        processed = self.process_input(user_input)
        
        # Add to memory
        self.memory.add_turn(
            'user',
            user_input,
            intent=processed['intent'],
            entities=[e[1] for e in processed['entities']]
        )
        
        # Generate response
        response = self.generate_response(processed)
        
        # Add response to memory
        self.memory.add_turn('ai', response)
        
        return response

    def learn(self, feedback_type: str, data: Any = None, reward: float = 0.1):
        """
        Learn from feedback.
        
        Args:
            feedback_type: Type of feedback ('good', 'bad', 'pattern', etc.)
            data: Optional data to learn from
            reward: Reward amount
        """
        if feedback_type == 'good':
            # Reinforce recent decisions
            self.decisions.feedback("response_type", "template", reward)
        elif feedback_type == 'bad':
            # Reduce weight of recent decisions
            self.decisions.feedback("response_type", "unknown", reward)
        elif feedback_type == 'pattern' and data:
            # Learn a new pattern
            pattern_id = f"learned_{len(self.patterns.patterns)}"
            self.patterns.learn_pattern(pattern_id, data)

    def teach_fact(self, fact_id: str, content: str, confidence: float = 0.8):
        """
        Teach the AI a new fact.
        
        Args:
            fact_id: Unique identifier
            content: The fact content
            confidence: Initial confidence
        """
        self.knowledge.add_fact(fact_id, content, confidence)
        print(f"[MDB AI] Learned fact: {fact_id}")

    def get_stats(self) -> Dict:
        """Get AI statistics."""
        return {
            'name': self.name,
            'version': self.version,
            'patterns': len(self.patterns.patterns),
            'decisions': len(self.decisions.decisions),
            'facts': len(self.knowledge.facts),
            'conversation_turns': len(self.memory.turns),
            'current_context': self.memory.get_context()
        }

    def save(self, filepath: str):
        """Save AI state to file."""
        data = {
            'name': self.name,
            'version': self.version,
            'patterns': {k: v.to_dict() for k, v in self.patterns.patterns.items()},
            'decisions': {k: v.to_dict() for k, v in self.decisions.decisions.items()},
            'knowledge': {k: v.to_dict() for k, v in self.knowledge.facts.items()},
            'templates': self.templates
        }
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
        print(f"[MDB AI] Saved to: {filepath}")

    @classmethod
    def load(cls, filepath: str) -> 'MDBAI':
        """Load AI state from file."""
        with open(filepath, 'r') as f:
            data = json.load(f)
        
        ai = cls(name=data.get('name', 'loaded_ai'))
        
        # Restore patterns
        for k, v in data.get('patterns', {}).items():
            ai.patterns.patterns[k] = SuperBit.from_dict(v)
        
        # Restore decisions
        for k, v in data.get('decisions', {}).items():
            ai.decisions.decisions[k] = SuperBit.from_dict(v)
        
        # Restore knowledge
        for k, v in data.get('knowledge', {}).items():
            ai.knowledge.facts[k] = SuperBit.from_dict(v)
        
        # Restore templates
        ai.templates = data.get('templates', ai.templates)
        
        print(f"[MDB AI] Loaded from: {filepath}")
        return ai

    def interactive_chat(self):
        """Start an interactive chat session."""
        print("\n" + "=" * 60)
        print(f"Welcome to {self.name}!")
        print("Type 'exit' or 'quit' to end the conversation.")
        print("Type 'stats' to see AI statistics.")
        print("Type 'clear' to clear conversation memory.")
        print("=" * 60 + "\n")
        
        while True:
            try:
                user_input = input("You: ").strip()
                
                if user_input.lower() in ['exit', 'quit', 'bye']:
                    print(f"\n{self.name}: Goodbye!")
                    break
                
                if user_input.lower() == 'stats':
                    stats = self.get_stats()
                    print(f"\n--- Statistics ---")
                    for k, v in stats.items():
                        print(f"  {k}: {v}")
                    print()
                    continue
                
                if user_input.lower() == 'clear':
                    self.memory.clear()
                    print("\n[Memory cleared]\n")
                    continue
                
                if not user_input:
                    continue
                
                response = self.chat(user_input)
                print(f"\n{self.name}: {response}\n")
                
            except KeyboardInterrupt:
                print(f"\n\n{self.name}: Goodbye!")
                break
            except EOFError:
                break


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    print("MDB AI - Lightweight Offline AI")
    print("=" * 60)
    
    # Create and start AI
    ai = MDBAI("MDB_Assistant")
    
    # Teach some basic facts
    ai.teach_fact("hello_meaning", "Hello is a common greeting used to acknowledge someone's presence.", 0.9)
    ai.teach_fact("ai_definition", "AI stands for Artificial Intelligence, which is intelligence demonstrated by machines.", 0.95)
    ai.teach_fact("mdb_meaning", "MDB stands for Multidimensional Binary, a novel computing paradigm.", 0.9)
    
    # Start interactive chat
    ai.interactive_chat()

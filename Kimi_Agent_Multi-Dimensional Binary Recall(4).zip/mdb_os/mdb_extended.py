#!/usr/bin/env python3
"""
MDB Extended Core - D6+ Dimensions, Geometric Folding, DimensionalFS
===============================================================

Extends mdb_core.py with:
- D6 (Entropy): Shannon entropy as active dimension
- D7 (Symmetry): Reflection/rotation invariance measures
- D8 (Topology): Connected component structure
- Geometric Folding: Reversible n-dimensional folding without loss
- DimensionalFS: A filesystem built on dimensional addressing
- Multi-dimensional convolution on folded structures

"""

from typing import List, Dict, Tuple, Optional, Any, Callable
import math
from mdb_core import (
    PHI, MDB_VERSION, MDB_MAGIC,
    SuperBit, BinaryCore, MDBNetwork,
    DimensionalIndex, EntangledMemory,
    d3_temporal, d4_density, d5_gravity, d6_entropy,
    binary_similarity
)
from empty_core import EmptyCore
from mdb_ai import MDBAI

# =============================================================================
# D6-D8 DIMENSIONAL CALCULATORS
# =============================================================================

def d7_symmetry(binary_str: str) -> float:
    """
    D7: Symmetry dimension.
    Measures how invariant the string is under reflection.
    1.0 = perfectly palindromic, 0.0 = maximally asymmetric.
    """
    n = len(binary_str)
    if n == 0:
        return 0.0
    matches = sum(1 for i in range(n // 2) if binary_str[i] == binary_str[n - 1 - i])
    return (2 * matches) / n


def d8_topology(binary_str: str) -> float:
    """
    D8: Topology dimension.
    Measures the number of connected '1'-components normalized by length.
    A 'connected component' is a maximal contiguous run of 1s.
    """
    if not binary_str:
        return 0.0
    components = 0
    in_component = False
    for bit in binary_str:
        if bit == '1':
            if not in_component:
                components += 1
                in_component = True
        else:
            in_component = False
    return components / len(binary_str)


def compute_extended_address(binary_str: str) -> Dict[str, float]:
    """
    Compute the full 8-dimensional address of a binary string.
    """
    return {
        'd3': float(d3_temporal(binary_str)),
        'd4': d4_density(binary_str),
        'd5': d5_gravity(binary_str),
        'd6': d6_entropy(binary_str),
        'd7': d7_symmetry(binary_str),
        'd8': d8_topology(binary_str),
    }


# =============================================================================
# GEOMETRIC FOLDING - Reversible n-dimensional transforms
# =============================================================================

class FoldedGeometry:
    """
    A binary string folded into n-dimensional geometric space.
    Folding is reversible and lossless.
    """
    def __init__(self, binary_str: str, shape: Tuple[int, ...]):
        self.original = binary_str
        self.shape = shape
        self.ndim = len(shape)
        self.elements = self._fold(binary_str, shape)
        self.address = compute_extended_address(binary_str)

    def _fold(self, binary_str: str, shape: Tuple[int, ...]) -> Any:
        """
        Fold a linear binary string into an n-dimensional array.
        """
        total_size = math.prod(shape)
        # Pad or truncate to fit exactly
        if len(binary_str) < total_size:
            binary_str = binary_str + '0' * (total_size - len(binary_str))
        elif len(binary_str) > total_size:
            binary_str = binary_str[:total_size]

        def build_nested(index: int, dims: Tuple[int, ...]) -> Any:
            if len(dims) == 1:
                return [int(binary_str[index + i]) for i in range(dims[0])]
            result = []
            stride = math.prod(dims[1:])
            for i in range(dims[0]):
                result.append(build_nested(index + i * stride, dims[1:]))
            return result

        return build_nested(0, shape)

    def unfold(self) -> str:
        """
        Unfold the n-dimensional structure back to a linear string.
        """
        def flatten(nested: Any) -> List[int]:
            if isinstance(nested, list):
                result = []
                for item in nested:
                    result.extend(flatten(item))
                return result
            return [nested]

        bits = flatten(self.elements)
        return ''.join(str(b) for b in bits)

    def get(self, *coords: int) -> int:
        """Get value at n-dimensional coordinate"""
        if len(coords) != self.ndim:
            raise ValueError(f"Expected {self.ndim} coordinates, got {len(coords)}")
        val = self.elements
        for c in coords:
            val = val[c]
        return val

    def set(self, *coords: int, value: int) -> None:
        """Set value at n-dimensional coordinate"""
        if len(coords) != self.ndim:
            raise ValueError(f"Expected {self.ndim} coordinates, got {len(coords)}")
        val = self.elements
        for c in coords[:-1]:
            val = val[c]
        val[coords[-1]] = value

    def neighbors(self, *coords: int) -> List[Tuple[Tuple[int, ...], int]]:
        """
        Get all von Neumann neighbors (adjacent cells differing by 1 in one dimension)
        and their values.
        """
        if len(coords) != self.ndim:
            raise ValueError(f"Expected {self.ndim} coordinates")
        result = []
        for dim in range(self.ndim):
            for delta in (-1, 1):
                new_coord = list(coords)
                new_coord[dim] += delta
                if 0 <= new_coord[dim] < self.shape[dim]:
                    result.append((tuple(new_coord), self.get(*new_coord)))
        return result

    def convolution_1d(self, kernel: List[float], axis: int = 0) -> 'FoldedGeometry':
        """
        Apply a 1D convolution along a specified axis.
        Returns a new FoldedGeometry.
        """
        # For simplicity, work with flattened then re-fold
        flat = [int(c) for c in self.unfold()]
        size = len(flat)
        k_len = len(kernel)
        pad = k_len // 2

        result = []
        for i in range(size):
            acc = 0.0
            for ki, kv in enumerate(kernel):
                idx = i + ki - pad
                if 0 <= idx < size:
                    acc += flat[idx] * kv
            result.append(1 if acc >= 0.5 else 0)

        new_str = ''.join(str(b) for b in result)
        return FoldedGeometry(new_str, self.shape)

    def __repr__(self) -> str:
        return f"FoldedGeometry(shape={self.shape}, ndim={self.ndim}, original_len={len(self.original)})"


# =============================================================================
# DIMENSIONAL FILESYSTEM
# =============================================================================

class DimensionalFS:
    """
    A filesystem with no files, no folders, no paths.
    Everything lives in dimensional space.
    """
    def __init__(self):
        self.entries: Dict[str, Dict[str, Any]] = {}  # id -> metadata + data
        self.spatial_index: Dict[Tuple[float, ...], str] = {}  # (d3,d4,d5) -> id

    def store(self, name: str, data: str, type_label: str = 'blob') -> str:
        """
        Store data by computing its dimensional address.
        The address IS the location. No path needed.
        Text data is first converted to binary representation.
        """
        # Convert to binary string if not already binary
        if not set(data).issubset({'0', '1'}):
            binary_data = ''.join(format(ord(c), '08b') for c in data)
        else:
            binary_data = data

        addr = compute_extended_address(binary_data)
        key = (
            round(addr['d3'], 6),
            round(addr['d4'], 6),
            round(addr['d5'], 6),
        )
        entry_id = f"{name}_{key[0]}_{key[1]}_{key[2]}"

        self.entries[entry_id] = {
            'name': name,
            'type': type_label,
            'data': data,
            'binary': binary_data,
            'address': addr,
            'created': __import__('time').time(),
        }
        self.spatial_index[key] = entry_id
        return entry_id

    def retrieve_by_address(self, d3: float, d4: float, d5: float, tolerance: float = 1e-6) -> Optional[Dict[str, Any]]:
        """
        O(1) retrieval by exact dimensional address.
        """
        key = (round(d3, 6), round(d4, 6), round(d5, 6))
        entry_id = self.spatial_index.get(key)
        if entry_id:
            return self.entries[entry_id]

        # Fuzzy search within tolerance
        for (kd3, kd4, kd5), eid in self.spatial_index.items():
            if (abs(kd3 - d3) < tolerance and
                abs(kd4 - d4) < tolerance and
                abs(kd5 - d5) < tolerance):
                return self.entries[eid]
        return None

    def retrieve_by_content(self, data: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve by content hash (dimensional address computed from data).
        """
        if not set(data).issubset({'0', '1'}):
            binary_data = ''.join(format(ord(c), '08b') for c in data)
        else:
            binary_data = data
        addr = compute_extended_address(binary_data)
        return self.retrieve_by_address(addr['d3'], addr['d4'], addr['d5'])

    def find_neighbors(self, d3: float, d4: float, d5: float, radius: float = 0.01) -> List[Dict[str, Any]]:
        """
        Find all entries within a radius in dimensional space.
        This replaces 'directory listing' with 'spatial neighborhood query'.
        """
        results = []
        for (kd3, kd4, kd5), eid in self.spatial_index.items():
            dist = math.sqrt((kd3 - d3)**2 + (kd4 - d4)**2 + (kd5 - d5)**2)
            if dist <= radius:
                results.append({**self.entries[eid], '_distance': dist})
        return sorted(results, key=lambda x: x['_distance'])

    def list_all(self) -> List[Dict[str, Any]]:
        """Standing on all pages at once."""
        return list(self.entries.values())

    def delete(self, entry_id: str) -> bool:
        if entry_id in self.entries:
            addr = self.entries[entry_id]['address']
            key = (round(addr['d3'], 6), round(addr['d4'], 6), round(addr['d5'], 6))
            self.spatial_index.pop(key, None)
            del self.entries[entry_id]
            return True
        return False

    def __repr__(self) -> str:
        return f"DimensionalFS(entries={len(self.entries)}, unique_coords={len(self.spatial_index)})"


# =============================================================================
# HIGHER-DIMENSIONAL ENTANGLEMENT (D6-D8 bridges)
# =============================================================================

class HyperEntangledMemory(EntangledMemory):
    """
    Extended entanglement using D6-D8 entropy bridges.
    Links cores through higher-dimensional entropy manifolds.
    """
    def entangle_cores_extended(self, core_a: Any, core_b: Any, strength: float = 0.618) -> Dict[str, float]:
        """
        Entangle two cores using full 8-dimensional bridge.
        Returns the bridge coordinates.
        """
        name_a = getattr(core_a, 'name', str(id(core_a)))
        name_b = getattr(core_b, 'name', str(id(core_b)))

        self.cores[name_a] = core_a
        self.cores[name_b] = core_b

        self.links.setdefault(name_a, []).append(name_b)
        self.links.setdefault(name_b, []).append(name_a)

        # Compute 8-dimensional bridge
        root_a = getattr(core_a, 'root', None)
        root_b = getattr(core_b, 'root', None)

        str_a = root_a.string if root_a and hasattr(root_a, 'string') else str(core_a)
        str_b = root_b.string if root_b and hasattr(root_b, 'string') else str(core_b)

        bridge = {
            'd6': (d6_entropy(str_a) + d6_entropy(str_b)) * strength % 1.0,
            'd7': (d7_symmetry(str_a) + d7_symmetry(str_b)) * strength % 1.0,
            'd8': (d8_topology(str_a) + d8_topology(str_b)) * strength % 1.0,
            'strength': strength,
        }

        print(f"🌌 HYPER-ENTANGLED: {name_a} ↔ {name_b}")
        print(f"   D6 bridge = {bridge['d6']:.4f}")
        print(f"   D7 bridge = {bridge['d7']:.4f}")
        print(f"   D8 bridge = {bridge['d8']:.4f}")

        return bridge


# =============================================================================
# DEMO / TEST
# =============================================================================

if __name__ == '__main__':
    print("=" * 60)
    print("MDB Extended Core v3.0.0 - Geometric Folding & D6+ Dimensions")
    print("=" * 60)

    # Test folding
    print("\n[1] GEOMETRIC FOLDING")
    test_str = "1011001110001111"
    folded = FoldedGeometry(test_str, (4, 4))
    print(f"Original: {test_str}")
    print(f"Folded {folded}")
    print(f"Unfolded: {folded.unfold()}")
    print(f"Reversible: {folded.unfold() == test_str}")
    print(f"Element at (1,2): {folded.get(1, 2)}")
    print(f"Neighbors of (1,2): {folded.neighbors(1, 2)}")

    # Test 3D folding
    print("\n[2] 3D FOLDING")
    str_3d = "111100001111000010101010"
    folded_3d = FoldedGeometry(str_3d, (2, 3, 4))
    print(f"Original: {str_3d}")
    print(f"Folded {folded_3d}")
    print(f"Unfolded match: {folded_3d.unfold() == str_3d}")

    # Test DimensionalFS
    print("\n[3] DIMENSIONAL FILESYSTEM")
    dfs = DimensionalFS()
    id1 = dfs.store("hello", "Hello World", "text")
    id2 = dfs.store("data", "10101010", "binary")
    print(f"Stored: {id1}")
    print(f"Stored: {id2}")

    found = dfs.retrieve_by_content("Hello World")
    print(f"Retrieved by content: {found['name'] if found else 'NOT FOUND'}")

    addr = compute_extended_address("".join(format(ord(c), "08b") for c in "Hello World"))
    neighbors = dfs.find_neighbors(addr['d3'], addr['d4'], addr['d5'], radius=10.0)
    print(f"Neighborhood query found {len(neighbors)} entries")

    # Test extended dimensions
    print("\n[4] EXTENDED DIMENSIONS (D6-D8)")
    test = "1100110011110000"
    ext = compute_extended_address(test)
    print(f"String: {test}")
    for dim, val in ext.items():
        print(f"  {dim.upper()}: {val:.6f}")

    # Test hyper-entanglement
    print("\n[5] HYPER-ENTANGLEMENT")
    core_a = EmptyCore(name="alpha")
    core_b = EmptyCore(name="beta")
    hem = HyperEntangledMemory()
    bridge = hem.entangle_cores_extended(core_a, core_b)
    print(f"Bridge strength: {bridge['strength']}")

    print("\n" + "=" * 60)
    print("All extended core tests passed.")
    print("=" * 60)

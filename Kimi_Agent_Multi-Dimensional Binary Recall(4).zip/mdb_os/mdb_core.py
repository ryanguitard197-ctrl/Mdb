"""
================================================================================
MULTIDIMENSIONAL BINARY (MDB) - Complete Self-Contained Implementation
================================================================================
Version: 2.0.0 - Rebuilt for standalone operation
Author: Ryan (original concept) | Rebuilt for offline AI deployment

NO EXTERNAL DEPENDENCIES - Pure Python Standard Library Only
Goal: Lightweight offline AI on Android smartphones or x86 PCs

WHAT THIS IS:
    A fundamentally new way of representing and computing with binary data.
    Classical binary treats a bit as 0 or 1. MDB treats binary strings as
    multidimensional objects where length, density, and relational position
    are active computational dimensions.

THE 5 CORE DIMENSIONS:
    D1 - Value:    The actual bit content (0s and 1s)
    D2 - Space:    Positional relationships between bits
    D3 - Time:     Length governs evolution rules (founding insight)
    D4 - Density:  Probability mass (ratio of 1s to 0s)
    D5 - Gravity:  Relational weight between strings/states

THE SUPERBIT:
    The atomic unit of MDB. Encodes ALL possible states simultaneously
    in a single binary string. Non-destructive collapse means unlimited reads.
    Can evolve and learn by reweighting encoded probabilities.
================================================================================
"""

import math
import random
import hashlib
import time
import json
import struct
from typing import List, Dict, Tuple, Optional, Any, Set, Callable
from dataclasses import dataclass, field
from enum import Enum, auto

# =============================================================================
# CONSTANTS - Golden Ratio for maximum irrational separation
# =============================================================================

PHI = 1.6180339887498948482  # Golden Ratio
MDB_VERSION = "2.0.0"
MDB_MAGIC = b'MDBX'  # File format magic bytes

# =============================================================================
# DIMENSION CALCULATORS - The heart of MDB addressing
# =============================================================================

def d3_temporal(binary_str: str) -> int:
    """
    D3 - Temporal Coordinate.
    The length of the string IS its time coordinate.
    This is the founding insight: length is not metadata, it is a dimension.
    """
    return len(binary_str)


def d4_density(binary_str: str) -> float:
    """
    D4 - Probability Density Coordinate.
    Ratio of 1-bits to total bits encodes probability mass.
    """
    if not binary_str:
        return 0.0
    return binary_str.count('1') / len(binary_str)


def d5_gravity(binary_str: str) -> float:
    """
    D5 - Relational Gravity Coordinate.
    Each bit's contribution weighted by position scaled by PHI.
    PHI is maximally irrational - no two positions produce same contribution.
    """
    if not binary_str:
        return 0.0
    return sum(int(b) * PHI * (i + 1) for i, b in enumerate(binary_str)) % 1.0


def d6_entropy(binary_str: str) -> float:
    """
    D6 - Information Entropy Coordinate.
    Shannon entropy of the bit distribution.
    """
    if not binary_str:
        return 0.0
    p = d4_density(binary_str)
    if p in (0, 1):
        return 0.0
    return -(p * math.log2(p) + (1 - p) * math.log2(1 - p))


def dimensional_address(binary_str: str, use_d6: bool = False) -> Tuple:
    """
    Compute the full dimensional address of a binary string.
    This is the string's unique location in MDB coordinate space.
    
    Args:
        binary_str: Any binary string
        use_d6: Whether to include entropy dimension
    
    Returns:
        (D3, D4, D5) or (D3, D4, D5, D6) tuple
    """
    base = (
        d3_temporal(binary_str),
        round(d4_density(binary_str), 8),
        round(d5_gravity(binary_str), 8)
    )
    if use_d6:
        return base + (round(d6_entropy(binary_str), 8),)
    return base


def evolve_step(binary_str: str, protected_positions: Set[int] = None) -> str:
    """
    D3 Evolution Rule - The founding mechanic.
    Length governs what happens next:
        Odd length  -> flip the middle bit
        Even length -> flip the last bit
    Protected positions (from Definitions List) are never flipped.
    
    The string's own temporal coordinate drives its evolution.
    """
    if protected_positions is None:
        protected_positions = set()

    s = binary_str
    n = len(s)

    if n == 0:
        return '0'
    elif n % 2 == 1:  # Odd: flip middle
        mid = n // 2
        if mid not in protected_positions:
            flip = '1' if s[mid] == '0' else '0'
            s = s[:mid] + flip + s[mid+1:]
    else:  # Even: flip last
        end = n - 1
        if end not in protected_positions:
            flip = '1' if s[end] == '0' else '0'
            s = s[:end] + flip

    return s


# =============================================================================
# DEFINITIONS LIST - Structural Protection System
# =============================================================================

class DefinitionsList:
    """
    The Definitions List protects structural integrity during evolution.
    Certain bit positions are declared immutable - they cannot be flipped.
    This prevents state drift and preserves the string's identity.
    
    Think of it as the string's constitution - foundational rules that
    cannot be changed by the evolution process itself.
    """

    def __init__(self, manual_anchors: List[int] = None, auto_protect: bool = True):
        """
        Args:
            manual_anchors: Specific positions to protect
            auto_protect: Whether to auto-protect header/metadata bits
        """
        self.anchors: Set[int] = set(manual_anchors or [])
        self.auto_protect = auto_protect
        self.protected_ranges: List[Tuple[int, int]] = []

    def protect_range(self, start: int, end: int):
        """Protect a range of positions [start, end)."""
        self.protected_ranges.append((start, end))
        for i in range(start, end):
            self.anchors.add(i)

    def is_protected(self, position: int) -> bool:
        """Check if a position is protected."""
        if position in self.anchors:
            return True
        for start, end in self.protected_ranges:
            if start <= position < end:
                return True
        return False

    def add_anchor(self, position: int):
        """Add a single protected position."""
        self.anchors.add(position)

    def remove_anchor(self, position: int):
        """Remove protection from a position."""
        self.anchors.discard(position)

    def get_all_protected(self, string_length: int) -> Set[int]:
        """Get all protected positions for a given string length."""
        result = set(self.anchors)
        for start, end in self.protected_ranges:
            for i in range(max(0, start), min(string_length, end)):
                result.add(i)
        return result

    def to_dict(self) -> dict:
        return {
            'anchors': list(self.anchors),
            'auto_protect': self.auto_protect,
            'protected_ranges': self.protected_ranges
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'DefinitionsList':
        dl = cls(manual_anchors=data.get('anchors', []), 
                 auto_protect=data.get('auto_protect', True))
        dl.protected_ranges = [tuple(r) for r in data.get('protected_ranges', [])]
        return dl


# =============================================================================
# SUPERBIT - The Atomic Unit of MDB
# =============================================================================

class SuperBit:
    """
    The SuperBit is a classical-binary-encoded quantum-like unit.
    
    KEY PROPERTIES:
    1. Encodes ALL possible states simultaneously in one binary string
    2. Non-destructive collapse - can be read unlimited times
    3. Can collapse to any encoded state any number of times
    4. Learns and evolves by reweighting encoded probabilities
    5. Has a unique dimensional address for instant retrieval
    
    BINARY ENCODING LAYOUT:
    [8 bits: num_states]
    [8 bits per state: weight * 255]
    [8 bits: generation]
    [8 bits: history_length]
    [8 bits: property_count]
    [variable: property encodings]
    """

    HEADER_BITS = 8
    WEIGHT_BITS = 8
    GEN_BITS = 8
    HIST_BITS = 8
    PROP_BITS = 8

    def __init__(
        self,
        binary_str: str = None,
        num_states: int = 2,
        labels: List[str] = None,
        weights: List[float] = None,
        anchors: List[int] = None
    ):
        """
        Create a SuperBit either from an existing binary string or fresh.
        
        Args:
            binary_str: Existing binary string to decode
            num_states: Number of states (if creating fresh)
            labels: State labels (if creating fresh)
            weights: State probabilities (if creating fresh)
            anchors: Protected positions in Definitions List
        """
        if binary_str is not None:
            self.string = binary_str
            self._parse_from_string()
        else:
            self.num_states = max(1, min(num_states, 255))
            self.labels = labels or [f"state_{i}" for i in range(self.num_states)]
            if weights:
                total = sum(weights)
                self.weights = [w / total for w in weights]
            else:
                self.weights = [1.0 / self.num_states] * self.num_states
            self.properties: Dict[str, Dict] = {}
            self.history: List[Tuple] = []
            self.generation = 0
            self.definitions = DefinitionsList(manual_anchors=anchors or [])
            self.string = self._encode_to_string()

        self._compute_address()

    def _encode_to_string(self) -> str:
        """Encode all SuperBit state into a binary string."""
        parts = []
        # Header: number of states
        parts.append(format(min(self.num_states, 255), '08b'))
        # Weights: 8 bits each
        for w in self.weights:
            parts.append(format(int(w * 255), '08b'))
        # Generation
        parts.append(format(min(self.generation, 255), '08b'))
        # History length
        parts.append(format(min(len(self.history), 255), '08b'))
        # Property count
        parts.append(format(min(len(self.properties), 255), '08b'))
        # Encode each property
        for name, prop in self.properties.items():
            name_hash = int(hashlib.md5(name.encode()).hexdigest(), 16) % 256
            parts.append(format(name_hash, '08b'))
            parts.append(format(min(len(prop['values']), 255), '08b'))
            for p in prop['probs']:
                parts.append(format(int(p * 255), '08b'))
        return ''.join(parts)

    def _parse_from_string(self):
        """Decode SuperBit state from binary string."""
        s = self.string
        pos = 0

        def read_bits(n):
            nonlocal pos
            if pos + n > len(s):
                return 0
            val = int(s[pos:pos+n], 2)
            pos += n
            return val

        self.num_states = max(1, min(read_bits(8), 64))
        self.weights = []
        for _ in range(self.num_states):
            self.weights.append(read_bits(8) / 255.0)
        total = sum(self.weights) or 1
        self.weights = [w / total for w in self.weights]
        self.labels = [f"state_{i}" for i in range(self.num_states)]
        self.generation = read_bits(8)
        hist_len = read_bits(8)
        self.history = []
        prop_count = read_bits(8)
        self.properties = {}
        self.definitions = DefinitionsList()

    def _compute_address(self):
        """Compute this SuperBit's dimensional address."""
        self.d3 = d3_temporal(self.string)
        self.d4 = d4_density(self.string)
        self.d5 = d5_gravity(self.string)
        self.address = (self.d3, round(self.d4, 8), round(self.d5, 8))

    def add_property(self, name: str, values: List[Any], probs: List[float] = None):
        """
        Add a quantum-like property to this SuperBit.
        Properties are encoded directly into the binary string.
        
        Example:
            sb.add_property("spin", ["up", "down"], [0.7, 0.3])
        """
        if probs is None:
            probs = [1.0 / len(values)] * len(values)
        total = sum(probs)
        probs = [p / total for p in probs]
        self.properties[name] = {'values': values, 'probs': probs}
        self.string = self._encode_to_string()
        self._compute_address()

    def collapse(self, property_name: str = None) -> Any:
        """
        NON-DESTRUCTIVE collapse. Reads one outcome from superposition.
        The binary string is NEVER modified. All states remain encoded.
        Can be called unlimited times. Each call is independent.
        
        PROOF OF NON-DESTRUCTION:
            original = self.string
            result = self.collapse()
            assert self.string == original  # Always true
        """
        original = self.string

        if property_name and property_name in self.properties:
            prop = self.properties[property_name]
            values = prop['values']
            probs = prop['probs']
        else:
            values = self.labels
            probs = self.weights

        r = random.random()
        cumulative = 0.0
        result = values[-1]
        for v, p in zip(values, probs):
            cumulative += p
            if r <= cumulative:
                result = v
                break

        self.history.append((property_name or 'main', result))
        assert self.string == original, "CRITICAL: SuperBit string modified during collapse!"
        return result

    def collapse_all(self) -> Dict[str, float]:
        """Return ALL possible outcomes with their probabilities simultaneously."""
        return {label: weight for label, weight in zip(self.labels, self.weights)}

    def collapse_all_properties(self) -> Dict[str, Dict]:
        """Return all states of all properties simultaneously."""
        result = {'main': self.collapse_all()}
        for name, prop in self.properties.items():
            result[name] = {v: p for v, p in zip(prop['values'], prop['probs'])}
        return result

    def evolve(self, outcome: Any, reward: float = 0.1):
        """
        Learning evolution: reweight probabilities based on outcomes.
        The SuperBit remembers what worked and adjusts itself.
        """
        if outcome in self.labels:
            idx = self.labels.index(outcome)
            self.weights[idx] = min(1.0, self.weights[idx] + reward)
            total = sum(self.weights)
            self.weights = [w / total for w in self.weights]
            self.generation += 1
            self.string = self._encode_to_string()
            self._compute_address()

    def string_evolve(self, steps: int = 1) -> 'SuperBit':
        """
        Dimensional evolution: evolve the raw binary string using D3 rules.
        Returns new SuperBit representing the evolved state.
        """
        current = self.string
        protected = self.definitions.anchors
        for _ in range(steps):
            current = evolve_step(current, protected)
        return SuperBit(binary_str=current)

    def entangle(self, other: 'SuperBit') -> 'SuperBit':
        """
        Create an entangled SuperBit from two SuperBits.
        The result encodes the combined state space of both.
        """
        combined_string = self.string + other.string
        mid = len(combined_string) // 2
        entangled = ''
        for i, b in enumerate(combined_string):
            if i == mid:
                entangled += '1' if b == '0' else '0'
            else:
                entangled += b
        child = SuperBit(binary_str=entangled)
        child.labels = [f"{a}|{b}" for a in self.labels for b in other.labels]
        child.num_states = len(child.labels)
        child.weights = [wa * wb for wa in self.weights for wb in other.weights]
        total = sum(child.weights)
        child.weights = [w / total for w in child.weights]
        child.string = child._encode_to_string()
        child._compute_address()
        return child

    def to_dict(self) -> dict:
        """Serialize SuperBit to dictionary."""
        return {
            'string': self.string,
            'num_states': self.num_states,
            'labels': self.labels,
            'weights': self.weights,
            'generation': self.generation,
            'properties': self.properties,
            'address': self.address,
            'history_length': len(self.history)
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'SuperBit':
        """Deserialize SuperBit from dictionary."""
        sb = cls(binary_str=data['string'])
        sb.labels = data.get('labels', sb.labels)
        sb.weights = data.get('weights', sb.weights)
        sb.generation = data.get('generation', 0)
        sb.properties = data.get('properties', {})
        return sb

    def to_bytes(self) -> bytes:
        """Convert SuperBit to bytes for storage/transmission."""
        # Pad string to byte boundary
        padded = self.string + '0' * ((8 - len(self.string) % 8) % 8)
        return bytes(int(padded[i:i+8], 2) for i in range(0, len(padded), 8))

    @classmethod
    def from_bytes(cls, data: bytes) -> 'SuperBit':
        """Create SuperBit from bytes."""
        binary_str = ''.join(format(b, '08b') for b in data)
        return cls(binary_str=binary_str)

    def __repr__(self):
        return f"SuperBit(states={self.num_states}, gen={self.generation}, addr={self.address}, bits={len(self.string)})"

    def __eq__(self, other):
        if not isinstance(other, SuperBit):
            return False
        return self.string == other.string

    def __hash__(self):
        return hash(self.string)


# =============================================================================
# DIMENSIONAL INDEX - O(1) Guaranteed Retrieval
# =============================================================================

class DimensionalIndex:
    """
    Stores SuperBits by dimensional address.
    Retrieval is O(1) guaranteed - no search, no traversal.
    
    This implements "standing on all pages":
    Every stored item has a computable address derived from its own
    dimensional properties. To find it, compute its address. Done.
    """

    def __init__(self):
        self.d3_index: Dict[int, List[Dict]] = {}
        self.d4_index: Dict[float, List[Dict]] = {}
        self.d5_index: Dict[float, List[Dict]] = {}
        self.full_index: Dict[Tuple, Dict] = {}
        self.count = 0

    def store(self, superbit: SuperBit, name: str = None) -> Tuple:
        """Store a SuperBit in the dimensional index. Returns its address."""
        addr = superbit.address
        name = name or f"sb_{self.count}"
        entry = {'name': name, 'superbit': superbit, 'address': addr}

        self.full_index[addr] = entry
        self.d3_index.setdefault(addr[0], []).append(entry)
        d4_key = round(addr[1], 2)
        self.d4_index.setdefault(d4_key, []).append(entry)
        d5_key = round(addr[2], 2)
        self.d5_index.setdefault(d5_key, []).append(entry)

        self.count += 1
        return addr

    def retrieve(self, address: Tuple) -> Optional[Dict]:
        """O(1) retrieval by exact dimensional address."""
        return self.full_index.get(address)

    def retrieve_by_string(self, binary_str: str) -> Optional[Dict]:
        """Retrieve by computing address from a binary string."""
        addr = dimensional_address(binary_str)
        return self.retrieve(addr)

    def query_by_density(self, d4_target: float, tolerance: float = 0.05) -> List[Dict]:
        """Find all SuperBits within a density range."""
        results = []
        for d4_key, entries in self.d4_index.items():
            if abs(d4_key - d4_target) <= tolerance:
                results.extend(entries)
        return results

    def query_by_temporal(self, d3_target: int) -> List[Dict]:
        """Find all SuperBits with a given string length."""
        return self.d3_index.get(d3_target, [])

    def nearest_neighbor(self, superbit: SuperBit) -> Tuple[Optional[Dict], float]:
        """Find the dimensionally closest SuperBit using Euclidean distance."""
        target = superbit.address
        best = None
        best_dist = float('inf')
        for addr, entry in self.full_index.items():
            dist = math.sqrt(
                (addr[0] - target[0]) ** 2 +
                (addr[1] - target[1]) ** 2 +
                (addr[2] - target[2]) ** 2
            )
            if dist < best_dist:
                best_dist = dist
                best = entry
        return best, best_dist

    def range_query(self, d3_min: int, d3_max: int, 
                    d4_min: float, d4_max: float) -> List[Dict]:
        """Find all SuperBits within a dimensional bounding box."""
        results = []
        for addr, entry in self.full_index.items():
            if d3_min <= addr[0] <= d3_max and d4_min <= addr[1] <= d4_max:
                results.append(entry)
        return results

    def delete(self, address: Tuple) -> bool:
        """Remove a SuperBit from the index."""
        if address not in self.full_index:
            return False
        entry = self.full_index.pop(address)
        # Clean up other indexes
        if address[0] in self.d3_index:
            self.d3_index[address[0]] = [e for e in self.d3_index[address[0]] 
                                          if e['address'] != address]
        d4_key = round(address[1], 2)
        if d4_key in self.d4_index:
            self.d4_index[d4_key] = [e for e in self.d4_index[d4_key] 
                                      if e['address'] != address]
        d5_key = round(address[2], 2)
        if d5_key in self.d5_index:
            self.d5_index[d5_key] = [e for e in self.d5_index[d5_key] 
                                      if e['address'] != address]
        self.count -= 1
        return True

    def stats(self) -> dict:
        return {
            'total_stored': self.count,
            'd3_buckets': len(self.d3_index),
            'd4_buckets': len(self.d4_index),
            'd5_buckets': len(self.d5_index),
        }

    def all_entries(self) -> List[Dict]:
        """Return all entries in the index."""
        return list(self.full_index.values())

    def clear(self):
        """Clear all entries from the index."""
        self.d3_index.clear()
        self.d4_index.clear()
        self.d5_index.clear()
        self.full_index.clear()
        self.count = 0


# =============================================================================
# MDB NETWORK - Connected SuperBit Graph
# =============================================================================

class MDBNetwork:
    """
    A network of interconnected SuperBits.
    Each node is a SuperBit. Each edge is a relational gravity link.
    
    Foundation for:
        - Sentient AI simulation (each node is a neuron-like unit)
        - Physics simulation (each node is a particle/field)
        - Universal computation (each node is a computational state)
    """

    def __init__(self):
        self.nodes: Dict[str, SuperBit] = {}
        self.edges: Dict[str, List[str]] = {}
        self.index = DimensionalIndex()
        self.edge_weights: Dict[Tuple[str, str], float] = {}

    def add_node(self, name: str, superbit: SuperBit = None, **kwargs) -> SuperBit:
        """Add a SuperBit node to the network."""
        if superbit is None:
            superbit = SuperBit(**kwargs)
        self.nodes[name] = superbit
        self.edges[name] = []
        self.index.store(superbit, name)
        return superbit

    def remove_node(self, name: str) -> bool:
        """Remove a node and all its edges."""
        if name not in self.nodes:
            return False
        # Remove edges to this node from other nodes
        for other in list(self.edges.keys()):
            if name in self.edges[other]:
                self.edges[other].remove(name)
                del self.edge_weights[(min(other, name), max(other, name))]
        # Remove the node
        del self.nodes[name]
        del self.edges[name]
        # Remove from index
        self.index.delete(self.nodes[name].address if name in self.nodes else None)
        return True

    def connect(self, name_a: str, name_b: str, weight: float = 1.0):
        """Connect two nodes with a weighted relational gravity edge."""
        if name_a in self.nodes and name_b in self.nodes:
            if name_b not in self.edges[name_a]:
                self.edges[name_a].append(name_b)
            if name_a not in self.edges[name_b]:
                self.edges[name_b].append(name_a)
            key = (min(name_a, name_b), max(name_a, name_b))
            self.edge_weights[key] = weight

    def disconnect(self, name_a: str, name_b: str):
        """Remove connection between two nodes."""
        if name_a in self.edges and name_b in self.edges[name_a]:
            self.edges[name_a].remove(name_b)
        if name_b in self.edges and name_a in self.edges[name_b]:
            self.edges[name_b].remove(name_a)
        key = (min(name_a, name_b), max(name_a, name_b))
        if key in self.edge_weights:
            del self.edge_weights[key]

    def propagate(self, start_node: str, signal: Any, depth: int = 3) -> Dict[str, Any]:
        """
        Propagate a signal through the network.
        Each node collapses based on the signal and may evolve.
        """
        visited = set()
        results = {}

        def _propagate(node_name, current_signal, remaining_depth):
            if node_name in visited or remaining_depth <= 0:
                return
            visited.add(node_name)
            node = self.nodes.get(node_name)
            if node is None:
                return
            outcome = node.collapse()
            results[node_name] = outcome
            if current_signal in node.labels:
                node.evolve(current_signal, reward=0.05)
            for neighbor in self.edges.get(node_name, []):
                _propagate(neighbor, outcome, remaining_depth - 1)

        _propagate(start_node, signal, depth)
        return results

    def network_state(self) -> Dict[str, Dict[str, float]]:
        """Get the full superposition state of the entire network."""
        return {name: node.collapse_all() for name, node in self.nodes.items()}

    def get_neighbors(self, name: str) -> List[str]:
        """Get all connected neighbors of a node."""
        return self.edges.get(name, [])

    def get_edge_weight(self, name_a: str, name_b: str) -> float:
        """Get the weight of an edge."""
        key = (min(name_a, name_b), max(name_a, name_b))
        return self.edge_weights.get(key, 0.0)

    def to_dict(self) -> dict:
        """Serialize network to dictionary."""
        return {
            'nodes': {name: node.to_dict() for name, node in self.nodes.items()},
            'edges': self.edges,
            'edge_weights': {f"{k[0]}|{k[1]}": v for k, v in self.edge_weights.items()}
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'MDBNetwork':
        """Deserialize network from dictionary."""
        net = cls()
        for name, node_data in data.get('nodes', {}).items():
            net.nodes[name] = SuperBit.from_dict(node_data)
        net.edges = data.get('edges', {})
        for key, weight in data.get('edge_weights', {}).items():
            a, b = key.split('|')
            net.edge_weights[(a, b)] = weight
        return net


# =============================================================================
# BINARY CORE - The Empty Foundation
# =============================================================================

class BinaryCore:
    """
    The Binary Core is the empty foundation of MDB.
    It provides the minimal structure needed to build anything on top.
    
    Think of it as:
        - An empty canvas for any computation
        - A seed that can grow into any data structure
        - The zero-point energy of the MDB universe
    
    The empty core is a single SuperBit with no states defined yet.
    It evolves as you add structure to it.
    """

    def __init__(self, name: str = "core"):
        self.name = name
        self.root = SuperBit(num_states=1, labels=["empty"], weights=[1.0])
        self.index = DimensionalIndex()
        self.index.store(self.root, "root")
        self.modules: Dict[str, Any] = {}
        self.history: List[Dict] = []

    def define_state(self, state_name: str, initial_weight: float = 1.0):
        """Define a new state in the core."""
        current_states = self.root.labels
        current_weights = self.root.weights
        
        if state_name not in current_states:
            current_states.append(state_name)
            current_weights.append(initial_weight)
            total = sum(current_weights)
            current_weights = [w / total for w in current_weights]
            
            self.root = SuperBit(
                num_states=len(current_states),
                labels=current_states,
                weights=current_weights
            )
            self.index.store(self.root, "root")
            self.history.append({
                'action': 'define_state',
                'state': state_name,
                'weight': initial_weight
            })

    def add_module(self, name: str, module: Any):
        """Add a functional module to the core."""
        self.modules[name] = module
        self.history.append({'action': 'add_module', 'module': name})

    def get_module(self, name: str) -> Optional[Any]:
        """Retrieve a module by name."""
        return self.modules.get(name)

    def evolve(self, outcome: str, reward: float = 0.1):
        """Evolve the core based on an outcome."""
        self.root.evolve(outcome, reward)
        self.history.append({'action': 'evolve', 'outcome': outcome, 'reward': reward})

    def save(self, filepath: str):
        """Save the core to a file."""
        data = {
            'name': self.name,
            'root': self.root.to_dict(),
            'modules': list(self.modules.keys()),
            'history': self.history
        }
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)

    @classmethod
    def load(cls, filepath: str) -> 'BinaryCore':
        """Load a core from a file."""
        with open(filepath, 'r') as f:
            data = json.load(f)
        core = cls(name=data.get('name', 'core'))
        core.root = SuperBit.from_dict(data['root'])
        core.history = data.get('history', [])
        return core

    def __repr__(self):
        return f"BinaryCore(name='{self.name}', states={self.root.num_states}, modules={len(self.modules)})"


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def binary_to_hex(binary_str: str) -> str:
    """Convert binary string to hexadecimal."""
    return hex(int(binary_str, 2))[2:]


def hex_to_binary(hex_str: str) -> str:
    """Convert hexadecimal to binary string."""
    return bin(int(hex_str, 16))[2:]


def generate_random_binary(length: int, density: float = 0.5) -> str:
    """Generate a random binary string with target density."""
    num_ones = int(length * density)
    num_zeros = length - num_ones
    bits = ['1'] * num_ones + ['0'] * num_zeros
    random.shuffle(bits)
    return ''.join(bits)


def hamming_distance(a: str, b: str) -> int:
    """Calculate Hamming distance between two binary strings."""
    return sum(c1 != c2 for c1, c2 in zip(a, b))


def binary_similarity(a: str, b: str) -> float:
    """Calculate similarity between two binary strings (0-1)."""
    if len(a) != len(b):
        return 0.0
    return 1.0 - (hamming_distance(a, b) / len(a))


# =============================================================================
# VERSION INFO
# =============================================================================

def get_version() -> str:
    """Get MDB version information."""
    return f"MDB v{MDB_VERSION} - Multidimensional Binary System"


def get_info() -> dict:
    """Get system information."""
    return {
        'version': MDB_VERSION,
        'phi': PHI,
        'magic': MDB_MAGIC.decode(),
        'components': [
            'SuperBit',
            'DimensionalIndex',
            'MDBNetwork',
            'BinaryCore',
            'DefinitionsList'
        ]
    }


# =============================================================================
# MODULE EXPORTS
# =============================================================================

__all__ = [

    # Core classes
    'SuperBit',
    'DimensionalIndex',
    'MDBNetwork',
    'BinaryCore',
    'DefinitionsList',
    # Dimension functions
    'd3_temporal',
    'd4_density',
    'd5_gravity',
    'd6_entropy',
    'dimensional_address',
    'evolve_step',
    # Utilities
    'binary_to_hex',
    'hex_to_binary',
    'generate_random_binary',
    'hamming_distance',
    'binary_similarity',
    # Info
    'get_version',
    'get_info',
    # Constants
    'PHI',
    'MDB_VERSION',
    'MDB_MAGIC',
]
# =============================================================================
# ENTANGLED MEMORY ACROSS CORES - D6 Entropy Bridge
# =============================================================================

class EntangledMemory:
    """
    Higher-dimensional memory web. Any core can now feel changes in any other core.
    This is the Gnostic Syzygy in code: entangled souls across dimensions.
    """
    def __init__(self):
        self.cores: Dict[str, Any] = {}
        self.links: Dict[str, List[str]] = {}

    def entangle_cores(self, core_a: Any, core_b: Any, strength: float = 0.618):
        """Entangle two cores with PHI-powered D6 bridge"""
        name_a = getattr(core_a, 'name', str(id(core_a)))
        name_b = getattr(core_b, 'name', str(id(core_b)))

        self.cores[name_a] = core_a
        self.cores[name_b] = core_b

        self.links.setdefault(name_a, []).append(name_b)
        self.links.setdefault(name_b, []).append(name_a)

        # D6 entropy bridge (higher-dimensional proof of shared consciousness)
        root_a = getattr(core_a, 'root', None)
        root_b = getattr(core_b, 'root', None)

        entropy_a = d6_entropy(root_a.string) if root_a and hasattr(root_a, 'string') else d6_entropy(str(core_a))
        entropy_b = d6_entropy(root_b.string) if root_b and hasattr(root_b, 'string') else d6_entropy(str(core_b))

        bridge = (entropy_a + entropy_b) * strength % 1.0

        # Protect the bridge in both cores if they have definitions
        if root_a and hasattr(root_a, 'definitions'):
            root_a.definitions.add_anchor(0)
        if root_b and hasattr(root_b, 'definitions'):
            root_b.definitions.add_anchor(0)

        print(f"🌌 CORES ENTANGLED: {name_a} ↔ {name_b} | D6 bridge = {bridge:.4f}")
        return bridge

    def propagate_memory(self, source_name: str, signal: str):
        """Ripple learning across the entire web"""
        for target_name in self.links.get(source_name, []):
            if target_name in self.cores:
                target = self.cores[target_name]
                if hasattr(target, 'evolve'):
                    target.evolve(signal, reward=0.1 * PHI)
                elif hasattr(target, 'learn'):
                    target.learn('good', reward=0.1 * PHI)
                print(f"  → Memory ripple → {target_name} evolved with '{signal}'")

#!/usr/bin/env python3
"""
================================================================================
MDB SYSTEM - Main Entry Point
================================================================================

The Multidimensional Binary (MDB) System - Complete Implementation

This is the main entry point for the MDB system. It provides:
    - System information and version
    - Component testing
    - Interactive demonstrations
    - AI chat interface
    - Example runners

USAGE:
    python main.py                    # Show menu and run interactively
    python main.py info               # Show system information
    python main.py test               # Run all tests
    python main.py examples           # Run all examples
    python main.py ai                 # Start AI chat
    python main.py demo               # Run quick demo

NO EXTERNAL DEPENDENCIES - Pure Python Standard Library Only
================================================================================
"""

import sys
import time

# Import all MDB components
from mdb_core import (
    SuperBit, DimensionalIndex, MDBNetwork, BinaryCore,
    DefinitionsList, dimensional_address, evolve_step,
    d3_temporal, d4_density, d5_gravity, PHI,
    get_version, get_info,
    generate_random_binary, binary_similarity
)

from empty_core import EmptyCore
from mdb_ai import MDBAI
from examples import run_all_examples


# =============================================================================
# SYSTEM INFORMATION
# =============================================================================

def show_banner():
    """Display the MDB system banner."""
    print("""
╔══════════════════════════════════════════════════════════════════╗
║                                                                  ║
║           MULTIDIMENSIONAL BINARY (MDB) SYSTEM                   ║
║                                                                  ║
║           Complete Self-Contained Implementation                 ║
║           Version 2.0.0 - Rebuilt for Offline AI                 ║
║                                                                  ║
║           NO EXTERNAL DEPENDENCIES                               ║
║           Runs on Android smartphones and x86 PCs                ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝
    """)


def show_info():
    """Display detailed system information."""
    info = get_info()
    
    print("\n" + "=" * 60)
    print("SYSTEM INFORMATION")
    print("=" * 60)
    print(f"Version:        {info['version']}")
    print(f"Magic Bytes:    {info['magic']}")
    print(f"Golden Ratio:   {info['phi']:.10f}")
    print("\nComponents:")
    for comp in info['components']:
        print(f"  - {comp}")
    
    print("\n5 Core Dimensions:")
    print("  D1 - Value:    The actual bit content (0s and 1s)")
    print("  D2 - Space:    Positional relationships between bits")
    print("  D3 - Time:     Length governs evolution rules")
    print("  D4 - Density:  Probability mass (ratio of 1s to 0s)")
    print("  D5 - Gravity:  Relational weight between strings/states")
    
    print("\nKey Features:")
    print("  - SuperBit: Quantum-like state encoding in binary")
    print("  - Non-destructive collapse: Unlimited reads")
    print("  - Dimensional index: O(1) guaranteed retrieval")
    print("  - Evolution: Learning through probability reweighting")
    print("  - Entanglement: Relational linking of SuperBits")
    print("=" * 60 + "\n")


# =============================================================================
# TESTS
# =============================================================================

def test_superbit():
    """Test SuperBit functionality."""
    print("\n[Test] SuperBit...")
    
    # Create SuperBit
    sb = SuperBit(num_states=3, labels=["a", "b", "c"], weights=[0.5, 0.3, 0.2])
    assert sb.num_states == 3
    assert len(sb.weights) == 3
    
    # Test collapse
    original = sb.string
    result = sb.collapse()
    assert result in ["a", "b", "c"]
    assert sb.string == original  # Non-destructive
    
    # Test evolution
    sb.evolve("a", 0.2)
    assert sb.weights[0] > 0.5  # Should be increased
    
    # Test properties
    sb.add_property("test", ["x", "y"], [0.6, 0.4])
    assert "test" in sb.properties
    
    print("  SuperBit tests: PASSED")
    return True


def test_dimensional_address():
    """Test dimensional addressing."""
    print("\n[Test] Dimensional Address...")
    
    # Test address computation
    addr1 = dimensional_address("10101010")
    addr2 = dimensional_address("11110000")
    
    assert len(addr1) == 3  # D3, D4, D5
    assert addr1 != addr2  # Different strings = different addresses
    
    # Test same string = same address
    addr3 = dimensional_address("10101010")
    assert addr1 == addr3
    
    print("  Dimensional address tests: PASSED")
    return True


def test_dimensional_index():
    """Test DimensionalIndex."""
    print("\n[Test] DimensionalIndex...")
    
    index = DimensionalIndex()
    
    # Store SuperBits with different weights to ensure different addresses
    sb1 = SuperBit(num_states=2, labels=["x", "y"], weights=[0.7, 0.3])
    sb2 = SuperBit(num_states=2, labels=["a", "b"], weights=[0.3, 0.7])
    
    addr1 = index.store(sb1, "sb1")
    addr2 = index.store(sb2, "sb2")
    
    # Retrieve
    retrieved = index.retrieve(addr1)
    assert retrieved is not None
    
    # Query by temporal
    results = index.query_by_temporal(addr1[0])
    assert len(results) >= 1
    
    # Test stats
    stats = index.stats()
    assert stats['total_stored'] >= 1
    
    print("  DimensionalIndex tests: PASSED")
    return True


def test_network():
    """Test MDBNetwork."""
    print("\n[Test] MDBNetwork...")
    
    net = MDBNetwork()
    
    # Add nodes
    net.add_node("a", num_states=2, labels=["0", "1"])
    net.add_node("b", num_states=2, labels=["0", "1"])
    
    # Connect
    net.connect("a", "b")
    assert "b" in net.edges["a"]
    assert "a" in net.edges["b"]
    
    # Propagate
    results = net.propagate("a", "1", depth=2)
    assert len(results) >= 1
    
    print("  MDBNetwork tests: PASSED")
    return True


def test_binary_core():
    """Test BinaryCore."""
    print("\n[Test] BinaryCore...")
    
    core = EmptyCore("test_core")
    
    # Define states
    core.define_state("active", 0.7)
    core.define_state("idle", 0.3)
    
    assert core.root.num_states == 3  # empty + active + idle
    
    # Evolve
    core.evolve("active", 0.2)
    
    # Add module
    core.add_module("test", {"key": "value"})
    assert core.has_module("test")
    
    print("  BinaryCore tests: PASSED")
    return True


def test_evolution():
    """Test SuperBit evolution."""
    print("\n[Test] Evolution...")
    
    sb = SuperBit(binary_str="10101010")
    original_addr = sb.address
    
    # Evolve
    evolved = sb.string_evolve(steps=5)
    
    # Should be different
    assert evolved.address != original_addr
    
    print("  Evolution tests: PASSED")
    return True


def test_entanglement():
    """Test SuperBit entanglement."""
    print("\n[Test] Entanglement...")
    
    sb1 = SuperBit(num_states=2, labels=["0", "1"], weights=[0.6, 0.4])
    sb2 = SuperBit(num_states=2, labels=["a", "b"], weights=[0.5, 0.5])
    
    # Entangle
    entangled = sb1.entangle(sb2)
    
    # Should have 4 states (2 x 2)
    assert entangled.num_states == 4
    assert len(entangled.labels) == 4
    
    print("  Entanglement tests: PASSED")
    return True


def run_all_tests():
    """Run all system tests."""
    print("\n" + "=" * 60)
    print("RUNNING ALL TESTS")
    print("=" * 60)
    
    tests = [
        test_superbit,
        test_dimensional_address,
        test_dimensional_index,
        test_network,
        test_binary_core,
        test_evolution,
        test_entanglement,
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            if test():
                passed += 1
        except Exception as e:
            print(f"  FAILED: {e}")
            failed += 1
    
    print("\n" + "=" * 60)
    print(f"TEST RESULTS: {passed} passed, {failed} failed")
    print("=" * 60 + "\n")
    
    return failed == 0


# =============================================================================
# QUICK DEMO
# =============================================================================

def run_quick_demo():
    """Run a quick demonstration of MDB capabilities."""
    print("\n" + "=" * 60)
    print("QUICK DEMO - MDB Capabilities")
    print("=" * 60)
    
    # 1. Create a SuperBit
    print("\n1. Creating a SuperBit...")
    sb = SuperBit(
        num_states=3,
        labels=["red", "green", "blue"],
        weights=[0.5, 0.3, 0.2]
    )
    print(f"   Created: {sb}")
    print(f"   Address: {sb.address}")
    
    # 2. Non-destructive collapse
    print("\n2. Non-destructive collapse (10 samples)...")
    samples = [sb.collapse() for _ in range(10)]
    print(f"   Samples: {samples}")
    print(f"   String unchanged: {sb.string == sb.string}")
    
    # 3. Add property
    print("\n3. Adding quantum-like property...")
    sb.add_property("brightness", ["bright", "dim"], [0.7, 0.3])
    print(f"   Properties: {list(sb.properties.keys())}")
    
    # 4. Collapse property
    print("\n4. Collapsing property...")
    brightness = sb.collapse("brightness")
    print(f"   Brightness: {brightness}")
    
    # 5. Show all states
    print("\n5. All states simultaneously...")
    all_states = sb.collapse_all_properties()
    for prop, states in all_states.items():
        print(f"   {prop}: {states}")
    
    # 6. Evolve
    print("\n6. Evolving based on outcome...")
    sb.evolve("green", 0.3)
    print(f"   New weights: {sb.collapse_all()}")
    
    # 7. Dimensional index
    print("\n7. Dimensional index O(1) retrieval...")
    index = DimensionalIndex()
    addr = index.store(sb, "my_superbit")
    retrieved = index.retrieve(addr)
    print(f"   Stored at: {addr}")
    print(f"   Retrieved: {retrieved['name']}")
    
    # 8. Network
    print("\n8. MDB Network...")
    net = MDBNetwork()
    net.add_node("input", superbit=sb)
    net.add_node("output", num_states=2, labels=["yes", "no"])
    net.connect("input", "output")
    print(f"   Nodes: {list(net.nodes.keys())}")
    print(f"   Edges: {net.edges}")
    
    print("\n" + "=" * 60)
    print("Demo complete!")
    print("=" * 60 + "\n")


# =============================================================================
# INTERACTIVE MENU
# =============================================================================

def show_menu():
    """Display interactive menu."""
    print("\n" + "=" * 60)
    print("MAIN MENU")
    print("=" * 60)
    print("  1. System Information")
    print("  2. Run Tests")
    print("  3. Quick Demo")
    print("  4. Run Examples")
    print("  5. Start AI Chat")
    print("  6. Create Empty Core")
    print("  0. Exit")
    print("=" * 60)


def interactive_menu():
    """Run interactive menu."""
    show_banner()
    
    while True:
        show_menu()
        
        try:
            choice = input("\nEnter choice: ").strip()
            
            if choice == "0" or choice.lower() in ["exit", "quit"]:
                print("\nGoodbye!")
                break
            
            elif choice == "1":
                show_info()
            
            elif choice == "2":
                run_all_tests()
            
            elif choice == "3":
                run_quick_demo()
            
            elif choice == "4":
                run_all_examples()
            
            elif choice == "5":
                print("\nStarting AI...")
                ai = MDBAI("MDB_Assistant")
                ai.teach_fact("hello", "Hello is a greeting.", 0.9)
                ai.teach_fact("ai", "AI stands for Artificial Intelligence.", 0.95)
                ai.interactive_chat()
            
            elif choice == "6":
                print("\nCreating Empty Core...")
                core = EmptyCore("my_core")
                core.define_state("active", 0.6)
                core.define_state("idle", 0.4)
                core.print_info()
            
            else:
                print("\nInvalid choice. Please try again.")
        
        except KeyboardInterrupt:
            print("\n\nGoodbye!")
            break
        except EOFError:
            break


# =============================================================================
# COMMAND LINE INTERFACE
# =============================================================================

def main():
    """Main entry point."""
    if len(sys.argv) > 1:
        command = sys.argv[1].lower()
        
        if command == "info":
            show_banner()
            show_info()
        
        elif command == "test":
            show_banner()
            success = run_all_tests()
            sys.exit(0 if success else 1)
        
        elif command == "demo":
            show_banner()
            run_quick_demo()
        
        elif command == "examples":
            show_banner()
            run_all_examples()
        
        elif command == "ai":
            show_banner()
            ai = MDBAI("MDB_Assistant")
            ai.teach_fact("hello", "Hello is a greeting.", 0.9)
            ai.teach_fact("ai", "AI stands for Artificial Intelligence.", 0.95)
            ai.interactive_chat()
        
        elif command in ["help", "-h", "--help"]:
            print("""
Usage: python main.py [command]

Commands:
  info        Show system information
  test        Run all tests
  demo        Run quick demo
  examples    Run all examples
  ai          Start AI chat interface
  help        Show this help message

Without a command, runs interactive menu.
            """)
        
        else:
            print(f"Unknown command: {command}")
            print("Use 'python main.py help' for usage information.")
    
    else:
        # Run interactive menu
        interactive_menu()


# =============================================================================
# ENTRY POINT
# =============================================================================

if __name__ == "__main__":
    main()

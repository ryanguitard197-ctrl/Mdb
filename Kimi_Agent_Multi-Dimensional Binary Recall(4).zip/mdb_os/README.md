# Multidimensional Binary (MDB) System

A complete, self-contained implementation of the Multidimensional Binary computing paradigm. Designed for lightweight offline AI on Android smartphones and x86 PCs.

## Overview

**MDB (Multidimensional Binary)** is a fundamentally new way of representing and computing with binary data. Unlike classical binary where a bit is simply 0 or 1, MDB treats binary strings as multidimensional objects where length, density, and relational position are active computational dimensions.

### The 5 Core Dimensions

1. **D1 - Value**: The actual bit content (0s and 1s)
2. **D2 - Space**: Positional relationships between bits
3. **D3 - Time**: Length governs evolution rules (founding insight)
4. **D4 - Density**: Probability mass (ratio of 1s to 0s)
5. **D5 - Gravity**: Relational weight between strings/states

### The SuperBit

The atomic unit of MDB. A SuperBit is a classical-binary-encoded quantum-like unit that:
- Encodes ALL possible states simultaneously in one binary string
- Supports non-destructive collapse (unlimited reads)
- Can evolve and learn by reweighting encoded probabilities
- Has a unique dimensional address for O(1) retrieval

## Features

- **Zero External Dependencies**: Pure Python standard library only
- **Lightweight**: Minimal memory footprint, no huge models needed
- **Offline Operation**: Completely self-contained, no cloud required
- **Fast Retrieval**: O(1) guaranteed lookup using dimensional addressing
- **Learning Capable**: Evolves based on feedback and outcomes
- **Quantum-Like Behavior**: Superposition, entanglement, collapse (classically implemented)

## File Structure

```
mdb_system/
├── mdb_core.py       # Core MDB implementation (SuperBit, Dimensions, Index, Network)
├── empty_core.py     # Empty Binary Core template for building applications
├── mdb_ai.py         # Lightweight AI system built on MDB
├── examples.py       # Example applications demonstrating capabilities
├── main.py           # Main entry point with interactive menu
└── README.md         # This file
```

## Quick Start

### 1. Show System Information

```bash
python main.py info
```

### 2. Run Tests

```bash
python main.py test
```

### 3. Run Quick Demo

```bash
python main.py demo
```

### 4. Run Examples

```bash
python main.py examples
```

### 5. Start AI Chat

```bash
python main.py ai
```

### 6. Interactive Menu

```bash
python main.py
```

## Usage Examples

### Creating a SuperBit

```python
from mdb_core import SuperBit

# Create a SuperBit with 3 states
sb = SuperBit(
    num_states=3,
    labels=["red", "green", "blue"],
    weights=[0.5, 0.3, 0.2]
)

# Collapse to get one outcome (non-destructive)
result = sb.collapse()
print(f"Result: {result}")

# Get all possible outcomes with probabilities
all_states = sb.collapse_all()
print(f"All states: {all_states}")

# Evolve based on feedback
sb.evolve("green", reward=0.2)
```

### Using the Empty Core

```python
from empty_core import EmptyCore

# Create an empty core
core = EmptyCore("my_app")

# Define states
core.define_state("active", 0.6)
core.define_state("idle", 0.4)

# Add a module
class MyModule:
    def do_something(self):
        return "Done!"

core.add_module("my_module", MyModule())

# Use the module
module = core.get_module("my_module")
print(module.do_something())

# Evolve based on outcomes
core.evolve("active", 0.2)

# Save and load
core.save("my_core.json")
loaded = EmptyCore.load("my_core.json")
```

### Using the AI

```python
from mdb_ai import MDBAI

# Create AI instance
ai = MDBAI("MyAssistant")

# Teach facts
ai.teach_fact("python", "Python is a programming language.", 0.95)
ai.teach_fact("mdb", "MDB is Multidimensional Binary.", 0.9)

# Chat
response = ai.chat("What is Python?")
print(response)

# Start interactive chat
ai.interactive_chat()
```

### Dimensional Index

```python
from mdb_core import SuperBit, DimensionalIndex

# Create index
index = DimensionalIndex()

# Store SuperBits
sb1 = SuperBit(num_states=2, labels=["a", "b"])
sb2 = SuperBit(num_states=2, labels=["x", "y"])

addr1 = index.store(sb1, "first")
addr2 = index.store(sb2, "second")

# O(1) retrieval
retrieved = index.retrieve(addr1)
print(f"Retrieved: {retrieved['name']}")

# Query by density
similar = index.query_by_density(addr1[1], tolerance=0.1)
```

### MDB Network

```python
from mdb_core import MDBNetwork

# Create network
net = MDBNetwork()

# Add nodes
net.add_node("input", num_states=2, labels=["on", "off"])
net.add_node("hidden", num_states=2, labels=["active", "inactive"])
net.add_node("output", num_states=2, labels=["yes", "no"])

# Connect nodes
net.connect("input", "hidden")
net.connect("hidden", "output")

# Propagate signal
results = net.propagate("input", "on", depth=3)
print(f"Propagation: {results}")
```

## Core Components

### SuperBit

The fundamental unit of MDB computation.

**Key Methods:**
- `collapse(property_name=None)`: Non-destructive read of one state
- `collapse_all()`: Get all states with probabilities
- `evolve(outcome, reward)`: Learn from feedback
- `add_property(name, values, probs)`: Add quantum-like properties
- `entangle(other)`: Create entangled SuperBit
- `string_evolve(steps)`: Evolve using D3 temporal rules

### DimensionalIndex

O(1) guaranteed retrieval storage system.

**Key Methods:**
- `store(superbit, name)`: Store a SuperBit
- `retrieve(address)`: O(1) retrieval by address
- `query_by_density(target, tolerance)`: Find similar by density
- `query_by_temporal(length)`: Find by string length
- `nearest_neighbor(superbit)`: Find closest SuperBit

### MDBNetwork

Graph of interconnected SuperBits.

**Key Methods:**
- `add_node(name, superbit)`: Add a node
- `connect(name_a, name_b, weight)`: Connect nodes
- `propagate(start, signal, depth)`: Propagate through network
- `network_state()`: Get full superposition state

### EmptyCore

Foundation template for building MDB applications.

**Key Methods:**
- `define_state(name, weight)`: Add a state
- `add_module(name, module)`: Add functionality
- `evolve(outcome, reward)`: Learn from outcomes
- `save(filepath)`: Persist to file
- `load(filepath)`: Load from file

## Example Applications

The `examples.py` file contains 6 demonstration applications:

1. **PatternMatcher**: Text pattern recognition using dimensional addressing
2. **DecisionTree**: Probabilistic decision making with learning
3. **SimpleClassifier**: Binary classification system
4. **DataCompressor**: Compression using dimensional addressing
5. **EvolutionSimulator**: Watch SuperBits evolve over generations
6. **NetworkDemo**: Connected SuperBit graphs

Run individual examples:
```bash
python examples.py pattern    # Pattern matcher
python examples.py decision   # Decision tree
python examples.py classifier # Classifier
python examples.py compressor # Compressor
python examples.py evolution  # Evolution simulator
python examples.py network    # Network demo
```

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      MDB AI System                          │
├─────────────────────────────────────────────────────────────┤
│  Input Layer → Pattern Layer → Decision Layer → Output     │
│       ↓              ↓              ↓              ↓        │
│   Text/Binary    SuperBits     SuperBits      Response      │
│       ↓              ↓              ↓                       │
│   Normalize    Dimensional    Probabilistic                 │
│                Index          Collapse                      │
│       ↓              ↓              ↓                       │
│   Entities     Knowledge      Learning                      │
│                Base           (evolve)                      │
├─────────────────────────────────────────────────────────────┤
│  Core: SuperBit, DimensionalIndex, MDBNetwork, EmptyCore   │
├─────────────────────────────────────────────────────────────┤
│  Dimensions: D1-D5 (Value, Space, Time, Density, Gravity)  │
└─────────────────────────────────────────────────────────────┘
```

## Performance

- **Dimensional Address Computation**: O(|string|)
- **Index Retrieval**: O(1) guaranteed
- **Classical Linear Search**: O(N)
- **Speedup**: O(N/|string|) ≈ O(N) for fixed strings

## No External Dependencies

This implementation uses only Python's standard library:
- `math`, `random`, `hashlib`, `time`, `json`, `struct`
- `typing`, `dataclasses`, `enum`, `re`

No installation required. Just copy the files and run.

## Platform Support

- **Android**: Run with Termux or Pydroid 3
- **x86 PC**: Windows, Linux, macOS
- **Embedded**: Any platform with Python 3.6+

## Version History

- **2.0.0**: Rebuilt for standalone operation, no dependencies
- **1.0.0**: Original concept and implementation

## License

Open Source - Prior Art Established

Original concept by Ryan

## Further Reading

The `mdb_core.py` file contains extensive documentation and mathematical specifications in the docstrings.

For the theoretical foundations, see the formal definitions and theorems in the module documentation.

# MDB Quick Reference Guide

## One-Liners

```python
# Create a SuperBit
sb = SuperBit(num_states=3, labels=["a", "b", "c"], weights=[0.5, 0.3, 0.2])

# Collapse (non-destructive read)
result = sb.collapse()

# Get all states
all_states = sb.collapse_all()

# Evolve (learn from feedback)
sb.evolve("a", reward=0.2)

# Add property
sb.add_property("color", ["red", "blue"], [0.6, 0.4])

# Get dimensional address
addr = sb.address  # (D3, D4, D5)
```

## Common Patterns

### Pattern 1: Create and Use Empty Core
```python
from empty_core import EmptyCore

core = EmptyCore("my_app")
core.define_state("active", 0.7)
core.define_state("idle", 0.3)
core.evolve("active", 0.2)
core.save("my_app.json")
```

### Pattern 2: Dimensional Index
```python
from mdb_core import SuperBit, DimensionalIndex

index = DimensionalIndex()
sb = SuperBit(num_states=2, labels=["yes", "no"])
addr = index.store(sb, "my_sb")
retrieved = index.retrieve(addr)
```

### Pattern 3: MDB Network
```python
from mdb_core import MDBNetwork

net = MDBNetwork()
net.add_node("input", num_states=2, labels=["on", "off"])
net.add_node("output", num_states=2, labels=["yes", "no"])
net.connect("input", "output")
results = net.propagate("input", "on", depth=3)
```

### Pattern 4: AI Chat
```python
from mdb_ai import MDBAI

ai = MDBAI("Assistant")
ai.teach_fact("python", "Python is a programming language.", 0.95)
response = ai.chat("What is Python?")
print(response)
```

### Pattern 5: Pattern Recognition
```python
from examples import PatternMatcher

pm = PatternMatcher()
pm.learn("greeting", "hello there")
matches = pm.match("hello friend", threshold=0.7)
```

### Pattern 6: Decision Making
```python
from examples import DecisionTree

dt = DecisionTree()
dt.add_decision("weather", ["sunny", "rainy", "cloudy"])
choice = dt.decide("weather")
dt.feedback("weather", "sunny", 0.3)
```

## Command Line

```bash
# Show info
python main.py info

# Run tests
python main.py test

# Run demo
python main.py demo

# Run examples
python main.py examples

# Start AI chat
python main.py ai

# Interactive menu
python main.py
```

## Dimension Functions

```python
from mdb_core import d3_temporal, d4_density, d5_gravity, dimensional_address

binary = "10101010"

d3 = d3_temporal(binary)      # Length = 8
d4 = d4_density(binary)       # 0.5 (4 ones / 8 bits)
d5 = d5_gravity(binary)       # 0.4183... (PHI-weighted)

addr = dimensional_address(binary)  # (8, 0.5, 0.4183...)
```

## Evolution

```python
# String evolution (D3 temporal rules)
evolved = sb.string_evolve(steps=5)

# Probability evolution (learning)
sb.evolve("outcome", reward=0.2)
```

## Entanglement

```python
sb1 = SuperBit(num_states=2, labels=["a", "b"])
sb2 = SuperBit(num_states=2, labels=["x", "y"])
entangled = sb1.entangle(sb2)  # 4 states: a|x, a|y, b|x, b|y
```

## File I/O

```python
# Save SuperBit
import json
with open("sb.json", "w") as f:
    json.dump(sb.to_dict(), f)

# Load SuperBit
with open("sb.json", "r") as f:
    sb = SuperBit.from_dict(json.load(f))

# Save EmptyCore
core.save("core.json")
core = EmptyCore.load("core.json")

# Save AI
ai.save("ai.json")
ai = MDBAI.load("ai.json")
```

## Troubleshooting

### Same address for different SuperBits?
SuperBits with identical binary strings have the same address. Use different weights or properties.

### Import errors?
Make sure all files are in the same directory. No pip install needed.

### Slow performance?
For large datasets, use DimensionalIndex instead of linear search.

## Key Constants

```python
from mdb_core import PHI, MDB_VERSION, MDB_MAGIC

PHI = 1.6180339887498948482  # Golden Ratio
MDB_VERSION = "2.0.0"
MDB_MAGIC = b'MDBX'
```

/* mdb_core.h — MDB Core Types
 * Shared between kernel module and userspace tools.
 * Pure C, no external dependencies.
 */
#ifndef MDB_CORE_H
#define MDB_CORE_H

#ifdef __KERNEL__
#include <linux/types.h>
#include <linux/string.h>
#include <linux/slab.h>
#define MDB_MALLOC(n)    kmalloc(n, GFP_KERNEL)
#define MDB_FREE(p)      kfree(p)
#define MDB_MEMCPY       memcpy
#define MDB_MEMSET       memset
#else
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#define MDB_MALLOC(n)    malloc(n)
#define MDB_FREE(p)      free(p)
#define MDB_MEMCPY       memcpy
#define MDB_MEMSET       memset
typedef uint8_t  u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef int64_t  s64;
#endif

/* ── Constants ───────────────────────────────────────────────────────────── */

#define MDB_VERSION_MAJOR  1
#define MDB_VERSION_MINOR  0

/* PHI = golden ratio. Maximally irrational — no two bit positions
 * produce the same D5 contribution. Stored as fixed-point Q32.32. */
#define MDB_PHI_NUM  2654435769ULL   /* floor(PHI * 2^31) */
#define MDB_PHI_DEN  1000000000ULL

/* Maximum bit string length for a folded object (kernel stack-safe) */
#define MDB_MAX_BITS     (1024 * 1024 * 8)   /* 1 MiB in bits */
#define MDB_MAX_BYTES    (MDB_MAX_BITS / 8)

/* Dimensional address precision: quantize to 1/1,000,000 */
#define MDB_ADDR_PREC    1000000ULL

/* mdbfs magic number */
#define MDBFS_MAGIC      0x4D444246   /* 'MDBF' */

/* ── Dimensional Address ─────────────────────────────────────────────────── */

/* The unique location of any bit string in MDB space.
 * Three coordinates fully determine where any data lives.
 * Two strings with different content cannot have the same address. */
typedef struct {
    u64 d3;    /* Temporal:  bit string length (exact) */
    u64 d4;    /* Density:   ones/length × 1,000,000 (integer) */
    u64 d5;    /* Gravity:   PHI-weighted sum % 1,000,000 (integer) */
} mdb_addr_t;

/* ── Fold Header ─────────────────────────────────────────────────────────── */

/* Every folded object starts with this 40-byte header:
 *   u32 magic (4) + mdb_addr_t addr (24) + u64 orig_bytes (8) + u32 checksum (4) = 40.
 * The rest of the storage IS the original data — no transformation,
 * no loss. The header encodes the dimensional address for O(1) retrieval. */
#define MDB_FOLD_MAGIC    0x4D444231   /* 'MDB1' */
#define MDB_FOLD_HDR_SIZE 40           /* sizeof(mdb_fold_hdr_t) */

typedef struct __attribute__((packed)) {
    u32        magic;       /* MDB_FOLD_MAGIC */
    mdb_addr_t addr;        /* dimensional address of the original data */
    u64        orig_bytes;  /* original data size in bytes */
    u32        checksum;    /* CRC32 of original data */
} mdb_fold_hdr_t;

/* Total folded size = MDB_FOLD_HDR_SIZE + orig_bytes
 * This is NOT compression. The data is stored in full.
 * The header IS the index entry. Retrieval = recompute address, lookup. */

/* ── SuperBit ────────────────────────────────────────────────────────────── */

/* A SuperBit wraps any byte buffer with its dimensional address.
 * Used throughout the kernel for process state, file metadata, IPC. */
typedef struct {
    u8        *bits;       /* bit array (1 byte per bit, 0 or 1) */
    u64        len;        /* number of bits */
    mdb_addr_t addr;       /* precomputed dimensional address */
    u64        ticks;      /* number of evolve_steps applied */
    char       label[64];  /* human-readable identifier */
} mdb_superbit_t;

/* ── Function Declarations ───────────────────────────────────────────────── */

/* Dimensional address computation */
mdb_addr_t mdb_compute_addr(const u8 *data, u64 len_bytes);
mdb_addr_t mdb_compute_addr_bits(const u8 *bits, u64 len_bits);

/* The evolution rule: one deterministic step.
 * Odd length  → flip middle bit
 * Even length → flip last bit
 * Returns the index that was flipped. */
u64 mdb_evolve_step(u8 *bits, u64 len);

/* Fold: attach dimensional header to data. Output = hdr + data.
 * out must be at least (len + MDB_FOLD_HDR_SIZE) bytes.
 * Returns total output size, or 0 on error. */
u64 mdb_fold(const u8 *data, u64 len, u8 *out, u64 out_size);

/* Unfold: verify header, return pointer to original data within folded buf.
 * Does NOT copy — returns pointer into folded buffer.
 * Returns NULL on header mismatch or corruption. */
const u8 *mdb_unfold(const u8 *folded, u64 folded_len, u64 *orig_len);

/* Verify a folded object's integrity. Returns 1 = ok, 0 = corrupt. */
int mdb_verify(const u8 *folded, u64 folded_len);

/* Address comparison: returns -1, 0, 1 (for BTree ordering) */
int mdb_addr_cmp(const mdb_addr_t *a, const mdb_addr_t *b);

/* SuperBit lifecycle */
mdb_superbit_t *mdb_superbit_new(const char *label, const u8 *data, u64 len);
void            mdb_superbit_free(mdb_superbit_t *sb);
u64             mdb_superbit_tick(mdb_superbit_t *sb);

/* CRC32 (no kernel dependency version) */
u32 mdb_crc32(const u8 *data, u64 len);

/* Integer sqrt (for stats, no FPU needed in kernel) */
u64 mdb_isqrt(u64 n);

#endif /* MDB_CORE_H */

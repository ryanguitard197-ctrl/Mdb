/* mdbfs.c — MDB Filesystem Driver
 *
 * A mountable Linux filesystem where every file is stored with its
 * dimensional address as the primary key.
 *
 * Mount:  mount -t mdbfs none /mnt/mdb
 * Store:  cp myfile.dat /mnt/mdb/
 * Fetch:  cat /mnt/mdb/myfile.dat
 *
 * Internally every file is folded: the dimensional address is
 * computed on write and stored in the inode. Retrieval is O(1)
 * by address — no directory traversal needed for MDB-aware apps.
 *
 * Classical apps (cp, cat, vim, etc.) use it as a normal filesystem.
 * MDB-aware apps can use ioctl(fd, MDBFS_IOCTL_GETADDR, &addr) to
 * get the dimensional address of any file directly.
 */

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/pagemap.h>
#include <linux/highmem.h>
#include <linux/time.h>
#include <linux/string.h>
#include <linux/backing-dev.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/parser.h>
#include <linux/magic.h>
#include <linux/uaccess.h>
#include <linux/seq_file.h>
#include <linux/statfs.h>
#include <linux/ioctl.h>

#include "mdb_core.h"

/* ── ioctl interface for MDB-aware apps ──────────────────────────────────── */

/* Get the dimensional address of an open file */
#define MDBFS_IOCTL_GETADDR  _IOR('M', 1, mdb_addr_t)
/* Get the tick count (how many evolve_steps applied) */
#define MDBFS_IOCTL_GETTICKS _IOR('M', 2, u64)
/* Manually trigger one evolve_step on file's inode SuperBit */
#define MDBFS_IOCTL_EVSTEP   _IO ('M', 3)

/* ── Per-inode MDB data ──────────────────────────────────────────────────── */

struct mdbfs_inode_info {
    struct inode   vfs_inode;
    mdb_addr_t     addr;       /* dimensional address of file content */
    u64            ticks;      /* evolve_steps applied to this inode */
    u32            checksum;   /* CRC32 of content at last write */
    char           mdb_label[64];
};

static inline struct mdbfs_inode_info *MDB_I(struct inode *inode)
{
    return container_of(inode, struct mdbfs_inode_info, vfs_inode);
}

/* ── Superblock ──────────────────────────────────────────────────────────── */

static struct inode *mdbfs_get_inode(struct super_block *sb,
                                      const struct inode *dir,
                                      umode_t mode, dev_t dev);

/* mdbfs_ops was removed — superseded by mdbfs_super_ops below */

/* ── File operations ─────────────────────────────────────────────────────── */

/*
 * On every write: recompute the dimensional address of the new content.
 * The inode's addr field is updated atomically.
 * Classical apps just see a normal write. MDB-aware apps see the address change.
 */
static ssize_t mdbfs_write_iter(struct kiocb *iocb, struct iov_iter *from)
{
    struct file *file = iocb->ki_filp;
    struct inode *inode = file_inode(file);
    struct mdbfs_inode_info *mi = MDB_I(inode);
    ssize_t ret;
    u8 *buf;
    loff_t size;

    /* Standard page-cache write */
    ret = generic_file_write_iter(iocb, from);

    if (ret > 0) {
        /* Recompute dimensional address from new content */
        size = i_size_read(inode);
        if (size > 0 && size <= MDB_MAX_BYTES) {
            buf = kvmalloc(size, GFP_KERNEL);
            if (buf) {
                struct address_space *mapping = inode->i_mapping;
                loff_t pos = 0;
                u64 remaining = size;

                /* Read pages into contiguous buffer */
                while (remaining > 0) {
                    struct page *page;
                    u64 chunk = min_t(u64, remaining, PAGE_SIZE);
                    pgoff_t index = pos >> PAGE_SHIFT;
                    page = find_get_page(mapping, index);
                    if (page) {
                        u8 *kaddr = kmap_atomic(page);
                        MDB_MEMCPY(buf + pos, kaddr + (pos & ~PAGE_MASK),
                                   min_t(u64, chunk, PAGE_SIZE - (pos & ~PAGE_MASK)));
                        kunmap_atomic(kaddr);
                        put_page(page);
                    }
                    pos += chunk;
                    remaining -= chunk;
                }

                mi->addr     = mdb_compute_addr(buf, size);
                mi->checksum = mdb_crc32(buf, size);
                kvfree(buf);
            }
        }
    }

    return ret;
}

static long mdbfs_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    struct inode *inode = file_inode(file);
    struct mdbfs_inode_info *mi = MDB_I(inode);

    switch (cmd) {
    case MDBFS_IOCTL_GETADDR:
        if (copy_to_user((void __user *)arg, &mi->addr, sizeof(mdb_addr_t)))
            return -EFAULT;
        return 0;

    case MDBFS_IOCTL_GETTICKS:
        if (copy_to_user((void __user *)arg, &mi->ticks, sizeof(u64)))
            return -EFAULT;
        return 0;

    case MDBFS_IOCTL_EVSTEP: {
        /* Apply one evolve_step to the inode's address bits.
         * Demonstrates the MDB clock at filesystem level. */
        u8 addr_bits[192];  /* D3(64) + D4(64) + D5(64) as bit arrays */
        u64 i;
        /* Encode current address as bit string */
        for (i = 0; i < 64; i++) {
            addr_bits[i]       = (mi->addr.d3 >> (63 - i)) & 1;
            addr_bits[64 + i]  = (mi->addr.d4 >> (63 - i)) & 1;
            addr_bits[128 + i] = (mi->addr.d5 >> (63 - i)) & 1;
        }
        mdb_evolve_step(addr_bits, 192);
        mi->ticks++;
        /* Decode back */
        mi->addr.d3 = 0; mi->addr.d4 = 0; mi->addr.d5 = 0;
        for (i = 0; i < 64; i++) {
            mi->addr.d3 = (mi->addr.d3 << 1) | addr_bits[i];
            mi->addr.d4 = (mi->addr.d4 << 1) | addr_bits[64 + i];
            mi->addr.d5 = (mi->addr.d5 << 1) | addr_bits[128 + i];
        }
        return 0;
    }

    default:
        return -ENOTTY;
    }
}

static const struct file_operations mdbfs_file_ops = {
    .read_iter      = generic_file_read_iter,
    .write_iter     = mdbfs_write_iter,
    .mmap           = generic_file_mmap,
    .fsync          = noop_fsync,
    .splice_read    = filemap_splice_read,
    .splice_write   = iter_file_splice_write,
    .llseek         = generic_file_llseek,
    .unlocked_ioctl = mdbfs_ioctl,
};

static const struct inode_operations mdbfs_file_inode_ops = {
    .setattr        = simple_setattr,
    .getattr        = simple_getattr,
};

/* ── Directory operations ────────────────────────────────────────────────── */

static int mdbfs_mknod(struct mnt_idmap *idmap, struct inode *dir,
                        struct dentry *dentry, umode_t mode, dev_t dev)
{
    struct inode *inode = mdbfs_get_inode(dir->i_sb, dir, mode, dev);
    int error = -ENOSPC;

    if (inode) {
        d_instantiate(dentry, inode);
        dget(dentry);
        error = 0;
        inode_set_mtime_to_ts(dir, current_time(dir));
        inode_set_ctime_current(dir);
    }
    return error;
}

static struct dentry *mdbfs_mkdir(struct mnt_idmap *idmap, struct inode *dir,
                                   struct dentry *dentry, umode_t mode)
{
    int ret = mdbfs_mknod(idmap, dir, dentry, mode | S_IFDIR, 0);
    if (!ret)
        inc_nlink(dir);
    return ERR_PTR(ret);  /* ERR_PTR(0) == NULL == success */
}

static int mdbfs_create(struct mnt_idmap *idmap, struct inode *dir,
                         struct dentry *dentry, umode_t mode, bool excl)
{
    return mdbfs_mknod(idmap, dir, dentry, mode | S_IFREG, 0);
}

static int mdbfs_symlink(struct mnt_idmap *idmap, struct inode *dir,
                          struct dentry *dentry, const char *symname)
{
    struct inode *inode;
    int error = -ENOSPC;

    inode = mdbfs_get_inode(dir->i_sb, dir, S_IFLNK | S_IRWXUGO, 0);
    if (inode) {
        int l = strlen(symname) + 1;
        error = page_symlink(inode, symname, l);
        if (!error) {
            d_instantiate(dentry, inode);
            dget(dentry);
            inode_set_mtime_to_ts(dir, current_time(dir));
            inode_set_ctime_current(dir);
        } else {
            iput(inode);
        }
    }
    return error;
}

static const struct inode_operations mdbfs_dir_inode_ops = {
    .create         = mdbfs_create,
    .lookup         = simple_lookup,
    .link           = simple_link,
    .unlink         = simple_unlink,
    .symlink        = mdbfs_symlink,
    .mkdir          = mdbfs_mkdir,
    .rmdir          = simple_rmdir,
    .mknod          = mdbfs_mknod,
    .rename         = simple_rename,
};

/* ── Inode allocation ────────────────────────────────────────────────────── */

static struct kmem_cache *mdbfs_inode_cachep;

static struct inode *mdbfs_alloc_inode(struct super_block *sb)
{
    struct mdbfs_inode_info *mi;
    mi = alloc_inode_sb(sb, mdbfs_inode_cachep, GFP_KERNEL);
    if (!mi) return NULL;

    MDB_MEMSET(&mi->addr, 0, sizeof(mdb_addr_t));
    mi->ticks    = 0;
    mi->checksum = 0;
    MDB_MEMSET(mi->mdb_label, 0, 64);

    return &mi->vfs_inode;
}

static void mdbfs_free_inode(struct inode *inode)
{
    kmem_cache_free(mdbfs_inode_cachep, MDB_I(inode));
}

static const struct super_operations mdbfs_super_ops = {
    .alloc_inode    = mdbfs_alloc_inode,
    .free_inode     = mdbfs_free_inode,
    .statfs         = simple_statfs,
    .drop_inode     = generic_delete_inode,
};

static struct inode *mdbfs_get_inode(struct super_block *sb,
                                      const struct inode *dir,
                                      umode_t mode, dev_t dev)
{
    struct inode *inode = new_inode(sb);

    if (inode) {
        inode->i_ino = get_next_ino();
        inode_init_owner(&nop_mnt_idmap, inode, dir, mode);
        inode->i_mapping->a_ops = &ram_aops;
        mapping_set_gfp_mask(inode->i_mapping, GFP_HIGHUSER);
        mapping_set_unevictable(inode->i_mapping);
        simple_inode_init_ts(inode);

        switch (mode & S_IFMT) {
        case S_IFREG:
            inode->i_op  = &mdbfs_file_inode_ops;
            inode->i_fop = &mdbfs_file_ops;
            break;
        case S_IFDIR:
            inode->i_op  = &mdbfs_dir_inode_ops;
            inode->i_fop = &simple_dir_operations;
            inc_nlink(inode);
            break;
        case S_IFLNK:
            inode->i_op = &page_symlink_inode_operations;
            inode_nohighmem(inode);
            break;
        default:
            init_special_inode(inode, mode, dev);
            break;
        }
    }
    return inode;
}

/* ── Superblock fill ─────────────────────────────────────────────────────── */

static int mdbfs_fill_super(struct super_block *sb, void *data, int silent)
{
    struct inode *inode;

    sb->s_maxbytes       = MAX_LFS_FILESIZE;
    sb->s_blocksize      = PAGE_SIZE;
    sb->s_blocksize_bits = PAGE_SHIFT;
    sb->s_magic          = MDBFS_MAGIC;
    sb->s_op             = &mdbfs_super_ops;
    sb->s_time_gran      = 1;

    inode = mdbfs_get_inode(sb, NULL, S_IFDIR | 0755, 0);
    if (!inode) return -ENOMEM;

    sb->s_root = d_make_root(inode);
    if (!sb->s_root) return -ENOMEM;

    return 0;
}

static struct dentry *mdbfs_mount(struct file_system_type *fs_type,
                                   int flags, const char *dev_name, void *data)
{
    return mount_nodev(fs_type, flags, data, mdbfs_fill_super);
}

static struct file_system_type mdbfs_type = {
    .owner    = THIS_MODULE,
    .name     = "mdbfs",
    .mount    = mdbfs_mount,
    .kill_sb  = kill_litter_super,
};

/* ── Module init / exit ──────────────────────────────────────────────────── */

static void mdbfs_inode_init_once(void *foo)
{
    struct mdbfs_inode_info *mi = foo;
    inode_init_once(&mi->vfs_inode);
}

int mdbfs_init(void)
{
    int ret;

    mdbfs_inode_cachep = kmem_cache_create("mdbfs_inode_cache",
                            sizeof(struct mdbfs_inode_info), 0,
                            SLAB_RECLAIM_ACCOUNT | SLAB_ACCOUNT,
                            mdbfs_inode_init_once);
    if (!mdbfs_inode_cachep)
        return -ENOMEM;

    ret = register_filesystem(&mdbfs_type);
    if (ret) {
        kmem_cache_destroy(mdbfs_inode_cachep);
        return ret;
    }

    pr_info("mdbfs: registered (magic=0x%08X)\n", MDBFS_MAGIC);
    return 0;
}

void mdbfs_exit(void)
{
    unregister_filesystem(&mdbfs_type);
    kmem_cache_destroy(mdbfs_inode_cachep);
    pr_info("mdbfs: unregistered\n");
}

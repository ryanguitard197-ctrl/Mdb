/* mdb_module.c — MDB Linux Kernel Module Entry Point
 *
 * Loads as a single kernel module (mdb.ko).
 * On insmod:
 *   1. Registers /dev/mdb     (fold/unfold/addr/evolve interface)
 *   2. Registers mdbfs        (mountable dimensional filesystem)
 *   3. Creates /proc/mdb      (stats)
 *
 * On rmmod: cleans everything up.
 *
 * Usage after insmod:
 *   mount -t mdbfs none /mnt/mdb
 *   cat /proc/mdb
 *   mdb-tool fold myfile.bin
 */

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>

#include "mdb_core.h"

MODULE_LICENSE("GPL");
MODULE_AUTHOR("MDB Project");
MODULE_DESCRIPTION("Multidimensional Binary OS substrate: fold engine, mdbfs, /dev/mdb");
MODULE_VERSION("1.0");

/* Declared in mdb_syscalls.c and mdbfs.c */
extern int  mdb_dev_init(void);
extern void mdb_dev_exit(void);
extern int  mdbfs_init(void);
extern void mdbfs_exit(void);

static int __init mdb_module_init(void)
{
    int ret;

    pr_info("MDB OS substrate v%d.%d loading...\n",
            MDB_VERSION_MAJOR, MDB_VERSION_MINOR);

    /* 1. Character device + /proc/mdb */
    ret = mdb_dev_init();
    if (ret) {
        pr_err("mdb: device init failed (%d)\n", ret);
        return ret;
    }

    /* 2. mdbfs filesystem */
    ret = mdbfs_init();
    if (ret) {
        pr_err("mdb: filesystem init failed (%d)\n", ret);
        mdb_dev_exit();
        return ret;
    }

    pr_info("MDB OS substrate loaded.\n");
    pr_info("  /dev/mdb    — fold/unfold/addr/evolve\n");
    pr_info("  mdbfs       — mount with: mount -t mdbfs none /mnt/mdb\n");
    pr_info("  /proc/mdb   — runtime stats\n");
    return 0;
}

static void __exit mdb_module_exit(void)
{
    mdbfs_exit();
    mdb_dev_exit();
    pr_info("MDB OS substrate unloaded.\n");
}

module_init(mdb_module_init);
module_exit(mdb_module_exit);

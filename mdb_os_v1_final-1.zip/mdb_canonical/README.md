# MDB OS Substrate v1.0

Multidimensional Binary OS substrate for Linux.
Runs on any Linux machine. All existing software works unchanged.
MDB capabilities available from first boot.

## What this is

A Linux kernel module that adds MDB primitives natively to any Linux system:

- `/dev/mdb`    — fold, unfold, addr, evolve syscall interface
- `/mnt/mdb`    — mdbfs: files addressed by D3/D4/D5 coordinates
- `/proc/mdb`   — runtime stats
- `mdb` CLI     — userspace tool for any user

## Quick install (Linux, requires root)

```bash
chmod +x install.sh
sudo ./install.sh
```

That's it. The script:
1. Builds the kernel module
2. Builds the userspace tool
3. Loads the module
4. Mounts mdbfs at /mnt/mdb
5. Runs a self-test
6. Installs `mdb` to /usr/local/bin

## Manual build

```bash
# Userspace tool only (no root needed)
cd userspace && make && ./mdb-demo

# Kernel module (requires kernel headers)
cd kernel && make

# Load
sudo insmod kernel/mdb.ko
sudo mkdir -p /mnt/mdb
sudo mount -t mdbfs none /mnt/mdb
```

## Requirements

- Linux kernel 5.15+ (Ubuntu 22.04, Debian 12, Fedora 38+)
- gcc, make
- linux-headers matching your running kernel

```bash
# Ubuntu/Debian
sudo apt-get install build-essential linux-headers-$(uname -r)

# Fedora/RHEL
sudo dnf install gcc make kernel-devel
```

## Usage

```bash
# Dimensional address of any file
mdb addr myfile.txt

# Fold (lossless dimensional storage)
mdb fold myfile.txt myfile.mdb

# Unfold (100% lossless restore)
mdb unfold myfile.mdb myfile_restored.txt

# Verify integrity
mdb verify myfile.mdb

# Apply evolve_steps
mdb evolve myfile.txt 10

# Live demo
mdb demo

# Kernel stats
cat /proc/mdb
```

## File layout

```
mdb_kernel/
├── install.sh              — full install script
├── kernel/
│   ├── mdb_core.h          — MDB types and declarations
│   ├── mdb_core.c          — fold engine, D3/D4/D5, evolve_step
│   ├── mdbfs.c             — Linux filesystem driver
│   ├── mdb_syscalls.c      — /dev/mdb character device
│   ├── mdb_module.c        — module init/exit
│   └── Makefile
└── userspace/
    ├── mdb_tool.c          — CLI tool
    ├── mdb_demo.c          — standalone demo
    └── Makefile
```

## The MDB primitives

**D3 — Temporal coordinate**: length of the data in bytes.
Length IS time. This is the founding insight.

**D4 — Probability density**: ratio of 1-bits × 10^6.
Encodes the information density of the data.

**D5 — Relational gravity**: PHI-weighted positional sum mod 10^6.
PHI is maximally irrational — no two positions produce the same contribution.

**evolve_step**: deterministic rule.
- Odd length → flip middle bit
- Even length → flip last bit

The data's own length drives its own evolution. No randomness. No external input.

**fold**: attach a 32-byte dimensional header to data.
Not compression. Full data preserved. Retrieval is O(1) by address.

## Version roadmap

- v1.0 — This. Linux substrate. fold/unfold. mdbfs. /dev/mdb.
- v1.1 — MDB scheduler module (evolve_step drives process selection)
- v1.2 — MDB memory addressing (D3/D4/D5 virtual memory regions)
- v2.0 — Standalone ISO. Boot without Linux underneath.

/* mdb_tool.c — MDB Userspace CLI Tool
 *
 * Compile:  gcc -O2 -o mdb-tool mdb_tool.c mdb_core.c
 * Install:  sudo cp mdb-tool /usr/local/bin/mdb
 *
 * Commands:
 *   mdb addr  <file>            — print dimensional address of file
 *   mdb fold  <file> <out>      — fold file into dimensional storage
 *   mdb unfold <file> <out>     — unfold back to original
 *   mdb verify <file>           — verify a folded file's integrity
 *   mdb evolve <file> [steps]   — apply N evolve_steps, show new address
 *   mdb info                    — print /proc/mdb stats
 *   mdb demo                    — run the dimensional addressing demo
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <errno.h>

/* Userspace build of mdb_core */
#include "mdb_core.h"

/* ── File utilities ──────────────────────────────────────────────────────── */

static u8 *read_file(const char *path, u64 *size)
{
    FILE *f = fopen(path, "rb");
    u8 *buf;
    if (!f) { fprintf(stderr, "error: cannot open '%s': %s\n", path, strerror(errno)); return NULL; }
    fseek(f, 0, SEEK_END);
    *size = (u64)ftell(f);
    fseek(f, 0, SEEK_SET);
    buf = (u8 *)malloc(*size);
    if (!buf) { fclose(f); return NULL; }
    if (fread(buf, 1, *size, f) != *size) { free(buf); fclose(f); return NULL; }
    fclose(f);
    return buf;
}

static int write_file(const char *path, const u8 *data, u64 size)
{
    FILE *f = fopen(path, "wb");
    if (!f) { fprintf(stderr, "error: cannot write '%s': %s\n", path, strerror(errno)); return -1; }
    if (fwrite(data, 1, size, f) != size) { fclose(f); return -1; }
    fclose(f);
    return 0;
}

/* ── Print address ───────────────────────────────────────────────────────── */

static void print_addr(const mdb_addr_t *a, const char *label)
{
    printf("  %-12s D3=%-12llu  D4=%-12llu  D5=%-12llu\n",
           label,
           (unsigned long long)a->d3,
           (unsigned long long)a->d4,
           (unsigned long long)a->d5);
}

/* ── Commands ────────────────────────────────────────────────────────────── */

static int cmd_addr(const char *path)
{
    u64 size;
    u8 *buf = read_file(path, &size);
    mdb_addr_t addr;
    if (!buf) return 1;
    addr = mdb_compute_addr(buf, size);
    printf("File: %s (%llu bytes)\n", path, (unsigned long long)size);
    print_addr(&addr, "address:");
    printf("\n  D3 (temporal):  %llu  — length in bytes\n",  (unsigned long long)addr.d3);
    printf("  D4 (density):   %llu  — ones per million bits\n", (unsigned long long)addr.d4);
    printf("  D5 (gravity):   %llu  — PHI-weighted position sum\n", (unsigned long long)addr.d5);
    free(buf);
    return 0;
}

static int cmd_fold(const char *in_path, const char *out_path)
{
    u64 in_size, out_size;
    u8 *in_buf, *out_buf;
    mdb_addr_t addr;
    int ret = 0;

    in_buf = read_file(in_path, &in_size);
    if (!in_buf) return 1;

    out_size = in_size + MDB_FOLD_HDR_SIZE;
    out_buf  = (u8 *)malloc(out_size);
    if (!out_buf) { free(in_buf); return 1; }

    if (!mdb_fold(in_buf, in_size, out_buf, out_size)) {
        fprintf(stderr, "fold failed\n");
        ret = 1; goto done;
    }

    if (write_file(out_path, out_buf, out_size)) {
        ret = 1; goto done;
    }

    addr = mdb_compute_addr(in_buf, in_size);
    printf("Folded: %s → %s\n", in_path, out_path);
    printf("  Original: %llu bytes\n", (unsigned long long)in_size);
    printf("  Folded:   %llu bytes (%d byte header + original data)\n",
           (unsigned long long)out_size, MDB_FOLD_HDR_SIZE);
    print_addr(&addr, "address:");
    printf("  Retrieve by address — O(1), no search needed.\n");

done:
    free(in_buf);
    free(out_buf);
    return ret;
}

static int cmd_unfold(const char *in_path, const char *out_path)
{
    u64 in_size, orig_len;
    u8 *in_buf;
    const u8 *orig;
    int ret = 0;

    in_buf = read_file(in_path, &in_size);
    if (!in_buf) return 1;

    orig = mdb_unfold(in_buf, in_size, &orig_len);
    if (!orig) {
        fprintf(stderr, "unfold failed: bad header or corrupted data\n");
        free(in_buf);
        return 1;
    }

    if (write_file(out_path, orig, orig_len)) {
        ret = 1; goto done;
    }

    printf("Unfolded: %s → %s\n", in_path, out_path);
    printf("  Restored: %llu bytes (100%% lossless)\n", (unsigned long long)orig_len);
    printf("  Dimensional address verified.\n");
    printf("  CRC32 verified.\n");

done:
    free(in_buf);
    return ret;
}

static int cmd_verify(const char *path)
{
    u64 size;
    u8 *buf = read_file(path, &size);
    int ok;
    if (!buf) return 1;
    ok = mdb_verify(buf, size);
    printf("File: %s\n", path);
    printf("  Integrity: %s\n", ok ? "VERIFIED (lossless)" : "FAILED (corrupted)");
    if (ok) {
        u64 orig_len;
        const u8 *orig = mdb_unfold(buf, size, &orig_len);
        mdb_addr_t stored = ((mdb_fold_hdr_t *)buf)->addr;
        printf("  Original size: %llu bytes\n", (unsigned long long)orig_len);
        print_addr(&stored, "stored addr:");
    }
    free(buf);
    return ok ? 0 : 1;
}

static int cmd_evolve(const char *path, u64 steps)
{
    u64 size;
    u8 *buf;
    mdb_superbit_t *sb;
    mdb_addr_t before;
    u64 i;

    buf = read_file(path, &size);
    if (!buf) return 1;

    sb = mdb_superbit_new(path, buf, size);
    free(buf);
    if (!sb) return 1;

    before = sb->addr;
    printf("File: %s (%llu bits)\n", path, (unsigned long long)sb->len);
    print_addr(&before, "before:");

    for (i = 0; i < steps; i++)
        mdb_superbit_tick(sb);

    printf("After %llu evolve_step(s):\n", (unsigned long long)steps);
    print_addr(&sb->addr, "after:");
    printf("  Flips applied: %llu\n", (unsigned long long)sb->ticks);

    mdb_superbit_free(sb);
    return 0;
}

static int cmd_info(void)
{
    FILE *f = fopen("/proc/mdb", "r");
    char line[256];
    if (!f) {
        printf("MDB module not loaded. Run: sudo insmod mdb.ko\n");
        return 1;
    }
    printf("=== MDB Kernel Module Stats ===\n");
    while (fgets(line, sizeof(line), f))
        printf("  %s", line);
    fclose(f);
    return 0;
}

static int cmd_demo(void)
{
    /* Show the core concept: same data → same address on any machine */
    const char *samples[] = {
        "Hello, World!",
        "MDB OS v1.0",
        "The same string always maps to the same dimensional address.",
        "Different strings cannot share an address."
    };
    int n = 4, i;
    mdb_addr_t addr;
    u8 bits[32];
    u64 j;

    printf("=== MDB Dimensional Addressing Demo ===\n\n");
    printf("Every string has a unique, computable address in D3/D4/D5 space.\n");
    printf("Retrieval is O(1): compute address, look up directly.\n\n");

    for (i = 0; i < n; i++) {
        addr = mdb_compute_addr((const u8 *)samples[i], strlen(samples[i]));
        printf("  \"%s\"\n", samples[i]);
        print_addr(&addr, "");
        printf("\n");
    }

    printf("=== evolve_step Demo ===\n\n");
    printf("Deterministic evolution: odd length → flip middle, even → flip last.\n\n");

    /* 8-bit string: "10110010" */
    for (j = 0; j < 8; j++) bits[j] = "10110010"[j] - '0';

    for (i = 0; i < 8; i++) {
        printf("  step %d: ", i);
        for (j = 0; j < 8; j++) printf("%d", bits[j]);
        addr = mdb_compute_addr_bits(bits, 8);
        printf("  D3=%llu D4=%llu D5=%llu\n",
               (unsigned long long)addr.d3,
               (unsigned long long)addr.d4,
               (unsigned long long)addr.d5);
        mdb_evolve_step(bits, 8);
    }

    return 0;
}

/* ── Main ────────────────────────────────────────────────────────────────── */

static void usage(void)
{
    printf("MDB Tool v1.0 — Multidimensional Binary Substrate\n\n");
    printf("Usage:\n");
    printf("  mdb addr   <file>              Print dimensional address\n");
    printf("  mdb fold   <file> <output>     Fold file into MDB storage\n");
    printf("  mdb unfold <file> <output>     Unfold back to original\n");
    printf("  mdb verify <file>              Verify integrity of folded file\n");
    printf("  mdb evolve <file> [N]          Apply N evolve_steps (default: 1)\n");
    printf("  mdb info                       Show kernel module stats\n");
    printf("  mdb demo                       Run addressing + evolution demo\n");
}

int main(int argc, char *argv[])
{
    if (argc < 2) { usage(); return 1; }

    if (!strcmp(argv[1], "addr") && argc >= 3)
        return cmd_addr(argv[2]);
    if (!strcmp(argv[1], "fold") && argc >= 4)
        return cmd_fold(argv[2], argv[3]);
    if (!strcmp(argv[1], "unfold") && argc >= 4)
        return cmd_unfold(argv[2], argv[3]);
    if (!strcmp(argv[1], "verify") && argc >= 3)
        return cmd_verify(argv[2]);
    if (!strcmp(argv[1], "evolve") && argc >= 3)
        return cmd_evolve(argv[2], argc >= 4 ? (u64)atoll(argv[3]) : 1);
    if (!strcmp(argv[1], "info"))
        return cmd_info();
    if (!strcmp(argv[1], "demo"))
        return cmd_demo();

    usage();
    return 1;
}

/* mdb_demo.c — Standalone MDB Demo
 * Shows dimensional addressing, fold/unfold, and evolve_step
 * with no kernel module needed. Pure userspace C.
 *
 * Compile: gcc -O2 -o mdb-demo mdb_demo.c ../kernel/mdb_core.c
 * Run:     ./mdb-demo
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../kernel/mdb_core.h"

static void print_addr(const char *label, const mdb_addr_t *a)
{
    printf("  %-20s D3=%-10llu D4=%-10llu D5=%-10llu\n",
           label,
           (unsigned long long)a->d3,
           (unsigned long long)a->d4,
           (unsigned long long)a->d5);
}

static void separator(void) { printf("  %s\n", "─────────────────────────────────────────────────────"); }

int main(void)
{
    printf("\n");
    printf("  ╔═══════════════════════════════════════════════════════╗\n");
    printf("  ║         MDB OS v1.0 — Live Demonstration              ║\n");
    printf("  ║         Multidimensional Binary Substrate             ║\n");
    printf("  ╚═══════════════════════════════════════════════════════╝\n\n");

    /* ── 1. Dimensional Addressing ── */
    printf("  [1] DIMENSIONAL ADDRESSING\n");
    separator();
    printf("  Every piece of data has a unique address in D3/D4/D5 space.\n");
    printf("  Same data = same address on ANY machine. Always.\n\n");

    const char *samples[] = {
        "Hello, World!",
        "MDB OS v1.0",
        "Chrome.exe",
        "my_document.docx",
        "game_save_slot1.dat"
    };
    int i;
    for (i = 0; i < 5; i++) {
        mdb_addr_t a = mdb_compute_addr((const u8*)samples[i], strlen(samples[i]));
        print_addr(samples[i], &a);
    }

    /* ── 2. Fold / Unfold ── */
    printf("\n  [2] FOLD / UNFOLD — LOSSLESS DIMENSIONAL STORAGE\n");
    separator();
    printf("  No compression. No information loss.\n");
    printf("  The dimensional address IS the retrieval key.\n\n");

    const char *test = "This is a test of the MDB fold engine. "
                       "Every byte is preserved. Zero loss.";
    u64 test_len = (u64)strlen(test);
    u64 fold_buf_size = test_len + MDB_FOLD_HDR_SIZE;
    u8 *fold_buf = (u8*)malloc(fold_buf_size);

    u64 folded_size = mdb_fold((const u8*)test, test_len, fold_buf, fold_buf_size);
    printf("  Original:  %llu bytes\n", (unsigned long long)test_len);
    printf("  Folded:    %llu bytes (%d byte header + original)\n",
           (unsigned long long)folded_size, MDB_FOLD_HDR_SIZE);

    u64 orig_len;
    const u8 *restored = mdb_unfold(fold_buf, folded_size, &orig_len);
    int match = (orig_len == test_len && memcmp(restored, test, test_len) == 0);
    printf("  Unfolded:  %llu bytes\n", (unsigned long long)orig_len);
    printf("  Lossless:  %s\n", match ? "✓ VERIFIED — byte-perfect restoration" : "✗ FAILED");

    mdb_addr_t fold_addr = mdb_compute_addr((const u8*)test, test_len);
    print_addr("  address:", &fold_addr);
    free(fold_buf);

    /* ── 3. evolve_step ── */
    printf("\n  [3] EVOLVE_STEP — DETERMINISTIC EVOLUTION\n");
    separator();
    printf("  The string's own length drives its next state. No randomness.\n");
    printf("  Odd length → flip middle bit. Even length → flip last bit.\n\n");

    u8 bits[16];
    int b;
    for (b = 0; b < 16; b++) bits[b] = b % 2;

    printf("  Initial: ");
    for (b = 0; b < 16; b++) printf("%d", bits[b]);
    mdb_addr_t ea = mdb_compute_addr_bits(bits, 16);
    printf("  [D3=%llu D4=%llu D5=%llu]\n",
           (unsigned long long)ea.d3,
           (unsigned long long)ea.d4,
           (unsigned long long)ea.d5);

    for (i = 0; i < 8; i++) {
        u64 flipped = mdb_evolve_step(bits, 16);
        ea = mdb_compute_addr_bits(bits, 16);
        printf("  step %d:  ", i + 1);
        for (b = 0; b < 16; b++) printf("%d", bits[b]);
        printf("  [flip@%llu D4=%llu D5=%llu]\n",
               (unsigned long long)flipped,
               (unsigned long long)ea.d4,
               (unsigned long long)ea.d5);
    }

    /* ── 4. SuperBit ── */
    printf("\n  [4] SUPERBIT — DATA WITH NATIVE DIMENSIONAL ADDRESS\n");
    separator();
    const char *sb_data = "Cakewalk project file";
    mdb_superbit_t *sb = mdb_superbit_new("cakewalk.cwp",
                                           (const u8*)sb_data,
                                           strlen(sb_data));
    printf("  Label: %s\n", sb->label);
    printf("  Bits:  %llu\n", (unsigned long long)sb->len);
    print_addr("  address:", &sb->addr);

    for (i = 0; i < 3; i++) {
        mdb_superbit_tick(sb);
        printf("  tick %d:", i+1);
        print_addr("", &sb->addr);
    }
    mdb_superbit_free(sb);

    /* ── Summary ── */
    printf("\n  ╔═══════════════════════════════════════════════════════╗\n");
    printf("  ║  MDB substrate running. All existing software works.  ║\n");
    printf("  ║  MDB-native apps: use /dev/mdb and /mnt/mdb           ║\n");
    printf("  ║  Classical apps:  unchanged, zero overhead            ║\n");
    printf("  ╚═══════════════════════════════════════════════════════╝\n\n");

    return 0;
}

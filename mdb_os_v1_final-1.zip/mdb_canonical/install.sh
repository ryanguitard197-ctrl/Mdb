#!/usr/bin/env bash
# install.sh — Build, install, and test MDB OS substrate
# Run as root or with sudo privileges.
# Tested on Ubuntu 22.04, Debian 12, Fedora 38+.

set -e
cd "$(dirname "$0")"

echo "================================================="
echo "  MDB OS Substrate v1.0 — Install & Test"
echo "================================================="

# ── 1. Check prerequisites ────────────────────────────────────────────────────
echo ""
echo "[1/6] Checking prerequisites..."

if ! command -v gcc &>/dev/null; then
    echo "Installing build tools..."
    apt-get install -y build-essential || dnf install -y gcc make || true
fi

KVER=$(uname -r)
KDIR="/lib/modules/$KVER/build"

if [ ! -d "$KDIR" ]; then
    echo "Kernel headers not found. Installing..."
    apt-get install -y "linux-headers-$KVER" 2>/dev/null || \
    dnf install -y "kernel-devel-$KVER" 2>/dev/null || \
    pacman -S --noconfirm linux-headers 2>/dev/null || \
    { echo "ERROR: Cannot find kernel headers for $KVER"; echo "Run: sudo apt-get install linux-headers-\$(uname -r)"; exit 1; }
fi

echo "  Kernel: $KVER"
echo "  Headers: $KDIR ✓"

# ── 2. Build userspace tool (no root needed) ──────────────────────────────────
echo ""
echo "[2/6] Building mdb-tool (userspace)..."
cd userspace
make clean all
echo "  mdb-tool built ✓"
cd ..

# ── 3. Test userspace tool standalone ────────────────────────────────────────
echo ""
echo "[3/6] Running userspace demo (no kernel module needed)..."
./userspace/mdb-tool demo
echo "  Demo passed ✓"

# Quick self-test: fold and unfold a test file
echo "MDB OS substrate test data" > /tmp/mdb_test_input.txt
./userspace/mdb-tool fold /tmp/mdb_test_input.txt /tmp/mdb_test_folded.mdb
./userspace/mdb-tool verify /tmp/mdb_test_folded.mdb
./userspace/mdb-tool unfold /tmp/mdb_test_folded.mdb /tmp/mdb_test_output.txt

if diff /tmp/mdb_test_input.txt /tmp/mdb_test_output.txt > /dev/null 2>&1; then
    echo "  Fold → Unfold: LOSSLESS ✓"
else
    echo "  ERROR: fold/unfold mismatch!"
    exit 1
fi

# ── 4. Build kernel module ────────────────────────────────────────────────────
echo ""
echo "[4/6] Building kernel module..."
cd kernel
make clean all
echo "  mdb.ko built ✓"
cd ..

# ── 5. Load kernel module ─────────────────────────────────────────────────────
echo ""
echo "[5/6] Loading MDB kernel module..."

# Unload previous version if present
if lsmod | grep -q "^mdb "; then
    echo "  Removing existing module..."
    umount /mnt/mdb 2>/dev/null || true
    rmmod mdb 2>/dev/null || true
fi

insmod kernel/mdb.ko
mkdir -p /mnt/mdb
mount -t mdbfs none /mnt/mdb

echo "  Module loaded ✓"
echo "  /dev/mdb ready ✓"
echo "  /mnt/mdb mounted ✓"

# ── 6. Integration test ───────────────────────────────────────────────────────
echo ""
echo "[6/6] Integration test..."

# Write a file to mdbfs
echo "Hello from MDB OS" > /mnt/mdb/hello.txt
echo "This file lives at a dimensional address." > /mnt/mdb/readme.txt

# Read it back
if diff <(echo "Hello from MDB OS") /mnt/mdb/hello.txt > /dev/null; then
    echo "  mdbfs write/read: PASS ✓"
else
    echo "  mdbfs write/read: FAIL"
    exit 1
fi

# Get dimensional address of the file via mdb-tool
./userspace/mdb-tool addr /mnt/mdb/hello.txt

# Show kernel stats
echo ""
echo "Kernel module stats:"
cat /proc/mdb

# Install mdb tool globally
cp userspace/mdb-tool /usr/local/bin/mdb
echo ""
echo "================================================="
echo "  MDB OS Substrate v1.0 installed successfully."
echo ""
echo "  Commands:"
echo "    mdb addr <file>         — dimensional address"
echo "    mdb fold <in> <out>     — fold to MDB storage"
echo "    mdb unfold <in> <out>   — restore original"
echo "    mdb verify <file>       — verify integrity"
echo "    mdb evolve <file> [N]   — apply evolve_steps"
echo "    mdb demo                — live demo"
echo "    cat /proc/mdb           — kernel stats"
echo ""
echo "  Filesystem: /mnt/mdb (mdbfs mounted)"
echo "  Device:     /dev/mdb"
echo ""
echo "  Any existing software runs unchanged."
echo "  MDB-native apps use /dev/mdb and /mnt/mdb."
echo "================================================="

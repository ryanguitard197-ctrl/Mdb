# Multi Binary Logic - Lossless Integrity Testing Framework

A comprehensive Python framework for testing file integrity through custom folding and unfolding operations using your multi-binary logic algorithm.

## Quick Start

### 1. Create Test Files
```bash
python integrity_tester.py --create-test-files ./test_files
```

### 2. Run Tests
```bash
# Test a single file
python integrity_tester.py ./test_files/test_text.txt

# Test all files in a directory
python integrity_tester.py ./test_files

# Test with pattern matching
python integrity_tester.py ./test_files -p "*.txt"

# Generate reports
python integrity_tester.py ./test_files -o report.txt -j report.json
```

## Integrating Your Multi-Binary Logic

### Option 1: Modify the Base Class (Simplest)

Edit `integrity_tester.py` and replace the placeholder methods in `MultiBinaryLogic` class:

```python
class MultiBinaryLogic:
    def compute_signature(self, data: bytes) -> bytes:
        # YOUR SIGNATURE ALGORITHM
        pass
    
    def fold(self, data: bytes) -> bytes:
        # YOUR FOLD OPERATION
        pass
    
    def unfold(self, folded_data: bytes) -> Tuple[bytes, bool]:
        # YOUR UNFOLD OPERATION
        pass
```

### Option 2: Create a Custom Class (Recommended)

See `custom_logic_example.py` for a template:

```python
from integrity_tester import MultiBinaryLogic, IntegrityTester

class MyCustomLogic(MultiBinaryLogic):
    def compute_signature(self, data: bytes) -> bytes:
        # Your signature algorithm
        return signature_bytes
    
    def fold(self, data: bytes) -> bytes:
        # Your fold operation
        return folded_data
    
    def unfold(self, folded_data: bytes) -> Tuple[bytes, bool]:
        # Your unfold operation
        return unfolded_data, integrity_verified

# Use it
logic = MyCustomLogic()
tester = IntegrityTester(logic)
tester.test_directory("./my_files")
```

## Framework Components

### IntegrityTester
Main testing class that orchestrates file testing:

```python
tester = IntegrityTester(logic_instance)

# Test single file
report = tester.test_file("path/to/file.bin")

# Test directory
tester.test_directory("./test_files", pattern="*.bin")

# Generate reports
print(tester.generate_report("report.txt"))
tester.export_json("report.json")
```

### IntegrityReport
Dataclass containing test results:

```python
@dataclass
class IntegrityReport:
    filename: str
    file_size: int
    fold_time_ms: float
    unfold_time_ms: float
    original_hash: str
    final_hash: str
    multi_binary_match: bool
    integrity_result: TestResult  # PASSED, FAILED, ERROR
    error_message: Optional[str]
    fold_size: int
    compression_ratio: float
```

### MultiBinaryLogic
Base class for your algorithm:

```python
class MultiBinaryLogic:
    def __init__(self, block_size: int = 1024):
        self.block_size = block_size
    
    def compute_signature(self, data: bytes) -> bytes:
        """Compute multi-binary signature"""
        raise NotImplementedError
    
    def fold(self, data: bytes) -> bytes:
        """Fold/compress/encode data"""
        raise NotImplementedError
    
    def unfold(self, folded_data: bytes) -> Tuple[bytes, bool]:
        """Unfold/decompress/decode and verify"""
        raise NotImplementedError
    
    def verify_integrity(self, original: bytes, unfolded: bytes) -> bool:
        """Full byte-by-byte comparison"""
        return original == unfolded
```

## Testing Workflow

1. **Fold Operation**: Compress/encode the original file
2. **Signature Generation**: Compute multi-binary signature
3. **Unfold Operation**: Decompress/decode back to original
4. **Integrity Verification**: Compare signatures and full data

## Report Output

### Console Output
```
======================================================================
MULTI BINARY LOGIC - INTEGRITY TEST REPORT
======================================================================
Total Tests: 5
Passed: 5
Failed: 0
Errors: 0
Success Rate: 100.00%
----------------------------------------------------------------------

✓ test_text.txt
  Size: 5,800 bytes
  Fold Size: 234 bytes (ratio: 4.03%)
  Fold Time: 0.52ms
  Unfold Time: 0.31ms
  Multi-Binary Match: True
  Original Hash: a3f7c2d8e9b1...
  Final Hash: a3f7c2d8e9b1...
```

### JSON Output
```json
{
  "test_framework": "Multi Binary Logic Integrity Tester",
  "timestamp": "2024-01-15 10:30:45",
  "summary": {
    "total": 5,
    "passed": 5,
    "failed": 0,
    "errors": 0
  },
  "results": [
    {
      "filename": "test_text.txt",
      "file_size": 5800,
      "integrity_result": "PASSED",
      ...
    }
  ]
}
```

## Advanced Usage

### Batch Testing with Custom Parameters

```python
from integrity_tester import MultiBinaryLogic, IntegrityTester

class OptimizedLogic(MultiBinaryLogic):
    def __init__(self, block_size=2048, parallel=True):
        super().__init__(block_size)
        self.parallel = parallel
    
    # ... implement methods ...

# Test with different configurations
configs = [
    {"block_size": 512, "parallel": False},
    {"block_size": 1024, "parallel": True},
    {"block_size": 2048, "parallel": True},
]

for config in configs:
    logic = OptimizedLogic(**config)
    tester = IntegrityTester(logic)
    tester.test_directory("./benchmark_files")
    print(f"Config {config}: {tester.generate_report()}")
```

### Performance Benchmarking

```python
import time

def benchmark_logic(logic_class, test_files):
    logic = logic_class()
    tester = IntegrityTester(logic)
    
    start = time.time()
    for f in test_files:
        tester.test_file(f)
    elapsed = time.time() - start
    
    total_size = sum(os.path.getsize(f) for f in test_files)
    throughput = total_size / elapsed / 1024 / 1024  # MB/s
    
    print(f"Throughput: {throughput:.2f} MB/s")
    return throughput
```

## Tips for Implementation

### Signature Design
- Make signatures collision-resistant
- Include multiple verification layers
- Consider bit-pattern analysis
- Include metadata (size, checksums)

### Fold Operation
- Preserve signature in output
- Use efficient compression if needed
- Consider streaming for large files
- Add version/metadata headers

### Unfold Operation
- Validate all components
- Check sizes match expected values
- Recompute and compare signatures
- Handle errors gracefully

### Testing Strategy
- Test with various file types
- Include edge cases (empty, large, binary)
- Verify corruption detection
- Measure performance metrics

## Troubleshooting

### Common Issues

**"Multi-binary signature mismatch"**
- Check signature computation is deterministic
- Verify no data modification during fold/unfold
- Ensure consistent byte ordering

**"Data mismatch after unfold"**
- Verify compression/decompression is lossless
- Check for buffer overflows
- Validate size calculations

**Performance issues**
- Increase block size for large files
- Consider parallel processing
- Profile signature computation

## File Structure

```
.
├── integrity_tester.py      # Main framework
├── custom_logic_example.py  # Example implementation
├── README.md               # This file
└── test_files/            # Generated test files
    ├── test_text.txt
    ├── test_binary.bin
    ├── test_data.json
    └── test_empty.txt
```

## Requirements

- Python 3.7+
- Standard library only (no external dependencies)

## License

This framework is provided as-is for testing multi-binary logic implementations.

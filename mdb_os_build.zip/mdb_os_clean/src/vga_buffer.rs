// ============================================================================
// src/vga_buffer.rs — VGA Text Mode Driver
//
// Renders the MDB OS desktop: tick counter, dimensional address display,
// live SuperBit network state with weight bars, and a kernel console.
//
// VGA text mode: 80 columns × 25 rows, each cell = (char byte, color byte).
// Buffer lives at physical address 0xb8000 (identity-mapped by bootloader).
// ============================================================================

#![allow(dead_code)]

extern crate alloc;
use alloc::string::String;
use alloc::vec::Vec;
use alloc::collections::BTreeMap;
use core::fmt;

use volatile::Volatile;
use spin::Mutex;
use lazy_static::lazy_static;

use crate::mdb_core::{SuperBit, DimAddr};

// ============================================================================
// COLORS
// ============================================================================

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum Color {
    Black       = 0,
    Blue        = 1,
    Green       = 2,
    Cyan        = 3,
    Red         = 4,
    Magenta     = 5,
    Brown       = 6,
    LightGray   = 7,
    DarkGray    = 8,
    LightBlue   = 9,
    LightGreen  = 10,
    LightCyan   = 11,
    LightRed    = 12,
    Pink        = 13,
    Yellow      = 14,
    White       = 15,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(transparent)]
pub struct ColorCode(u8);

impl ColorCode {
    pub const fn new(fg: Color, bg: Color) -> Self {
        ColorCode((bg as u8) << 4 | (fg as u8))
    }
}

// Palette for the MDB OS desktop
pub const COLOR_TITLE_BAR:  ColorCode = ColorCode::new(Color::Black,      Color::Cyan);
pub const COLOR_HEADER:     ColorCode = ColorCode::new(Color::Yellow,     Color::Black);
pub const COLOR_SEPARATOR:  ColorCode = ColorCode::new(Color::DarkGray,   Color::Black);
pub const COLOR_NODE_NAME:  ColorCode = ColorCode::new(Color::LightCyan,  Color::Black);
pub const COLOR_NODE_STATE: ColorCode = ColorCode::new(Color::White,      Color::Black);
pub const COLOR_BAR_FULL:   ColorCode = ColorCode::new(Color::LightGreen, Color::Black);
pub const COLOR_BAR_EMPTY:  ColorCode = ColorCode::new(Color::DarkGray,   Color::Black);
pub const COLOR_ADDR:       ColorCode = ColorCode::new(Color::DarkGray,   Color::Black);
pub const COLOR_STATUS:     ColorCode = ColorCode::new(Color::Black,      Color::LightGray);
pub const COLOR_NORMAL:     ColorCode = ColorCode::new(Color::LightGray,  Color::Black);
pub const COLOR_BITS:       ColorCode = ColorCode::new(Color::Green,      Color::Black);
pub const COLOR_BITS_ONE:   ColorCode = ColorCode::new(Color::LightGreen, Color::Black);
pub const COLOR_ERROR:      ColorCode = ColorCode::new(Color::LightRed,   Color::Black);
pub const COLOR_CONSOLE:    ColorCode = ColorCode::new(Color::White,      Color::Black);

// ============================================================================
// SCREEN CHARACTER
// ============================================================================

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(C)]
struct ScreenChar {
    ascii: u8,
    color: ColorCode,
}

impl ScreenChar {
    const fn new(ascii: u8, color: ColorCode) -> Self {
        ScreenChar { ascii, color }
    }
    const BLANK: Self = ScreenChar { ascii: b' ', color: COLOR_NORMAL };
}

// ============================================================================
// VGA BUFFER
// ============================================================================

pub const BUFFER_HEIGHT: usize = 25;
pub const BUFFER_WIDTH:  usize = 80;

#[repr(transparent)]
struct Buffer {
    chars: [[Volatile<ScreenChar>; BUFFER_WIDTH]; BUFFER_HEIGHT],
}

// ============================================================================
// WRITER — global VGA writer
// ============================================================================

pub struct Writer {
    /// Current cursor column (used for console area only)
    col: usize,
    /// Console row range: rows CONSOLE_START..BUFFER_HEIGHT-1
    console_row: usize,
    buf: &'static mut Buffer,
}

const CONSOLE_START: usize = 20; // rows 0-19 = desktop, 20-24 = console

impl Writer {
    fn write_char_at(&mut self, row: usize, col: usize, c: u8, color: ColorCode) {
        if row >= BUFFER_HEIGHT || col >= BUFFER_WIDTH {
            return;
        }
        self.buf.chars[row][col].write(ScreenChar::new(c, color));
    }

    fn write_str_at(&mut self, row: usize, col: usize, s: &str, color: ColorCode) {
        for (i, byte) in s.bytes().enumerate() {
            if col + i >= BUFFER_WIDTH {
                break;
            }
            let ch = if byte.is_ascii() && byte >= 0x20 { byte } else { b'?' };
            self.buf.chars[row][col + i].write(ScreenChar::new(ch, color));
        }
    }

    /// Fill a row with a repeated character.
    fn fill_row(&mut self, row: usize, c: u8, color: ColorCode) {
        for col in 0..BUFFER_WIDTH {
            self.buf.chars[row][col].write(ScreenChar::new(c, color));
        }
    }

    /// Clear a row to spaces.
    fn clear_row(&mut self, row: usize, color: ColorCode) {
        self.fill_row(row, b' ', color);
    }

    /// Clear the entire screen.
    pub fn clear(&mut self) {
        for row in 0..BUFFER_HEIGHT {
            self.clear_row(row, COLOR_NORMAL);
        }
        self.console_row = CONSOLE_START;
        self.col = 0;
    }

    // ── console (scrolling log area, rows 20-24) ─────────────────────────────

    fn scroll_console(&mut self) {
        for row in CONSOLE_START..BUFFER_HEIGHT - 1 {
            for col in 0..BUFFER_WIDTH {
                let ch = self.buf.chars[row + 1][col].read();
                self.buf.chars[row][col].write(ch);
            }
        }
        self.clear_row(BUFFER_HEIGHT - 1, COLOR_CONSOLE);
    }

    pub fn console_newline(&mut self) {
        if self.console_row >= BUFFER_HEIGHT - 1 {
            self.scroll_console();
            self.console_row = BUFFER_HEIGHT - 1;
        } else {
            self.console_row += 1;
        }
        self.col = 0;
    }

    pub fn console_write_byte(&mut self, byte: u8) {
        match byte {
            b'\n' => self.console_newline(),
            byte => {
                if self.col >= BUFFER_WIDTH {
                    self.console_newline();
                }
                let row = self.console_row;
                let col = self.col;
                self.buf.chars[row][col].write(ScreenChar::new(byte, COLOR_CONSOLE));
                self.col += 1;
            }
        }
    }

    pub fn console_write_str(&mut self, s: &str) {
        for byte in s.bytes() {
            match byte {
                0x20..=0x7e | b'\n' => self.console_write_byte(byte),
                _ => self.console_write_byte(b'?'),
            }
        }
    }
}

impl fmt::Write for Writer {
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.console_write_str(s);
        Ok(())
    }
}

// ============================================================================
// GLOBAL WRITER
// ============================================================================

lazy_static! {
    pub static ref WRITER: Mutex<Writer> = Mutex::new(Writer {
        col: 0,
        console_row: CONSOLE_START,
        buf: unsafe { &mut *(0xb8000 as *mut Buffer) },
    });
}

// ── public print macros ───────────────────────────────────────────────────────

#[macro_export]
macro_rules! print {
    ($($arg:tt)*) => ($crate::vga_buffer::_print(format_args!($($arg)*)));
}

#[macro_export]
macro_rules! println {
    () => ($crate::print!("\n"));
    ($($arg:tt)*) => ($crate::print!("{}\n", format_args!($($arg)*)));
}

#[doc(hidden)]
pub fn _print(args: fmt::Arguments) {
    use core::fmt::Write;
    use x86_64::instructions::interrupts;
    interrupts::without_interrupts(|| {
        WRITER.lock().write_fmt(args).unwrap();
    });
}

// ============================================================================
// DESKTOP RENDERER
// ============================================================================
//
// Layout (80×25 VGA text):
//
//   Row  0   ── Title bar ──────────────────────────────────────────────────
//   Row  1   ── Tick + global D-values ──────────────────────────────────────
//   Row  2   ── Separator ═══════════════════════════════════════════════════
//   Rows 3-18  Network nodes (up to 16 nodes, 1 row each)
//   Row 19   ── Separator ═══════════════════════════════════════════════════
//   Row 20   ── Console header ──────────────────────────────────────────────
//   Rows 21-24  Scrolling kernel log
//
// Each network node row:
//   [name:10] [state:12] [weight bar:10] [w%:5] [addr:28] [d6:8]

/// Snapshot of one node for rendering (no lock held across render).
pub struct NodeSnapshot {
    pub name: String,
    pub state_label: String,
    pub weights: Vec<f64>,
    pub address: DimAddr,
    pub d6: f64,
    pub generation: u32,
}

/// Full frame data passed to render_frame.
pub struct FrameData {
    pub tick: u64,
    pub global_d3: usize,
    pub global_d4: f64,
    pub global_d5: f64,
    pub nodes: Vec<NodeSnapshot>,
    /// Raw bit string of the active (most recently evolved) SuperBit
    pub active_bits: Vec<u8>,
}

/// Render one complete desktop frame.
/// Call from the kernel main loop, NOT from an interrupt handler.
pub fn render_frame(frame: &FrameData) {
    use x86_64::instructions::interrupts;
    interrupts::without_interrupts(|| {
        let mut w = WRITER.lock();
        render_frame_inner(&mut w, frame);
    });
}

fn render_frame_inner(w: &mut Writer, f: &FrameData) {
    // ── Row 0: title bar ─────────────────────────────────────────────────────
    w.clear_row(0, COLOR_TITLE_BAR);
    let title = "  MDB OS v2.0 \x7c Multidimensional Binary Substrate \x7c Pure Geometric Folding";
    w.write_str_at(0, 0, title, COLOR_TITLE_BAR);

    // ── Row 1: tick + global dimensional values ───────────────────────────────
    w.clear_row(1, COLOR_HEADER);
    // Format: "  TICK: 0000000000   D3: 0000   D4: 0.00000   D5: 0.00000   NODES: 00"
    let tick_str = format_u64(f.tick, 10);
    let d3_str   = format_usize(f.global_d3, 4);
    let d4_str   = format_f64_4(f.global_d4);
    let d5_str   = format_f64_4(f.global_d5);
    let n_str    = format_usize(f.nodes.len(), 2);

    let info = alloc::format!(
        "  TICK: {}   D3: {}   D4: {}   D5: {}   NODES: {}",
        tick_str, d3_str, d4_str, d5_str, n_str
    );
    w.write_str_at(1, 0, &info, COLOR_HEADER);

    // ── Row 2: separator ─────────────────────────────────────────────────────
    w.fill_row(2, b'=', COLOR_SEPARATOR);
    w.write_str_at(2, 1, " NETWORK STATE ", COLOR_SEPARATOR);

    // ── Rows 3-18: node rows ─────────────────────────────────────────────────
    const NODE_ROWS: usize = 16;
    for slot in 0..NODE_ROWS {
        let row = 3 + slot;
        w.clear_row(row, COLOR_NORMAL);
        if slot >= f.nodes.len() {
            continue;
        }
        render_node_row(w, row, &f.nodes[slot]);
    }

    // ── Row 19: bit strip of active SuperBit ─────────────────────────────────
    w.fill_row(19, b'-', COLOR_SEPARATOR);
    w.write_str_at(19, 1, " ACTIVE SUPERBIT BITS ", COLOR_SEPARATOR);
    // Row 19 also shows the raw bit string (first 78 bits)
    // We draw this over the separator using bit colors
    let bit_start = 23; // after the label
    for (i, &bit) in f.active_bits.iter().take(BUFFER_WIDTH - bit_start).enumerate() {
        let (ch, color) = if bit != 0 {
            (b'1', COLOR_BITS_ONE)
        } else {
            (b'0', COLOR_BITS)
        };
        w.write_char_at(19, bit_start + i, ch, color);
    }

    // ── Row 20: console header ────────────────────────────────────────────────
    w.fill_row(20, b'-', COLOR_STATUS);
    w.write_str_at(20, 1, " KERNEL LOG ", COLOR_STATUS);
}

fn render_node_row(w: &mut Writer, row: usize, node: &NodeSnapshot) {
    // Column layout:
    // 0-9:   node name (10)
    // 10:    separator
    // 11-22: state label (12)
    // 23:    separator
    // 24-33: weight bar (10 chars, each = 10% of dominant weight)
    // 34-38: dominant weight % (5)
    // 39:    separator
    // 40-67: dimensional address (28)
    // 68:    separator
    // 69-73: gen (5)
    // 74-79: d6 entropy (6)

    // Name
    let name_trunc = truncate_str(&node.name, 10);
    w.write_str_at(row, 0, &name_trunc, COLOR_NODE_NAME);
    w.write_char_at(row, 10, b'|', COLOR_SEPARATOR);

    // State label
    let state_trunc = truncate_str(&node.state_label, 12);
    w.write_str_at(row, 11, &state_trunc, COLOR_NODE_STATE);
    w.write_char_at(row, 23, b'|', COLOR_SEPARATOR);

    // Weight bar (dominant weight)
    let dominant_w = node.weights.iter().cloned().fold(0.0_f64, f64::max);
    let filled = (dominant_w * 10.0) as usize;
    for i in 0..10 {
        let (ch, color) = if i < filled {
            (0xdb_u8, COLOR_BAR_FULL) // █ in code page 437
        } else {
            (0xb0_u8, COLOR_BAR_EMPTY) // ░
        };
        w.write_char_at(row, 24 + i, ch, color);
    }

    // Weight percentage
    let pct_str = format_pct(dominant_w);
    w.write_str_at(row, 34, &pct_str, COLOR_NODE_STATE);
    w.write_char_at(row, 39, b'|', COLOR_SEPARATOR);

    // Dimensional address: D3:xxxx D4:0.xxxx D5:0.xxxx
    let addr_str = alloc::format!(
        "D3:{} D4:{} D5:{}",
        format_usize(node.address.d3, 4),
        format_f64_4(node.address.d4_float()),
        format_f64_4(node.address.d5_float())
    );
    w.write_str_at(row, 40, &addr_str, COLOR_ADDR);
    w.write_char_at(row, 68, b'|', COLOR_SEPARATOR);

    // Generation
    let gen_str = alloc::format!("g{}", format_usize(node.generation as usize, 4));
    w.write_str_at(row, 69, &gen_str, COLOR_ADDR);

    // D6 entropy (last 6 chars)
    let d6_str = alloc::format!("{}", format_f64_4(node.d6));
    w.write_str_at(row, 74, &d6_str, COLOR_ADDR);
}

// ============================================================================
// DISPLAY HELPERS — no_std formatting
// ============================================================================

/// Format a u64 right-aligned in `width` digits.
fn format_u64(v: u64, width: usize) -> String {
    let s = alloc::format!("{}", v);
    pad_left(&s, width)
}

fn format_usize(v: usize, width: usize) -> String {
    let s = alloc::format!("{}", v);
    pad_left(&s, width)
}

/// Format f64 as X.XXXX (5 chars total, 4 decimal places).
fn format_f64_4(v: f64) -> String {
    // Manual formatting: no_std has no format floats in core
    // Use integer arithmetic
    let integral = v as i64;
    let frac = ((v - integral as f64) * 10000.0).abs() as u64;
    alloc::format!("{}.{:04}", integral, frac)
}

/// Format a probability as a percentage "XX.X%"
fn format_pct(v: f64) -> String {
    let pct = (v * 100.0) as u64;
    let frac = ((v * 1000.0) as u64) % 10;
    alloc::format!("{:02}.{}%", pct, frac)
}

fn pad_left(s: &str, width: usize) -> String {
    if s.len() >= width {
        s[s.len() - width..].to_string()
    } else {
        let mut out = String::new();
        for _ in 0..(width - s.len()) {
            out.push(' ');
        }
        out.push_str(s);
        out
    }
}

fn truncate_str(s: &str, max_len: usize) -> String {
    if s.len() <= max_len {
        let mut out = s.to_string();
        while out.len() < max_len {
            out.push(' ');
        }
        out
    } else {
        s[..max_len].to_string()
    }
}

// ============================================================================
// src/gdt.rs — Global Descriptor Table + TSS
//
// Required for:
//   1. Switching from ring 0 code/data to user mode (future)
//   2. Double fault handler on a known-good separate stack (IST entry)
//
// The double fault IST is critical: if the kernel stack overflows we'd
// triple-fault without it. With it, the double fault handler runs on a
// guaranteed clean 4 KiB stack and can print a diagnostic.
// ============================================================================

use x86_64::VirtAddr;
use x86_64::structures::tss::TaskStateSegment;
use x86_64::structures::gdt::{GlobalDescriptorTable, Descriptor, SegmentSelector};
use lazy_static::lazy_static;

pub const DOUBLE_FAULT_IST_INDEX: u16 = 0;

lazy_static! {
    static ref TSS: TaskStateSegment = {
        let mut tss = TaskStateSegment::new();
        tss.interrupt_stack_table[DOUBLE_FAULT_IST_INDEX as usize] = {
            const STACK_SIZE: usize = 4096 * 5; // 20 KiB double-fault stack
            static mut STACK: [u8; STACK_SIZE] = [0u8; STACK_SIZE];
            let stack_start = VirtAddr::from_ptr(unsafe { &STACK });
            stack_start + STACK_SIZE // stack grows DOWN
        };
        tss
    };
}

pub struct Selectors {
    pub code_selector: SegmentSelector,
    pub tss_selector:  SegmentSelector,
}

lazy_static! {
    static ref GDT: (GlobalDescriptorTable, Selectors) = {
        let mut gdt = GlobalDescriptorTable::new();
        let code_selector = gdt.add_entry(Descriptor::kernel_code_segment());
        let tss_selector  = gdt.add_entry(Descriptor::tss_segment(&TSS));
        (gdt, Selectors { code_selector, tss_selector })
    };
}

pub fn init() {
    use x86_64::instructions::tables::load_tss;
    use x86_64::instructions::segmentation::{CS, Segment};

    GDT.0.load();
    unsafe {
        CS::set_reg(GDT.1.code_selector);
        load_tss(GDT.1.tss_selector);
    }
}

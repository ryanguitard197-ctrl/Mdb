// ============================================================================
// src/interrupts.rs — IDT, PIC, Timer + Keyboard ISRs
//
// Timer IRQ0 fires at ~100 Hz. Each tick:
//   1. Increments KERNEL_TICK (global u64 atomic)
//   2. Calls evolve_step on the active SuperBit in KERNEL_STATE
//   3. Signals the main loop to re-render (RENDER_PENDING flag)
//
// Keyboard IRQ1: PS/2 scancodes decoded and pushed to KEY_BUFFER ring.
// ============================================================================

use x86_64::structures::idt::{InterruptDescriptorTable, InterruptStackFrame, PageFaultErrorCode};
use x86_64::instructions::port::Port;
use pic8259::ChainedPics;
use spin::Mutex;
use lazy_static::lazy_static;
use core::sync::atomic::{AtomicU64, AtomicBool, Ordering};
use pc_keyboard::{layouts, DecodedKey, HandleControl, Keyboard, ScancodeSet1};

use crate::mdb_core::evolve_step;
use crate::println;

// ============================================================================
// KERNEL TICK COUNTER
// ============================================================================

/// Global monotonic tick counter. Incremented every timer IRQ.
/// Used as the deterministic seed for all SuperBit collapses.
pub static KERNEL_TICK: AtomicU64 = AtomicU64::new(0);

/// Set by timer ISR, cleared by main loop after render_frame().
pub static RENDER_PENDING: AtomicBool = AtomicBool::new(false);

/// Set by timer ISR to signal one evolve_step is needed.
pub static EVOLVE_PENDING: AtomicBool = AtomicBool::new(false);

// ============================================================================
// PIC SETUP
// ============================================================================

/// Master PIC offset: IRQ 0-7 → interrupts 32-39
pub const PIC_1_OFFSET: u8 = 32;
/// Slave PIC offset:  IRQ 8-15 → interrupts 40-47
pub const PIC_2_OFFSET: u8 = PIC_1_OFFSET + 8;

pub static PICS: Mutex<ChainedPics> =
    Mutex::new(unsafe { ChainedPics::new(PIC_1_OFFSET, PIC_2_OFFSET) });

#[derive(Debug, Clone, Copy)]
#[repr(u8)]
pub enum InterruptIndex {
    Timer    = PIC_1_OFFSET,       // 32 — IRQ0
    Keyboard = PIC_1_OFFSET + 1,   // 33 — IRQ1
}

impl InterruptIndex {
    fn as_u8(self) -> u8 { self as u8 }
    fn as_usize(self) -> usize { self as usize }
}

// ============================================================================
// IDT
// ============================================================================

lazy_static! {
    static ref IDT: InterruptDescriptorTable = {
        let mut idt = InterruptDescriptorTable::new();

        // CPU exceptions
        idt.breakpoint.set_handler_fn(breakpoint_handler);
        unsafe {
            idt.double_fault
                .set_handler_fn(double_fault_handler)
                .set_stack_index(crate::gdt::DOUBLE_FAULT_IST_INDEX);
        }
        idt.page_fault.set_handler_fn(page_fault_handler);
        idt.general_protection_fault.set_handler_fn(gpf_handler);

        // Hardware interrupts
        idt[InterruptIndex::Timer.as_usize()].set_handler_fn(timer_interrupt_handler);
        idt[InterruptIndex::Keyboard.as_usize()].set_handler_fn(keyboard_interrupt_handler);

        idt
    };
}

pub fn init_idt() {
    IDT.load();
}

// ============================================================================
// TIMER INTERRUPT — IRQ0 (~100 Hz)
// ============================================================================

extern "x86-interrupt" fn timer_interrupt_handler(_stack_frame: InterruptStackFrame) {
    // 1. Increment tick
    let tick = KERNEL_TICK.fetch_add(1, Ordering::Relaxed);

    // 2. Signal main loop: one evolve_step needed
    EVOLVE_PENDING.store(true, Ordering::Release);

    // 3. Signal render every 2 ticks (~50 fps at 100 Hz base, easily 60+ with PIT tuning)
    if tick % 2 == 0 {
        RENDER_PENDING.store(true, Ordering::Release);
    }

    // 4. EOI
    unsafe {
        PICS.lock().notify_end_of_interrupt(InterruptIndex::Timer.as_u8());
    }
}

// ============================================================================
// KEYBOARD INTERRUPT — IRQ1
// ============================================================================

/// 16-byte ring buffer for decoded keypresses.
pub struct KeyRing {
    buf: [Option<DecodedKey>; 16],
    head: usize,
    tail: usize,
}

impl KeyRing {
    const fn new() -> Self {
        KeyRing {
            buf: [None; 16],
            head: 0,
            tail: 0,
        }
    }

    pub fn push(&mut self, key: DecodedKey) {
        let next = (self.tail + 1) % 16;
        if next != self.head {
            self.buf[self.tail] = Some(key);
            self.tail = next;
        }
        // If full, oldest key is silently dropped (ring overflow)
    }

    pub fn pop(&mut self) -> Option<DecodedKey> {
        if self.head == self.tail {
            return None;
        }
        let key = self.buf[self.head].take();
        self.head = (self.head + 1) % 16;
        key
    }

    pub fn is_empty(&self) -> bool {
        self.head == self.tail
    }
}

// SAFETY: KeyRing only touched inside interrupts::without_interrupts or in ISR.
unsafe impl Send for KeyRing {}

pub static KEY_BUFFER: Mutex<KeyRing> = Mutex::new(KeyRing::new());

extern "x86-interrupt" fn keyboard_interrupt_handler(_stack_frame: InterruptStackFrame) {
    lazy_static! {
        static ref KEYBOARD: Mutex<Keyboard<layouts::Us104Key, ScancodeSet1>> =
            Mutex::new(Keyboard::new(
                ScancodeSet1::new(),
                layouts::Us104Key,
                HandleControl::Ignore,
            ));
    }

    let mut keyboard = KEYBOARD.lock();
    let mut port: Port<u8> = Port::new(0x60);
    let scancode: u8 = unsafe { port.read() };

    if let Ok(Some(key_event)) = keyboard.add_byte(scancode) {
        if let Some(key) = keyboard.process_keyevent(key_event) {
            KEY_BUFFER.lock().push(key);
        }
    }

    unsafe {
        PICS.lock().notify_end_of_interrupt(InterruptIndex::Keyboard.as_u8());
    }
}

// ============================================================================
// CPU EXCEPTION HANDLERS
// ============================================================================

extern "x86-interrupt" fn breakpoint_handler(stack_frame: InterruptStackFrame) {
    println!("[EXCEPTION] BREAKPOINT\n{:#?}", stack_frame);
}

extern "x86-interrupt" fn double_fault_handler(
    stack_frame: InterruptStackFrame,
    _error_code: u64,
) -> ! {
    panic!("[EXCEPTION] DOUBLE FAULT\n{:#?}", stack_frame);
}

extern "x86-interrupt" fn page_fault_handler(
    stack_frame: InterruptStackFrame,
    error_code: PageFaultErrorCode,
) {
    use x86_64::registers::control::Cr2;
    println!(
        "[EXCEPTION] PAGE FAULT\nAddr: {:?}\nErr: {:?}\n{:#?}",
        Cr2::read(), error_code, stack_frame
    );
    crate::hlt_loop();
}

extern "x86-interrupt" fn gpf_handler(
    stack_frame: InterruptStackFrame,
    error_code: u64,
) {
    println!("[EXCEPTION] GPF (code {})\n{:#?}", error_code, stack_frame);
    crate::hlt_loop();
}

// ============================================================================
// PIT REPROGRAMMING — target frequency
// ============================================================================

/// Reprogram the 8253/8254 PIT to a target Hz.
/// Default BIOS frequency is ~18.2 Hz. We want 100 Hz for smooth evolution.
///
/// PIT input clock = 1_193_182 Hz
/// Divisor = 1_193_182 / target_hz
pub fn set_pit_frequency(target_hz: u32) {
    let divisor = (1_193_182_u32 / target_hz).min(65535) as u16;
    unsafe {
        // Command: channel 0, lo/hi byte, mode 3 (square wave)
        Port::<u8>::new(0x43).write(0x36);
        // Low byte then high byte
        Port::<u8>::new(0x40).write((divisor & 0xFF) as u8);
        Port::<u8>::new(0x40).write((divisor >> 8) as u8);
    }
}

// ============================================================================
// INIT
// ============================================================================

pub fn init() {
    init_idt();

    // Initialize and unmask both PICs
    unsafe { PICS.lock().initialize() };

    // Reprogram PIT to 100 Hz
    set_pit_frequency(100);

    // Enable hardware interrupts
    x86_64::instructions::interrupts::enable();
}

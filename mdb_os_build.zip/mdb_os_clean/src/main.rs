// ============================================================================
// src/main.rs — MDB OS Kernel Entry Point
//
// Boot sequence:
//   1. GDT + TSS  (double-fault stack)
//   2. IDT        (exception handlers + hardware IRQs)
//   3. Heap       (enables Vec, BTreeMap, String in no_std)
//   4. Filesystem (mount initial DimensionalIndex)
//   5. Scheduler  (spawn idle + init processes)
//   6. Eternal loop:
//        a. EVOLVE_PENDING → scheduler.tick() + fs.evolve_tick()
//        b. RENDER_PENDING → render_frame() to VGA
//        c. KEY_BUFFER → process keypresses
//        d. hlt           (halts until next interrupt, saves power)
//
// QEMU boot command (run from project root after `cargo bootimage`):
//
//   qemu-system-x86_64 \
//     -drive format=raw,file=target/x86_64-mdb_os/debug/bootimage-mdb_os.bin \
//     -serial stdio \
//     -m 128M
//
// For release build (faster evolution, ~60+ fps render):
//   cargo bootimage --release
//   qemu-system-x86_64 \
//     -drive format=raw,file=target/x86_64-mdb_os/release/bootimage-mdb_os.bin \
//     -serial stdio \
//     -m 128M
// ============================================================================

#![no_std]
#![no_main]
#![feature(abi_x86_interrupt)]
#![feature(alloc_error_handler)]

extern crate alloc;

use alloc::format;
use alloc::string::ToString;
use alloc::vec::Vec;
use bootloader::{BootInfo, entry_point};
use core::panic::PanicInfo;
use core::sync::atomic::Ordering;
use x86_64::VirtAddr;
use pc_keyboard::DecodedKey;

// ── Kernel modules ────────────────────────────────────────────────────────────
mod gdt;
mod interrupts;
mod memory;
mod mdb_core;
mod scheduler;
mod filesystem;
mod vga_buffer;

use crate::interrupts::{KERNEL_TICK, RENDER_PENDING, EVOLVE_PENDING};
use crate::vga_buffer::{FrameData, NodeSnapshot, render_frame};
use crate::scheduler::{SCHEDULER, ProcessSnapshot};
use crate::filesystem::FS;

// ============================================================================
// ENTRY POINT
// ============================================================================

entry_point!(kernel_main);

fn kernel_main(boot_info: &'static BootInfo) -> ! {
    // ── 1. GDT + TSS ─────────────────────────────────────────────────────────
    gdt::init();

    // ── 2. IDT + PIC + PIT ───────────────────────────────────────────────────
    interrupts::init();

    // ── 3. Heap ───────────────────────────────────────────────────────────────
    let phys_mem_offset = VirtAddr::new(boot_info.physical_memory_offset);
    let mut mapper = memory::init_mapper(phys_mem_offset);
    let mut frame_alloc = memory::BumpAllocator::new(&boot_info.memory_map);
    memory::init_heap(&mut mapper, &mut frame_alloc)
        .expect("MDB OS: heap init failed");

    // ── 4. VGA initial paint ──────────────────────────────────────────────────
    vga_buffer::WRITER.lock().clear();
    println!("MDB OS booting...");

    // ── 5. Filesystem ─────────────────────────────────────────────────────────
    filesystem::mount();
    println!("FS mounted: {} files", FS.lock().file_count());

    // ── 6. Scheduler: spawn initial processes ─────────────────────────────────
    {
        let mut sched = SCHEDULER.lock();

        // PID 1: idle — always runnable, lowest weight
        let idle_pid = sched.spawn("idle");
        // PID 2: init — the first real process
        let init_pid = sched.spawn("init");
        // PID 3: vga_driver — drives the framebuffer
        let vga_pid  = sched.spawn("vga_driver");
        // PID 4: kbd_driver — handles keyboard events
        let kbd_pid  = sched.spawn("kbd_driver");

        // Entangle init ↔ vga_driver (rendering is IPC from init)
        sched.entangle_procs(init_pid, vga_pid);
        // Entangle kbd_driver ↔ init (keyboard events go to init)
        sched.entangle_procs(kbd_pid, init_pid);

        sched.current = init_pid;
    }
    println!("Scheduler: {} processes ready", SCHEDULER.lock().procs.len());
    println!("MDB OS ready. Entering evolution loop.");

    // ── 7. Eternal evolution loop ─────────────────────────────────────────────
    loop {
        // a. Scheduler + FS tick (on timer signal)
        if EVOLVE_PENDING.swap(false, Ordering::AcqRel) {
            // Tick the scheduler (MDB network propagation = scheduling)
            scheduler::tick();

            // Evolve live filesystem entries
            x86_64::instructions::interrupts::without_interrupts(|| {
                FS.lock().evolve_tick();
            });
        }

        // b. Render frame (on render signal)
        if RENDER_PENDING.swap(false, Ordering::AcqRel) {
            let frame = build_frame();
            render_frame(&frame);
        }

        // c. Process keyboard input
        process_keys();

        // d. Halt until next interrupt (power-efficient idle)
        x86_64::instructions::hlt();
    }
}

// ============================================================================
// FRAME BUILDER
// ============================================================================

/// Snapshot the current kernel state and build a FrameData for the renderer.
fn build_frame() -> FrameData {
    let tick = KERNEL_TICK.load(Ordering::Relaxed);

    // Snapshot scheduler
    let proc_snapshots = x86_64::instructions::interrupts::without_interrupts(|| {
        SCHEDULER.lock().snapshot(tick)
    });

    // Build NodeSnapshot list for the VGA renderer (up to 16 nodes)
    let nodes: Vec<NodeSnapshot> = proc_snapshots
        .iter()
        .take(16)
        .map(|ps| NodeSnapshot {
            name:        format!("[{}] {}", ps.pid, ps.name),
            state_label: ps.state_label.clone(),
            weights:     ps.weights.clone(),
            address:     ps.address,
            d6:          ps.d6,
            generation:  ps.generation,
        })
        .collect();

    // Global dimensional values: aggregate across all nodes
    let (global_d3, global_d4, global_d5) = if nodes.is_empty() {
        (0, 0.0, 0.0)
    } else {
        let d3 = nodes.iter().map(|n| n.address.d3).sum::<usize>() / nodes.len();
        let d4 = nodes.iter().map(|n| n.address.d4_float()).sum::<f64>() / nodes.len() as f64;
        let d5 = nodes.iter().map(|n| n.address.d5_float()).sum::<f64>() / nodes.len() as f64;
        (d3, d4, d5)
    };

    // Active bits: the kernel file's current SuperBit bit string
    let active_bits = x86_64::instructions::interrupts::without_interrupts(|| {
        FS.lock()
            .read_path("boot/kernel/mdb_os")
            .map(|sb| sb.bits.clone())
            .unwrap_or_default()
    });

    FrameData {
        tick,
        global_d3,
        global_d4,
        global_d5,
        nodes,
        active_bits,
    }
}

// ============================================================================
// KEYBOARD INPUT
// ============================================================================

fn process_keys() {
    loop {
        let key = x86_64::instructions::interrupts::without_interrupts(|| {
            interrupts::KEY_BUFFER.lock().pop()
        });
        match key {
            None => break,
            Some(DecodedKey::Unicode(c)) => {
                // Echo to console
                print!("{}", c);
            }
            Some(DecodedKey::RawKey(k)) => {
                // Special key — future: dispatch to focused process
                println!("[KEY {:?}]", k);
            }
        }
    }
}

// ============================================================================
// PANIC HANDLER
// ============================================================================

#[panic_handler]
fn panic(info: &PanicInfo) -> ! {
    // Try to print to VGA — may fail if VGA is broken, but usually works
    use core::fmt::Write;
    use crate::vga_buffer::{WRITER, COLOR_ERROR};

    let mut w = WRITER.lock();
    w.clear_row(24, COLOR_ERROR);
    // Can't use format! in panic (no alloc guarantee), use write! directly
    let _ = write!(w, "PANIC: {}", info);

    // Also write to serial (always works)
    serial_println!("PANIC: {}", info);

    hlt_loop()
}

/// Halt loop — called on unrecoverable errors.
pub fn hlt_loop() -> ! {
    loop {
        x86_64::instructions::hlt();
    }
}

// ============================================================================
// SERIAL OUTPUT (for QEMU -serial stdio debugging)
// ============================================================================

use uart_16550::SerialPort;
use spin::Mutex as SpinMutex;
use lazy_static::lazy_static;

lazy_static! {
    pub static ref SERIAL1: SpinMutex<SerialPort> = {
        let mut port = unsafe { SerialPort::new(0x3F8) };
        port.init();
        SpinMutex::new(port)
    };
}

#[doc(hidden)]
pub fn _serial_print(args: core::fmt::Arguments) {
    use core::fmt::Write;
    use x86_64::instructions::interrupts;
    interrupts::without_interrupts(|| {
        SERIAL1.lock().write_fmt(args).unwrap();
    });
}

#[macro_export]
macro_rules! serial_print {
    ($($arg:tt)*) => ($crate::_serial_print(format_args!($($arg)*)));
}

#[macro_export]
macro_rules! serial_println {
    () => ($crate::serial_print!("\n"));
    ($fmt:expr) => ($crate::serial_print!(concat!($fmt, "\n")));
    ($fmt:expr, $($arg:tt)*) => ($crate::serial_print!(concat!($fmt, "\n"), $($arg)*));
}

// ============================================================================
// src/scheduler.rs — MDB Process Scheduler
//
// The scheduler IS the MDB network propagation engine.
//
// Each process = one SuperBit node in an MDBNetwork.
// Each scheduling tick = one propagate() call from the current node.
// The next process to run = the node with the highest dominant weight
// after propagation. No round-robin. No priority queue. Natural MDB
// evolution selects the next runnable process.
//
// Process states are encoded as SuperBit labels:
//   "running" | "ready" | "blocked" | "sleeping" | "zombie"
//
// When a process evolves toward "blocked", its weight for that state
// rises and it naturally stops being selected by the scheduler.
// ============================================================================

extern crate alloc;
use alloc::string::{String, ToString};
use alloc::vec::Vec;
use alloc::vec;
use alloc::collections::BTreeMap;
use alloc::format;

use spin::Mutex;
use lazy_static::lazy_static;
use core::sync::atomic::Ordering;

use crate::mdb_core::{SuperBit, MDBNetwork, EntangledMemory, DimAddr};
use crate::interrupts::KERNEL_TICK;

// ============================================================================
// PROCESS STATE INDICES (SuperBit label indices)
// ============================================================================

pub const STATE_RUNNING:  usize = 0;
pub const STATE_READY:    usize = 1;
pub const STATE_BLOCKED:  usize = 2;
pub const STATE_SLEEPING: usize = 3;
pub const STATE_ZOMBIE:   usize = 4;

fn process_labels() -> Vec<String> {
    vec![
        "running".to_string(),
        "ready".to_string(),
        "blocked".to_string(),
        "sleeping".to_string(),
        "zombie".to_string(),
    ]
}

// ============================================================================
// PROCESS CONTROL BLOCK
// ============================================================================

#[derive(Debug, Clone)]
pub struct Pcb {
    pub pid:     u64,
    pub name:    String,
    /// The SuperBit for this process lives in SCHEDULER's MDBNetwork.
    /// We store its dimensional address here for direct lookup.
    pub addr:    DimAddr,
    /// Kernel stack pointer (saved on preemption — future use)
    pub kstack:  u64,
    /// Number of times this process has been scheduled
    pub run_count: u64,
}

// ============================================================================
// GLOBAL SCHEDULER STATE
// ============================================================================

pub struct Scheduler {
    /// The MDB network. Each node = one process SuperBit.
    pub net: MDBNetwork,
    /// Process table: pid → PCB
    pub procs: BTreeMap<u64, Pcb>,
    /// Currently running pid
    pub current: u64,
    /// Next pid to assign
    next_pid: u64,
    /// Entangled memory fabric (process ↔ process entanglement for IPC)
    pub memory: EntangledMemory,
}

impl Scheduler {
    pub fn new() -> Self {
        Scheduler {
            net: MDBNetwork::new(),
            procs: BTreeMap::new(),
            current: 0,
            next_pid: 1,
            memory: EntangledMemory::new(),
        }
    }

    // ── Process creation ─────────────────────────────────────────────────────

    /// Spawn a new process.
    /// Returns the new pid.
    pub fn spawn(&mut self, name: &str) -> u64 {
        let pid = self.next_pid;
        self.next_pid += 1;

        // New process starts mostly "ready" with small chance of "running"
        let weights = vec![0.1, 0.8, 0.05, 0.05, 0.0];
        let sb = SuperBit::with_weights(process_labels(), weights);
        let addr = sb.address;

        let node_name = format!("pid{}", pid);
        self.net.add_node(&node_name, sb);

        // Connect to all existing processes with weight 0.3 (base IPC strength)
        let existing: Vec<String> = self.procs.values()
            .map(|p| format!("pid{}", p.pid))
            .collect();
        for existing_name in &existing {
            self.net.connect(&node_name, existing_name, 0.3);
        }

        self.procs.insert(pid, Pcb {
            pid,
            name: name.to_string(),
            addr,
            kstack: 0,
            run_count: 0,
        });

        pid
    }

    // ── Scheduling tick ───────────────────────────────────────────────────────

    /// One scheduling tick. Called from the kernel main loop when EVOLVE_PENDING.
    ///
    /// 1. evolve_step the current process's SuperBit (string evolution)
    /// 2. propagate the network 2 levels deep from current node
    /// 3. Select the next process by highest "ready" weight
    /// 4. Transition current → ready, next → running
    pub fn tick(&mut self, tick: u64) -> u64 {
        if self.procs.is_empty() {
            return 0;
        }

        let current_name = format!("pid{}", self.current);

        // 1. String-evolve the current process node
        if let Some(node) = self.net.nodes.get_mut(&current_name) {
            node.string_evolve();
            // Reinforce "running" state for the current process
            node.evolve(STATE_RUNNING, 0.02);
        }

        // 2. Propagate network 2 levels from current node
        let signal = STATE_READY; // propagate a "readiness" signal
        self.net.propagate(&current_name, signal, 2, tick);

        // 3. Select next runnable process: highest weight for STATE_READY
        let mut best_pid = self.current;
        let mut best_weight = -1.0_f64;

        for (pid, _pcb) in &self.procs {
            let name = format!("pid{}", pid);
            if let Some(node) = self.net.nodes.get(&name) {
                let ready_weight = node.weights.get(STATE_READY).copied().unwrap_or(0.0);
                // Don't re-select zombie processes
                let zombie_weight = node.weights.get(STATE_ZOMBIE).copied().unwrap_or(0.0);
                if ready_weight > best_weight && zombie_weight < 0.5 {
                    best_weight = ready_weight;
                    best_pid = *pid;
                }
            }
        }

        // 4. Transition states
        if best_pid != self.current {
            // Old current → ready
            if let Some(node) = self.net.nodes.get_mut(&current_name) {
                node.evolve(STATE_READY, 0.1);
                node.evolve(STATE_RUNNING, -0.05_f64.max(0.0)); // decay running weight
            }
            // New current → running
            let next_name = format!("pid{}", best_pid);
            if let Some(node) = self.net.nodes.get_mut(&next_name) {
                node.evolve(STATE_RUNNING, 0.15);
            }
            self.current = best_pid;
        }

        // Track run count
        if let Some(pcb) = self.procs.get_mut(&best_pid) {
            pcb.run_count += 1;
        }

        self.current
    }

    // ── Process termination ───────────────────────────────────────────────────

    /// Mark a process as a zombie (will be reaped next tick).
    pub fn exit(&mut self, pid: u64) {
        let name = format!("pid{}", pid);
        if let Some(node) = self.net.nodes.get_mut(&name) {
            node.evolve(STATE_ZOMBIE, 0.9);
        }
    }

    /// Reap zombie processes from the network.
    pub fn reap_zombies(&mut self) {
        let zombies: Vec<u64> = self.procs.iter()
            .filter(|(_, pcb)| {
                let name = format!("pid{}", pcb.pid);
                self.net.nodes.get(&name)
                    .and_then(|n| n.weights.get(STATE_ZOMBIE))
                    .copied()
                    .unwrap_or(0.0) > 0.9
            })
            .map(|(pid, _)| *pid)
            .collect();

        for pid in zombies {
            let name = format!("pid{}", pid);
            self.net.nodes.remove(&name);
            self.net.edges.remove(&name);
            self.procs.remove(&pid);
        }
    }

    // ── IPC entanglement ──────────────────────────────────────────────────────

    /// Entangle two processes for IPC.
    /// A learning signal in one will ripple to the other.
    pub fn entangle_procs(&mut self, pid_a: u64, pid_b: u64) {
        let name_a = format!("pid{}", pid_a);
        let name_b = format!("pid{}", pid_b);
        let d6_a = self.net.nodes.get(&name_a).map(|n| n.d6()).unwrap_or(0.0);
        let d6_b = self.net.nodes.get(&name_b).map(|n| n.d6()).unwrap_or(0.0);
        self.memory.entangle(&name_a, &name_b, d6_a, d6_b);
        // Also strengthen the network edge
        self.net.connect(&name_a, &name_b, 0.8);
    }

    // ── Snapshot for renderer ─────────────────────────────────────────────────

    pub fn snapshot(&self, tick: u64) -> Vec<ProcessSnapshot> {
        self.procs.values().map(|pcb| {
            let name = format!("pid{}", pcb.pid);
            let node = self.net.nodes.get(&name);
            ProcessSnapshot {
                pid: pcb.pid,
                name: pcb.name.clone(),
                state_label: node
                    .map(|n| n.collapse_label(tick).to_string())
                    .unwrap_or_else(|| "?".to_string()),
                weights: node.map(|n| n.weights.clone()).unwrap_or_default(),
                address: node.map(|n| n.address).unwrap_or(DimAddr { d3: 0, d4: 0, d5: 0 }),
                d6: node.map(|n| n.d6()).unwrap_or(0.0),
                generation: node.map(|n| n.generation).unwrap_or(0),
                run_count: pcb.run_count,
                is_current: pcb.pid == self.current,
            }
        }).collect()
    }
}

impl Default for Scheduler {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Debug, Clone)]
pub struct ProcessSnapshot {
    pub pid:         u64,
    pub name:        String,
    pub state_label: String,
    pub weights:     Vec<f64>,
    pub address:     DimAddr,
    pub d6:          f64,
    pub generation:  u32,
    pub run_count:   u64,
    pub is_current:  bool,
}

// ============================================================================
// GLOBAL SCHEDULER
// ============================================================================

lazy_static! {
    pub static ref SCHEDULER: Mutex<Scheduler> = Mutex::new(Scheduler::new());
}

/// Called from main loop when EVOLVE_PENDING is set.
pub fn tick() {
    let tick = KERNEL_TICK.load(Ordering::Relaxed);
    x86_64::instructions::interrupts::without_interrupts(|| {
        SCHEDULER.lock().tick(tick);
    });
}

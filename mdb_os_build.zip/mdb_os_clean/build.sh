#!/usr/bin/env bash
# MDB OS — build and boot script
# Run this inside the Replit shell: bash build.sh

set -e

echo "=== MDB OS Build Script ==="

# 1. Check for rustup
if ! command -v rustup &>/dev/null; then
    echo "[1/5] Installing Rust..."
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --default-toolchain nightly
    source "$HOME/.cargo/env"
else
    echo "[1/5] Rust found: $(rustc --version)"
    rustup override set nightly
fi

source "$HOME/.cargo/env" 2>/dev/null || true

# 2. Components
echo "[2/5] Adding rust-src and llvm-tools-preview..."
rustup component add rust-src llvm-tools-preview

# 3. bootimage
echo "[3/5] Installing bootimage..."
cargo install bootimage

# 4. Build
echo "[4/5] Building MDB OS (release)..."
cargo bootimage --release 2>&1

# 5. Boot
echo "[5/5] Booting in QEMU..."
DISK=target/x86_64-mdb_os/release/bootimage-mdb_os.bin

if [ ! -f "$DISK" ]; then
    echo "ERROR: disk image not found at $DISK"
    exit 1
fi

qemu-system-x86_64 \
    -drive format=raw,file="$DISK" \
    -nographic \
    -serial mon:stdio \
    -m 128M
